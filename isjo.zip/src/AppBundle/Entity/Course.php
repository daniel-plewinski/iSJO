<?php

namespace AppBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * Course
 *
 * @ORM\Table(name="course")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\CourseRepository")
 */
class Course
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;


    /**
     * @ORM\OneToMany(targetEntity="Lesson", mappedBy="course")
     */
    private $lessons;


    /**
     * @ORM\Column(name="school_id", type="integer", length=50)
     */
    private $schoolId;


    /**
     * @ORM\Column(name="teacher_id", type="integer", length=50)
     */
    private $teacherId;

    /**
     * @var string
     *
     * @ORM\Column(name="course_name", type="string", length=50)
     *
     */
    private $courseName;

    /**
     * @var string
     *
     * @ORM\Column(name="subject", type="string", length=50)
     */
    private $subject;


    /**
     * @var int
     *
     * @ORM\Column(name="total_lessons", type="integer", length=4)
     */
    private $totalLessons;


    /**
     * @ORM\Column(name="teacher_rate", type="decimal", precision=7, scale=2)
     */
    protected $teacherRate;


    public function __construct()
    {
        $this->lessons = new ArrayCollection();
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set courseName
     *
     * @param string $courseName
     *
     * @return Course
     */
    public function setCourseName($courseName)
    {
        $this->courseName = $courseName;

        return $this;
    }

    /**
     * Get courseName
     *
     * @return string
     */
    public function getCourseName()
    {
        return $this->courseName;
    }

    /**
     * Set subject
     *
     * @param string $subject
     *
     * @return Course
     */
    public function setSubject($subject)
    {
        $this->subject = $subject;

        return $this;
    }

    /**
     * Get subject
     *
     * @return string
     */
    public function getSubject()
    {
        return $this->subject;
    }

    /**
     * Set schoolId
     *
     * @param integer $schoolId
     *
     * @return Course
     */
    public function setSchoolId($schoolId)
    {
        $this->schoolId = $schoolId;

        return $this;
    }

    /**
     * Get schoolId
     *
     * @return integer
     */
    public function getSchoolId()
    {
        return $this->schoolId;
    }

    /**
     * Set teacherId
     *
     * @param integer $teacherId
     *
     * @return Course
     */
    public function setTeacherId($teacherId)
    {
        $this->teacherId = $teacherId;

        return $this;
    }

    /**
     * Get teacherId
     *
     * @return integer
     */
    public function getTeacherId()
    {
        return $this->teacherId;
    }


    /**
     * Add lesson
     *
     * @param \AppBundle\Entity\Lesson $lesson
     *
     * @return Course
     */
    public function addLesson(\AppBundle\Entity\Lesson $lesson)
    {
        $this->lessons[] = $lesson;

        return $this;
    }

    /**
     * Remove lesson
     *
     * @param \AppBundle\Entity\Lesson $lesson
     */
    public function removeLesson(\AppBundle\Entity\Lesson $lesson)
    {
        $this->lessons->removeElement($lesson);
    }

    /**
     * Get lessons
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLessons()
    {
        return $this->lessons;
    }

    /**
     * Set totalLessons
     *
     * @param integer $totalLessons
     *
     * @return Course
     */
    public function setTotalLessons($totalLessons)
    {
        $this->totalLessons = $totalLessons;

        return $this;
    }

    /**
     * Get totalLessons
     *
     * @return integer
     */
    public function getTotalLessons()
    {
        return $this->totalLessons;
    }

    /**
     * Set teacherRate
     *
     * @return Course
     */
    public function setTeacherRate($teacherRate)
    {
        $this->teacherRate = $teacherRate;

        return $this;
    }

    /**
     * Get teacherRate
     *
     */
    public function getTeacherRate()
    {
        return $this->teacherRate;
    }
}
