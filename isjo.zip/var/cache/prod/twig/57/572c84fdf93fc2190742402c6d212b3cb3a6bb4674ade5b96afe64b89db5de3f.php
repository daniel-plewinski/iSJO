<?php

/* ::add_teacher_lesson.html.twig */
class __TwigTemplate_f2977287bfd27aad2ef1b97f9ac8d8b94d689acc51d0920626444e02b00b0558 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::add_teacher_lesson.html.twig", 1);
        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_javascripts($context, array $blocks = array())
    {
        // line 4
        echo "
    ";
        // line 5
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/locales/bootstrap-datepicker.pl.min.js\"></script>

    <script>
        \$(document).ready(function () {
            \$('.js-datepicker').datepicker({
                language: 'pl-PL',
                showOn: 'button',
                buttonImageOnly: true,
                changeMonth: true,
                changeYear: true,
                format: 'yyyy-mm-dd',
                yearRange: \"-0:+1\"

            });
        });
    </script>

";
    }

    // line 27
    public function block_body($context, array $blocks = array())
    {
        // line 28
        echo "

    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Dodawanie lekcji
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Dodawanie lekcji</a>
                </li>
            </ol>
        </div>

        <p>Do nazwy kursu automatycznie dodawany jest unikalny numer aby nazwa nie mogła się powtarzać</p>

        ";
        // line 50
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
        echo "
        ";
        // line 51
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'widget');
        echo "
        ";
        // line 52
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        echo "

    </div>



";
    }

    public function getTemplateName()
    {
        return "::add_teacher_lesson.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 52,  91 => 51,  87 => 50,  63 => 28,  60 => 27,  35 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "::add_teacher_lesson.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/add_teacher_lesson.html.twig");
    }
}
