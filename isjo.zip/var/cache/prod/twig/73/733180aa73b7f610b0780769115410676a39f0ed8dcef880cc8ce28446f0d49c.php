<?php

/* ::show_school_lessons.html.twig */
class __TwigTemplate_a26f52afa3eb40308cab125b029ccba0321939d7a7bc2a32e08c960edade507d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::show_school_lessons.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "
    <div class=\"container-fluid\">
    <!-- Page Heading -->
    <div class=\"row\">
        <div class=\"col-md-12\">
            <h2>
                Lekcje
            </h2>
        </div>
    </div>

    <div class=\"row\">
        <ol class=\"breadcrumb\">
            <li>
                <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
            </li>
            <li class=\"active\">
                <i class=\"fa fa-file\"></i> Lekcje
            </li>
        </ol>
    </div>
    <div>

        <div class=\"row\">
            <div class=\"col-lg-12\">
                <h4>Kurs ";
        // line 29
        echo twig_escape_filter($this->env, ($context["courseName"] ?? null), "html", null, true);
        echo "</h4>
                <table class=\"table\">
                    <thead class=\"thead\">
                    <tr>
                        <th>L.p.</th>
                        <th>Data lekcji</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>

                    ";
        // line 40
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["pagination"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 41
            echo "                        <tr>
                            <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["pagination"] ?? null), "getPaginationData", array()), "firstItemNumber", array()), "html", null, true);
            echo "</td>
                            <td>";
            // line 43
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["element"], "date", array()), "d-m-Y"), "html", null, true);
            echo "</td>
                            <td>
                                <a href=\" ";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete_school_lesson_course", array("id" => $this->getAttribute($context["element"], "id", array()))), "html", null, true);
            echo "\">
                                    <button type=\"button\" class=\"btn btn-danger\">Usuń</button>
                                </a>

                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "                    </tbody>
                </table>
                ";
        // line 55
        echo "                <div class=\"navigation\">
                    <div class=\"text-center\">
                    ";
        // line 57
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, ($context["pagination"] ?? null));
        echo "
                    </div>
                </div>
            </div>
        </div>
    </div>


";
    }

    public function getTemplateName()
    {
        return "::show_school_lessons.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 57,  105 => 55,  101 => 52,  88 => 45,  83 => 43,  79 => 42,  76 => 41,  72 => 40,  58 => 29,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "::show_school_lessons.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/show_school_lessons.html.twig");
    }
}
