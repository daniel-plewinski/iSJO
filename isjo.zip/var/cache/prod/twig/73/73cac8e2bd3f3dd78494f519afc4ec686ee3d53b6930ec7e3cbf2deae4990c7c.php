<?php

/* ::show_lessons.html.twig */
class __TwigTemplate_a08ebb840195e57548475aca4e1a0cc00d4ac97b2397b0c57499aeafc2efdeea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::show_lessons.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "
    <div class=\"container-fluid\">
    <!-- Page Heading -->
    <div class=\"row\">
        <div class=\"col-md-12\">
            <h2>
                Lekcje
            </h2>
        </div>
    </div>

    <div class=\"row\">
        <ol class=\"breadcrumb\">
            <li>
                <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
            </li>
            <li class=\"active\">
                <i class=\"fa fa-file\"></i> Lekcje
            </li>
        </ol>
    </div>
    <div>

        <div class=\"row\">
            <div class=\"col-lg-12\">
                <p>Możesz usuwać tylko lekcje dodane tego samego dnia. Jeśli musisz usunąć wcześniejszą lekcję - napisz
                    do administratora szkoły.</p>
                <h4>Kurs ";
        // line 31
        echo twig_escape_filter($this->env, $this->getAttribute(($context["course"] ?? null), "courseName", array()), "html", null, true);
        echo "</h4>
                <p>Stan realizacji lekcji ";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute(($context["pagination"] ?? null), "getTotalItemCount", array()), "html", null, true);
        echo " z ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["course"] ?? null), "totalLessons", array()), "html", null, true);
        echo "</p>

                <table class=\"table\">
                    <thead class=\"thead\">
                    <tr>
                        <th>L.p.</th>
                        <th>Data lekcji</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["pagination"] ?? null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 44
            echo "                        <tr>
                            <td>";
            // line 45
            echo twig_escape_filter($this->env, (($this->getAttribute($this->getAttribute(($context["pagination"] ?? null), "getPaginationData", array()), "firstItemNumber", array()) + $this->getAttribute($context["loop"], "index", array())) - 1), "html", null, true);
            echo "</td>
                            <td>";
            // line 46
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["element"], "date", array()), "d-m-Y"), "html", null, true);
            echo "</td>
                            <td>

                                ";
            // line 49
            if ($this->env->getExtension('AppBundle\Twig\AppExtension')->isOneDayOld($this->getAttribute($context["element"], "dateAdded", array()))) {
                // line 50
                echo "                                <a href=\" ";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete_teacher_lesson_course", array("id" => $this->getAttribute($context["element"], "id", array()))), "html", null, true);
                echo "\">
                                    <button type=\"button\" class=\"btn btn-danger\">Usuń</button>
                                </a>
                                ";
            }
            // line 54
            echo "
                            </td>
                        </tr>
                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "                    </tbody>
                </table>
                ";
        // line 61
        echo "                <div class=\"navigation\">
                    <div class=\"text-center\">
                    ";
        // line 63
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, ($context["pagination"] ?? null));
        echo "
                    </div>
                </div>
            </div>
        </div>
    </div>


";
    }

    public function getTemplateName()
    {
        return "::show_lessons.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 63,  141 => 61,  137 => 58,  120 => 54,  112 => 50,  110 => 49,  104 => 46,  100 => 45,  97 => 44,  80 => 43,  64 => 32,  60 => 31,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "::show_lessons.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/show_lessons.html.twig");
    }
}
