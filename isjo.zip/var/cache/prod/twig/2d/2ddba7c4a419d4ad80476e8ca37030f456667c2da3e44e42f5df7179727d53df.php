<?php

/* ::show_courses.html.twig */
class __TwigTemplate_6b25b399486054dd879e9c504b5ed9a90dbdbf162b79a4599f9b1fdddcc66876 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::show_courses.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        echo "
    <div class=\"container-fluid\">

        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Lista kursów
                </h2>
            </div>
            <div class=\"col-md-2\">

                <h2><a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_course");
        echo "\">
                        <button type=\"button\" class=\"btn btn-info\">Dodaj kurs</button>
                    </a></h2>

            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Lista kursów
                </li>
            </ol>
        </div>
    </div>

    <div class=\"row\">
        <div class=\"col-lg-12\">
            <table class=\"table\">
                <thead class=\"thead\">
                <tr>
                    <th>L.p.</th>
                    <th>Nazwa kursu</th>
                    <th>Kod</th>
                    <th>Lekcji</th>
                    <th class=\"hidden-xs hidden-sm\">Przedmiot</th>
                    <th>Nauczyciel</th>

                    <th></th>
                    <th class=\"hidden-xs hidden-sm\"></th>
                </tr>
                </thead>
                <tbody>

                ";
        // line 54
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["pagination"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 55
            echo "                    <tr>
                        <td>";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["pagination"] ?? null), "getPaginationData", array()), "firstItemNumber", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "courseName", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "id", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 59
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "totalLessons", array()), "html", null, true);
            echo "</td>
                        <td class=\"hidden-xs hidden-sm\">";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "subject", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 61
            echo twig_escape_filter($this->env, $this->getAttribute(($context["teacherAr"] ?? null), $this->getAttribute($context["element"], "teacherId", array())), "html", null, true);
            echo "</td>
                        <td><a href=\" ";
            // line 62
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("shows_school_lessons", array("id" => $this->getAttribute($context["element"], "id", array()))), "html", null, true);
            echo "\">
                                <button type=\"button\" class=\"btn btn-info\">Lekcje</button>
                            </a></td>
                        <td class=\"hidden-xs hidden-sm\"><a href=\" ";
            // line 65
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("edit_course", array("id" => $this->getAttribute($context["element"], "id", array()))), "html", null, true);
            echo "\">
                                <button type=\"button\" class=\"btn btn-warning\">Edycja</button>
                            </a></td>

                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 71
        echo "                </tbody>
            </table>
            ";
        // line 74
        echo "            <div class=\"navigation\">
                <div class=\"text-center\">
                    ";
        // line 76
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, ($context["pagination"] ?? null));
        echo "
                </div>
            </div>
        </div>
    </div>
    </div>


";
    }

    public function getTemplateName()
    {
        return "::show_courses.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  142 => 76,  138 => 74,  134 => 71,  122 => 65,  116 => 62,  112 => 61,  108 => 60,  104 => 59,  100 => 58,  96 => 57,  92 => 56,  89 => 55,  85 => 54,  45 => 17,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "::show_courses.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/show_courses.html.twig");
    }
}
