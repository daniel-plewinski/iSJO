<?php

/* ::teacher_added.html.twig */
class __TwigTemplate_10246ba47a101950201ab122ae9b7bed9ace170f049ce18030b574952cde29e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::teacher_added.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        echo "
    <h2>Dodano nauczyciela</h2>

    <p>Ta strona wyświetla się tylko 1 raz po dodaniu nauczyciela. Zapisz wygenerowane losowo hasło tymczasowe i
    przekaż je nauczycielowi. Powinien on zmienić je na własne.</p>

    <p>Imię i nazwisko: ";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["newTeacher"] ?? null), "getName", array(), "method"), "html", null, true);
        echo "</p>
    <p>Login: ";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute(($context["newTeacher"] ?? null), "getUserName", array(), "method"), "html", null, true);
        echo "</p>
    <p>Hasło: ";
        // line 13
        echo twig_escape_filter($this->env, ($context["password"] ?? null), "html", null, true);
        echo "</p>

    <a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("show_teachers");
        echo "\"><button type=\"button\" class=\"btn btn-primary\">Powrót do listy nauczycieli</button></a>

";
    }

    public function getTemplateName()
    {
        return "::teacher_added.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  52 => 15,  47 => 13,  43 => 12,  39 => 11,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "::teacher_added.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/teacher_added.html.twig");
    }
}
