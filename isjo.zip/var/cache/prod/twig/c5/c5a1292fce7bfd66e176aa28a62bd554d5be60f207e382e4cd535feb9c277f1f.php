<?php

/* ::show_teachers.html.twig */
class __TwigTemplate_7dc0c8a4009798c6fa27e988bd144ecee7620d5eb67219974c3cc1f5e3c957d9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::show_teachers.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        echo "
    <div class=\"container-fluid\">

        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Lista nauczycieli
                </h2>
            </div><div class=\"col-md-2\">

                <h2><a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_teacher");
        echo "\"><button type=\"button\" class=\"btn btn-info\">Dodaj nauczyciela</button></a></h2>

            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Lista nauczycieli
                </li>
            </ol>
        </div>
    </div>

    <div class=\"row\">
        <div class=\"col-lg-12\">
            <table class=\"table\">
                <thead class=\"thead\">
                <tr>
                    <th>L.p.</th>
                    <th>Nazwisko i imię</th>
                    <th>Dodaj kurs</th>
                    <th>Edycja</th>
                </tr>
                </thead>
                <tbody>
                ";
        // line 45
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["teachers"] ?? null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 46
            echo "                    <tr>
                        <td>";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "name", array()), "html", null, true);
            echo "</td>
                        <td><a href=\" ";
            // line 49
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_course_id", array("id" => $this->getAttribute($context["element"], "id", array()))), "html", null, true);
            echo "\">
                                <button type=\"button\" class=\"btn btn-info\">Dodaj kurs</button>
                            </a></td>
                        <td><a href=\" ";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("edit_teacher", array("id" => $this->getAttribute($context["element"], "id", array()))), "html", null, true);
            echo "\">
                                <button type=\"button\" class=\"btn btn-warning\">Edycja</button>
                            </a></td>
                    </tr>
                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        echo "                </tbody>
            </table>
        </div>
    </div>
    </div>


";
    }

    public function getTemplateName()
    {
        return "::show_teachers.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 57,  110 => 52,  104 => 49,  100 => 48,  96 => 47,  93 => 46,  76 => 45,  44 => 16,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "::show_teachers.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/show_teachers.html.twig");
    }
}
