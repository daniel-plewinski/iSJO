<?php

/* base.html.twig */
class __TwigTemplate_9ca3c8ee3d7c5b7c860084f952e1c8f1d4d85829de13912d1724823ac1ae5742 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"pl\">

<head>

    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>iSJO - Szkoła językowae</title>

    <!-- Bootstrap Core CSS -->
    <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/sb-admin.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/css/bootstrap-datepicker.css\"/>


    <!-- Custom CSS -->
    <link rel=\"stylesheet\" href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/blog-home.css"), "html", null, true);
        echo "\"/>

</head>

<body>

<div id=\"wrapper\">


    <!-- Navigation -->
    <nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-ex1-collapse\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"/\">iSJO</a>
        </div>
        <!-- Top Menu Items -->
        <ul class=\"nav navbar-right top-nav\">
            <li class=\"dropdown\">
                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\"><i
                            class=\"fa fa-user\"></i> ";
        // line 48
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array()), "name", array()), "html", null, true);
        echo " <b
                            class=\"caret\"></b></a>
                <ul class=\"dropdown-menu\">
                    <li>
                        <a href=\"/profile\"><i class=\"fa fa-fw fa-user\"></i> Profil</a>
                    </li>
                    <li class=\"divider\"></li>
                    <li>
                        <a href=\"/logout\"><i class=\"fa fa-fw fa-power-off\"></i> Wyloguj się</a>
                    </li>
                </ul>
            </li>
        </ul>
        <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
        <div class=\"collapse navbar-collapse navbar-ex1-collapse\">
            <ul class=\"nav navbar-nav side-nav\">

                ";
        // line 65
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_SCHOOL")) {
            // line 66
            echo "                    <li>
                        <a href=\"";
            // line 67
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index_school");
            echo "\"><i class=\"fa fa-fw fa-dashboard\"></i> Podsumowanie</a>
                    </li>
                    <li>
                        <a href=\"";
            // line 70
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("show_teachers");
            echo "\"><i class=\"fa fa-fw fa-user-circle\"></i> Nauczyciele</a>
                    </li>
                    <li>
                        <a href=\"";
            // line 73
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("show_courses");
            echo "\"><i class=\"fa fa-fw fa-table\"></i> Kursy</a>
                    </li>
                    <li><!-- Link with dropdown items -->
                    <a href=\"#homeSubmenu\" data-toggle=\"collapse\" aria-expanded=\"false\"><i class=\"fa fa-fw fa-edit\"></i>Rozliczenia</a>
                    <ul class=\"collapse list-unstyled\" id=\"homeSubmenu\">
                        <li><a href=\"";
            // line 78
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("school_settlement_date");
            echo "\"><i class=\"fa fa-fw fa-edit\"></i>Rozliczenie nauczyciela</a></li>
                        <li><a href=\"";
            // line 79
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("overview_settlement_date");
            echo "\"><i class=\"fa fa-fw fa-edit\"></i>Zestawienie zbiorcze</a></li>
                    </ul>

                ";
        } else {
            // line 83
            echo "                    <li>
                        <a href=\"";
            // line 84
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index_teacher");
            echo "\"><i class=\"fa fa-fw fa-dashboard\"></i> Podsumowanie</a>
                    </li>
                    <li>
                        <a href=\"";
            // line 87
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("show_teacher_courses");
            echo "\"><i class=\"fa fa-fw fa-table\"></i> Moje kursy</a>
                    </li>
                    <li>
                        <a href=\"";
            // line 90
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_teacher_lesson");
            echo "\"><i class=\"fa fa-fw fa-table\"></i> Dodaj lekcje</a>
                    </li>
                    <li>
                        <a href=\"";
            // line 93
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("teacher_settlement_date");
            echo "\"><i class=\"fa fa-fw fa-edit\"></i> Rozliczenia</a>
                    </li>
                ";
        }
        // line 96
        echo "

            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </nav>

    <div id=\"page-wrapper\">

        <div class=\"container-fluid min-height\">

            ";
        // line 107
        $this->displayBlock('body', $context, $blocks);
        // line 110
        echo "
        </div>

    </div>
    <!-- Footer -->
    <footer>
        <div class=\"row\">
            <div class=\"col-lg-12\">
                <p class=\"text-center\">&copy; iSJO by Daniel Plewinski</p>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </footer>

</div>

<!-- /#page-wrapper -->


";
        // line 136
        echo "
";
        // line 153
        echo "
";
        // line 154
        $this->displayBlock('javascripts', $context, $blocks);
        // line 161
        echo "
</body>
</html>

";
    }

    // line 107
    public function block_body($context, array $blocks = array())
    {
        // line 108
        echo "
            ";
    }

    // line 154
    public function block_javascripts($context, array $blocks = array())
    {
        // line 155
        echo "<script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 156
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 157
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/extra.js"), "html", null, true);
        echo "\"></script>
<script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>
<script src=\"https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  241 => 157,  237 => 156,  232 => 155,  229 => 154,  224 => 108,  221 => 107,  213 => 161,  211 => 154,  208 => 153,  205 => 136,  183 => 110,  181 => 107,  168 => 96,  162 => 93,  156 => 90,  150 => 87,  144 => 84,  141 => 83,  134 => 79,  130 => 78,  122 => 73,  116 => 70,  110 => 67,  107 => 66,  105 => 65,  85 => 48,  57 => 23,  49 => 18,  45 => 17,  41 => 16,  37 => 15,  21 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "base.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/base.html.twig");
    }
}
