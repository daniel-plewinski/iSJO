<?php

/* show_school_teacher_settlement.twig */
class __TwigTemplate_082be09299713b742571aff263209043c64e9ab7abc45d68f05f75b251b88054 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "show_school_teacher_settlement.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "
    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Rozliczenie za ";
        // line 10
        echo twig_escape_filter($this->env, ($context["month"] ?? null), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["year"] ?? null), "html", null, true);
        echo "
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Rozliczenie</a>
                </li>
            </ol>
        </div>

        <h3>Podsumowanie</h3>
        <table class=\"table\">
            <tr>
                <td class=\"short-td\">Liczba przeprowadzonych lekcji</td>
                <th>";
        // line 27
        echo twig_escape_filter($this->env, twig_length_filter($this->env, ($context["lessons"] ?? null)), "html", null, true);
        echo "</th>
            </tr>
            <tr>
                <td class=\"short-td\">Liczba kursów</td>
                <th>";
        // line 31
        echo twig_escape_filter($this->env, ($context["courseCount"] ?? null), "html", null, true);
        echo "</th>
            </tr>
            <tr>
                <td class=\"short-td\">Do wypłaty brutto</td>
                <th>";
        // line 35
        echo twig_escape_filter($this->env, ($context["salary"] ?? null), "html", null, true);
        echo "</th>
            </tr>
        </table>


        <h3>Przeprowadzone lekcje</h3>

        <table class=\"table\">
            <thead class=\"thead\">
            <tr>
                <th>L.p.</th>
                <th>Data lekcji</th>
                <th>Stawka za lekcję</th>
                <th>Nazwa kursu</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 52
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["lessons"] ?? null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 53
            echo "                <tr>
                    <td>";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 55
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["element"], "date", array()), "Y-d-m"), "html", null, true);
            echo "</td>
                    <td>";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "teacher_rate", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "course_name", array()), "html", null, true);
            echo "</td>
                </tr>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 60
        echo "            </tbody>
        </table>
    </div>




";
    }

    public function getTemplateName()
    {
        return "show_school_teacher_settlement.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 60,  127 => 57,  123 => 56,  119 => 55,  115 => 54,  112 => 53,  95 => 52,  75 => 35,  68 => 31,  61 => 27,  39 => 10,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "show_school_teacher_settlement.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/show_school_teacher_settlement.twig");
    }
}
