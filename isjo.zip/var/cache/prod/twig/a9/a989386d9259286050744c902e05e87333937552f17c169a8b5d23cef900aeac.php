<?php

/* ::show_overview_settlement.html.twig */
class __TwigTemplate_2bb4b36ddbf8240e4963704937bacbacc936e1d0d60897f20aed36935e32f827 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::show_overview_settlement.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "
    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Rozliczenie za ";
        // line 10
        echo twig_escape_filter($this->env, ($context["month"] ?? null), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["year"] ?? null), "html", null, true);
        echo "
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Rozliczenie</a>
                </li>
            </ol>
        </div>

        <h3>Podsumowanie</h3>
        <table class=\"table\">
            <tr>
                <td class=\"short-td\">Razem do wypłaty brutto</td>
                <th>";
        // line 27
        echo twig_escape_filter($this->env, ($context["totalSalary"] ?? null), "html", null, true);
        echo "</th>
            </tr>
            <tr>
                <td class=\"short-td\">Łączna liczba kursów</td>
                <th>";
        // line 31
        echo twig_escape_filter($this->env, ($context["courseCount"] ?? null), "html", null, true);
        echo "</th>
            </tr>
            <tr>
                <td class=\"short-td\">Łączna liczba lekcji</td>
                <th>";
        // line 35
        echo twig_escape_filter($this->env, ($context["lessonCount"] ?? null), "html", null, true);
        echo "</th>
            </tr>
        </table>

        <h3>Wynagrodzenie nauczycieli</h3>
        <table class=\"table\">
            ";
        // line 41
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["salaryByTeachers"] ?? null));
        foreach ($context['_seq'] as $context["index"] => $context["key"]) {
            // line 42
            echo "            <tr>
                <td class=\"short-td\">";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["key"], "name", array(), "array"), "html", null, true);
            echo "</td>
                <th>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["key"], "salary", array(), "array"), "html", null, true);
            echo "</th>
            </tr>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['index'], $context['key'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "        </table>





";
    }

    public function getTemplateName()
    {
        return "::show_overview_settlement.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 47,  95 => 44,  91 => 43,  88 => 42,  84 => 41,  75 => 35,  68 => 31,  61 => 27,  39 => 10,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "::show_overview_settlement.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/show_overview_settlement.html.twig");
    }
}
