<?php

/* ::choose_school_settlement_date.html.twig */
class __TwigTemplate_452076a4c316aca0d2918a41e45912cc17d73b7c1fa1f8e2e8f40c62104d948e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::choose_school_settlement_date.html.twig", 1);
        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_javascripts($context, array $blocks = array())
    {
        // line 4
        echo "
    ";
        // line 5
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

";
    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        // line 10
        echo "

    <div class=\"container-fluid\">

        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Wybierz okres rozliczenia
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Lista kursów
                </li>
            </ol>
        </div>


        ";
        // line 35
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
        echo "
        <table class=\"centered-table\">
            <tr>
                <th class=\"td-right-padding\">";
        // line 38
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? null), "year", array()), 'label');
        echo "</th>
                <th>";
        // line 39
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? null), "month", array()), 'label');
        echo "</th>
            </tr>
            <tr>
                <td class=\"td-right-padding\">";
        // line 42
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? null), "year", array()), 'widget', array("value" => twig_date_format_filter($this->env, "now", "Y")));
        echo "</td>
                <td>";
        // line 43
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? null), "month", array()), 'widget', array("value" => twig_date_format_filter($this->env, "now", "m")));
        echo "</td>
            </tr>
            <tr>
               <td>";
        // line 46
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? null), "month", array()), 'widget', array("value" => twig_date_format_filter($this->env, "now", "m")));
        echo "</td>
            </tr>
            <tr>
                <td colspan=\"2\" class=\"text-center\">";
        // line 49
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? null), "teacherId", array()), 'label');
        echo "</td>
            </tr>
            <tr>
                <td colspan=\"2\" class=\"text-center\">";
        // line 52
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? null), "teacherId", array()), 'widget');
        echo "</td>
            </tr>
            <tr>
                <td colspan=\"2\" class=\"text-center\">";
        // line 55
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? null), "submit", array()), 'widget');
        echo "</td>
            </tr>

        </table>



        ";
        // line 62
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        echo "

    </div>

";
    }

    public function getTemplateName()
    {
        return "::choose_school_settlement_date.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  126 => 62,  116 => 55,  110 => 52,  104 => 49,  98 => 46,  92 => 43,  88 => 42,  82 => 39,  78 => 38,  72 => 35,  45 => 10,  42 => 9,  35 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "::choose_school_settlement_date.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/choose_school_settlement_date.html.twig");
    }
}
