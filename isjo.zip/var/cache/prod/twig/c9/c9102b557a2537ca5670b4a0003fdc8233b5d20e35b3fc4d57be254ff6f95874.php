<?php

/* ::index_school.html.twig */
class __TwigTemplate_ba4b580610c8ae9e97b6fe5dd52b8e9778512721e5f2fac006b99ff3e01c9f87 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::index_school.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        echo "
    <!-- Page Heading -->
    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h2>
                Podsumowanie
            </h2>

            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"jumbotron jumbotron-fluid jumbotron-low\">
        <div class=\"container\">
            <h1 class=\"display-4\">Szkoła ";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "user", array()), "name", array()), "html", null, true);
        echo "</h1>
            <p class=\"lead\">Liczba nauczycieli: <b>";
        // line 24
        echo twig_escape_filter($this->env, ($context["teacherNo"] ?? null), "html", null, true);
        echo "</b>. Lczba kursów: <b>";
        echo twig_escape_filter($this->env, ($context["courseNo"] ?? null), "html", null, true);
        echo "</b>.</p>
        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "::index_school.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 24,  51 => 23,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "::index_school.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/index_school.html.twig");
    }
}
