<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_f546d053e6bfd35bee3b00ba03ca5591b4cc772bcf8f28821eb96f22488d6c3e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c277be9da466caf0b1253236a754aa2d03275a1414a03a79481e8db8fb8ed7cb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c277be9da466caf0b1253236a754aa2d03275a1414a03a79481e8db8fb8ed7cb->enter($__internal_c277be9da466caf0b1253236a754aa2d03275a1414a03a79481e8db8fb8ed7cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        $__internal_43b72e0d7df4bad00edf030137bd6e30f23d81d43c9fb014d80b8e81a1b10001 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_43b72e0d7df4bad00edf030137bd6e30f23d81d43c9fb014d80b8e81a1b10001->enter($__internal_43b72e0d7df4bad00edf030137bd6e30f23d81d43c9fb014d80b8e81a1b10001_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_c277be9da466caf0b1253236a754aa2d03275a1414a03a79481e8db8fb8ed7cb->leave($__internal_c277be9da466caf0b1253236a754aa2d03275a1414a03a79481e8db8fb8ed7cb_prof);

        
        $__internal_43b72e0d7df4bad00edf030137bd6e30f23d81d43c9fb014d80b8e81a1b10001->leave($__internal_43b72e0d7df4bad00edf030137bd6e30f23d81d43c9fb014d80b8e81a1b10001_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
", "@Framework/Form/url_widget.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/url_widget.html.php");
    }
}
