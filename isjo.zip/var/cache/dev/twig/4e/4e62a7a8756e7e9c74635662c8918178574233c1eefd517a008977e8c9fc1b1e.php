<?php

/* ::show_teacher_courses.html.twig */
class __TwigTemplate_9681debaaf631e3307ee4ce0ce3f3f6ad1633053485c1869bd870742aef105db extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::show_teacher_courses.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0c28139b1772ba8f41941f3525e7adf5981a42368a42cc3b0b814cc8a0766da2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0c28139b1772ba8f41941f3525e7adf5981a42368a42cc3b0b814cc8a0766da2->enter($__internal_0c28139b1772ba8f41941f3525e7adf5981a42368a42cc3b0b814cc8a0766da2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::show_teacher_courses.html.twig"));

        $__internal_ce71a5810566b3acaf7eae2fc46847b5d56e8f75c8a273d436eedfdd2395fd2c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce71a5810566b3acaf7eae2fc46847b5d56e8f75c8a273d436eedfdd2395fd2c->enter($__internal_ce71a5810566b3acaf7eae2fc46847b5d56e8f75c8a273d436eedfdd2395fd2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::show_teacher_courses.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0c28139b1772ba8f41941f3525e7adf5981a42368a42cc3b0b814cc8a0766da2->leave($__internal_0c28139b1772ba8f41941f3525e7adf5981a42368a42cc3b0b814cc8a0766da2_prof);

        
        $__internal_ce71a5810566b3acaf7eae2fc46847b5d56e8f75c8a273d436eedfdd2395fd2c->leave($__internal_ce71a5810566b3acaf7eae2fc46847b5d56e8f75c8a273d436eedfdd2395fd2c_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_529a3e1e0dfb70c70ada2c95a6d807a65dfcb58f255244cf884a42e983687ba9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_529a3e1e0dfb70c70ada2c95a6d807a65dfcb58f255244cf884a42e983687ba9->enter($__internal_529a3e1e0dfb70c70ada2c95a6d807a65dfcb58f255244cf884a42e983687ba9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_8d540e7c8367a2d5a58a8ed9cc5b4a07c6f03f36b9e5719b261311bbf12eaa75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d540e7c8367a2d5a58a8ed9cc5b4a07c6f03f36b9e5719b261311bbf12eaa75->enter($__internal_8d540e7c8367a2d5a58a8ed9cc5b4a07c6f03f36b9e5719b261311bbf12eaa75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <div class=\"container-fluid\">

        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-12\">
                <h2>
                    Moje kursy
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Moje kursy
                </li>
            </ol>
        </div>
    </div>

    <div class=\"row\">
        <div class=\"col-lg-12\">
            <table class=\"table\">
                <thead class=\"thead\">
                <tr>
                    <th>L.p.</th>
                    <th>Nazwa kursu</th>
                    <th>Kod</th>
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>

                ";
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["courses"] ?? $this->getContext($context, "courses")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 44
            echo "                    <tr>
                        <td>";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "courseName", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "id", array()), "html", null, true);
            echo "</td>
                        <td><a href=\" ";
            // line 48
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("show_lessons", array("id" => $this->getAttribute($context["element"], "id", array()))), "html", null, true);
            echo "\">
                                <button type=\"button\" class=\"btn btn-info\">Zobacz lekcje</button>
                            </a></td>
                        <td><a href=\" ";
            // line 51
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_teacher_lesson_course", array("id" => $this->getAttribute($context["element"], "id", array()))), "html", null, true);
            echo "\">
                                <button type=\"button\" class=\"btn btn-warning\">Dodaj lekcje</button>
                            </a></td>

                    </tr>
                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        echo "                </tbody>
            </table>
        </div>
    </div>
    </div>


";
        
        $__internal_8d540e7c8367a2d5a58a8ed9cc5b4a07c6f03f36b9e5719b261311bbf12eaa75->leave($__internal_8d540e7c8367a2d5a58a8ed9cc5b4a07c6f03f36b9e5719b261311bbf12eaa75_prof);

        
        $__internal_529a3e1e0dfb70c70ada2c95a6d807a65dfcb58f255244cf884a42e983687ba9->leave($__internal_529a3e1e0dfb70c70ada2c95a6d807a65dfcb58f255244cf884a42e983687ba9_prof);

    }

    public function getTemplateName()
    {
        return "::show_teacher_courses.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 57,  127 => 51,  121 => 48,  117 => 47,  113 => 46,  109 => 45,  106 => 44,  89 => 43,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

    <div class=\"container-fluid\">

        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-12\">
                <h2>
                    Moje kursy
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Moje kursy
                </li>
            </ol>
        </div>
    </div>

    <div class=\"row\">
        <div class=\"col-lg-12\">
            <table class=\"table\">
                <thead class=\"thead\">
                <tr>
                    <th>L.p.</th>
                    <th>Nazwa kursu</th>
                    <th>Kod</th>
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>

                {% for element in courses %}
                    <tr>
                        <td>{{ loop.index }}</td>
                        <td>{{ element.courseName }}</td>
                        <td>{{ element.id }}</td>
                        <td><a href=\" {{ path('show_lessons', {'id' : element.id }) }}\">
                                <button type=\"button\" class=\"btn btn-info\">Zobacz lekcje</button>
                            </a></td>
                        <td><a href=\" {{ path('add_teacher_lesson_course', {'id' : element.id }) }}\">
                                <button type=\"button\" class=\"btn btn-warning\">Dodaj lekcje</button>
                            </a></td>

                    </tr>
                {% endfor %}
                </tbody>
            </table>
        </div>
    </div>
    </div>


{% endblock %}", "::show_teacher_courses.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/show_teacher_courses.html.twig");
    }
}
