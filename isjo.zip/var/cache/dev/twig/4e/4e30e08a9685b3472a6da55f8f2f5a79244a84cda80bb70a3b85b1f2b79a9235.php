<?php

/* @Framework/Form/widget_container_attributes.html.php */
class __TwigTemplate_12a003ec365ac59af73ac41f4e11729eed8b6469948881af7a73a04f4c213c79 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_334efffe839e5c903199e1a700c9ae4c1d691ddc8f57cf3f1dec8e199303d0d6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_334efffe839e5c903199e1a700c9ae4c1d691ddc8f57cf3f1dec8e199303d0d6->enter($__internal_334efffe839e5c903199e1a700c9ae4c1d691ddc8f57cf3f1dec8e199303d0d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        $__internal_ec57dc75248a96a48c0b6cd085ed7ac6007a203ba6cdbd6f7ca90b1f3120f5ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec57dc75248a96a48c0b6cd085ed7ac6007a203ba6cdbd6f7ca90b1f3120f5ef->enter($__internal_ec57dc75248a96a48c0b6cd085ed7ac6007a203ba6cdbd6f7ca90b1f3120f5ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        // line 1
        echo "<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_334efffe839e5c903199e1a700c9ae4c1d691ddc8f57cf3f1dec8e199303d0d6->leave($__internal_334efffe839e5c903199e1a700c9ae4c1d691ddc8f57cf3f1dec8e199303d0d6_prof);

        
        $__internal_ec57dc75248a96a48c0b6cd085ed7ac6007a203ba6cdbd6f7ca90b1f3120f5ef->leave($__internal_ec57dc75248a96a48c0b6cd085ed7ac6007a203ba6cdbd6f7ca90b1f3120f5ef_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_container_attributes.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/widget_container_attributes.html.php");
    }
}
