<?php

/* FOSUserBundle:Security:login_content.html.twig */
class __TwigTemplate_7e2e3d0ebf2c1ff8f5c1f40d02de6e749b067a70cb3ea96913492efa65713480 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_728ef60aa837f64fbc2aeb357be0868528161158ab2af3ab4ec65e19f8e5358e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_728ef60aa837f64fbc2aeb357be0868528161158ab2af3ab4ec65e19f8e5358e->enter($__internal_728ef60aa837f64fbc2aeb357be0868528161158ab2af3ab4ec65e19f8e5358e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Security:login_content.html.twig"));

        $__internal_4643d4b13ba1fa6544a7fffd99db0227037d1e8f18ceb62aeb45fe52517e2a46 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4643d4b13ba1fa6544a7fffd99db0227037d1e8f18ceb62aeb45fe52517e2a46->enter($__internal_4643d4b13ba1fa6544a7fffd99db0227037d1e8f18ceb62aeb45fe52517e2a46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Security:login_content.html.twig"));

        // line 2
        echo "
";
        // line 3
        if (($context["error"] ?? $this->getContext($context, "error"))) {
            // line 4
            echo "    <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</div>
";
        }
        // line 6
        echo "
<form action=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_check");
        echo "\" method=\"post\" class=\"form-signin\">
    ";
        // line 8
        if (($context["csrf_token"] ?? $this->getContext($context, "csrf_token"))) {
            // line 9
            echo "        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
            echo twig_escape_filter($this->env, ($context["csrf_token"] ?? $this->getContext($context, "csrf_token")), "html", null, true);
            echo "\"/>
    ";
        }
        // line 11
        echo "
    <h2 class=\"form-signin-heading\">Logowanie do iSJO</h2>
    <input type=\"text\" class=\"form-control\" placeholder=\"Nazwa użytkownika\" id=\"username\" name=\"_username\"
           value=\"";
        // line 14
        echo twig_escape_filter($this->env, ($context["last_username"] ?? $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\" autofocus=\"\"/>
    <input type=\"password\" class=\"form-control\" placeholder=\"Hasło\" id=\"password\" name=\"_password\" required=\"required\"/>

    <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
    <label for=\"remember_me\">";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Zapamiętaj mnie", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>

    <input type=\"submit\" class=\"btn btn-lg btn-success btn-block\" id=\"_submit\" name=\"_submit\" value=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Dalej", array(), "FOSUserBundle"), "html", null, true);
        echo "\"/>
    <br>
    <center><a href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_registration_register");
        echo "\">Rejestracja</a></center>
</form>
";
        
        $__internal_728ef60aa837f64fbc2aeb357be0868528161158ab2af3ab4ec65e19f8e5358e->leave($__internal_728ef60aa837f64fbc2aeb357be0868528161158ab2af3ab4ec65e19f8e5358e_prof);

        
        $__internal_4643d4b13ba1fa6544a7fffd99db0227037d1e8f18ceb62aeb45fe52517e2a46->leave($__internal_4643d4b13ba1fa6544a7fffd99db0227037d1e8f18ceb62aeb45fe52517e2a46_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Security:login_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 22,  68 => 20,  63 => 18,  56 => 14,  51 => 11,  45 => 9,  43 => 8,  39 => 7,  36 => 6,  30 => 4,  28 => 3,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

{% if error %}
    <div>{{ error.messageKey|trans(error.messageData, 'security') }}</div>
{% endif %}

<form action=\"{{ path(\"fos_user_security_check\") }}\" method=\"post\" class=\"form-signin\">
    {% if csrf_token %}
        <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\"/>
    {% endif %}

    <h2 class=\"form-signin-heading\">Logowanie do iSJO</h2>
    <input type=\"text\" class=\"form-control\" placeholder=\"Nazwa użytkownika\" id=\"username\" name=\"_username\"
           value=\"{{ last_username }}\" required=\"required\" autofocus=\"\"/>
    <input type=\"password\" class=\"form-control\" placeholder=\"Hasło\" id=\"password\" name=\"_password\" required=\"required\"/>

    <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
    <label for=\"remember_me\">{{ 'Zapamiętaj mnie'|trans }}</label>

    <input type=\"submit\" class=\"btn btn-lg btn-success btn-block\" id=\"_submit\" name=\"_submit\" value=\"{{ 'Dalej'|trans }}\"/>
    <br>
    <center><a href=\"{{ path(\"fos_user_registration_register\") }}\">Rejestracja</a></center>
</form>
", "FOSUserBundle:Security:login_content.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Security/login_content.html.twig");
    }
}
