<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_be88724ea114c13336f1029cdfbedf61c5c2cbd5487886f2a6e98785df8795ce extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_508f09bca31275c6e392df0995ff1fc4f899cf1a42c8dbcff133e930d734a26f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_508f09bca31275c6e392df0995ff1fc4f899cf1a42c8dbcff133e930d734a26f->enter($__internal_508f09bca31275c6e392df0995ff1fc4f899cf1a42c8dbcff133e930d734a26f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_55184fdba81cdc1af7221348db9eb0ea98fbb15ed9f9a6af36d68cc87725045e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_55184fdba81cdc1af7221348db9eb0ea98fbb15ed9f9a6af36d68cc87725045e->enter($__internal_55184fdba81cdc1af7221348db9eb0ea98fbb15ed9f9a6af36d68cc87725045e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_508f09bca31275c6e392df0995ff1fc4f899cf1a42c8dbcff133e930d734a26f->leave($__internal_508f09bca31275c6e392df0995ff1fc4f899cf1a42c8dbcff133e930d734a26f_prof);

        
        $__internal_55184fdba81cdc1af7221348db9eb0ea98fbb15ed9f9a6af36d68cc87725045e->leave($__internal_55184fdba81cdc1af7221348db9eb0ea98fbb15ed9f9a6af36d68cc87725045e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget.html.php");
    }
}
