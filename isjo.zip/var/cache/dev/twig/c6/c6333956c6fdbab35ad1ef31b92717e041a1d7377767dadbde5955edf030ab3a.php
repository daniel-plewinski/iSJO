<?php

/* FOSUserBundle:Profile:edit_content.html.twig */
class __TwigTemplate_f1d63105d6d777254423dcbbc45904eb4250d7ce122d6458cec19912aeda6fc6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cfd47521053a12cc22de983579fe47a8518ab2ebb9af6d0783d1412f48ac2a1d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cfd47521053a12cc22de983579fe47a8518ab2ebb9af6d0783d1412f48ac2a1d->enter($__internal_cfd47521053a12cc22de983579fe47a8518ab2ebb9af6d0783d1412f48ac2a1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit_content.html.twig"));

        $__internal_318d340709bba297ddd7ea5c27ec6462df6512fd7aa1c980d6bf25ed13f29653 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_318d340709bba297ddd7ea5c27ec6462df6512fd7aa1c980d6bf25ed13f29653->enter($__internal_318d340709bba297ddd7ea5c27ec6462df6512fd7aa1c980d6bf25ed13f29653_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit_content.html.twig"));

        // line 2
        echo "
";
        // line 3
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_cfd47521053a12cc22de983579fe47a8518ab2ebb9af6d0783d1412f48ac2a1d->leave($__internal_cfd47521053a12cc22de983579fe47a8518ab2ebb9af6d0783d1412f48ac2a1d_prof);

        
        $__internal_318d340709bba297ddd7ea5c27ec6462df6512fd7aa1c980d6bf25ed13f29653->leave($__internal_318d340709bba297ddd7ea5c27ec6462df6512fd7aa1c980d6bf25ed13f29653_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_aa008487840062570ebce0ad1e962575e6c481154835208031847161df8bb8e0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aa008487840062570ebce0ad1e962575e6c481154835208031847161df8bb8e0->enter($__internal_aa008487840062570ebce0ad1e962575e6c481154835208031847161df8bb8e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_5d75fdecb5e80bfdf5dbaa87cb9c7f3803a2c1599afb9308bcc4cb6ecea48924 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5d75fdecb5e80bfdf5dbaa87cb9c7f3803a2c1599afb9308bcc4cb6ecea48924->enter($__internal_5d75fdecb5e80bfdf5dbaa87cb9c7f3803a2c1599afb9308bcc4cb6ecea48924_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_profile_edit"), "attr" => array("class" => "fos_user_profile_edit")));
        echo "
    ";
        // line 5
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
    <div>
        <input type=\"submit\" value=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("profile.edit.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "\" />
    </div>
";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

";
        
        $__internal_5d75fdecb5e80bfdf5dbaa87cb9c7f3803a2c1599afb9308bcc4cb6ecea48924->leave($__internal_5d75fdecb5e80bfdf5dbaa87cb9c7f3803a2c1599afb9308bcc4cb6ecea48924_prof);

        
        $__internal_aa008487840062570ebce0ad1e962575e6c481154835208031847161df8bb8e0->leave($__internal_aa008487840062570ebce0ad1e962575e6c481154835208031847161df8bb8e0_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:edit_content.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  61 => 9,  56 => 7,  51 => 5,  47 => 4,  29 => 3,  26 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

{% block body %}
{{ form_start(form, { 'action': path('fos_user_profile_edit'), 'attr': { 'class': 'fos_user_profile_edit' } }) }}
    {{ form_widget(form) }}
    <div>
        <input type=\"submit\" value=\"{{ 'profile.edit.submit'|trans }}\" />
    </div>
{{ form_end(form) }}

{% endblock %}
", "FOSUserBundle:Profile:edit_content.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Profile/edit_content.html.twig");
    }
}
