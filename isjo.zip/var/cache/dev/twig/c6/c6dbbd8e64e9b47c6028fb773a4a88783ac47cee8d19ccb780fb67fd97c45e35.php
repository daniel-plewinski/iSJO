<?php

/* @FOSUser/layout.html.twig */
class __TwigTemplate_2baa5fa781a2f6ec497136b750d1e23b7dc8c87cc66dcf6311eb0220ee39c6cf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4734e13aac8a2a8581b553c2d4a7486f81be254c9f4d233380fdb72c273c8f16 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4734e13aac8a2a8581b553c2d4a7486f81be254c9f4d233380fdb72c273c8f16->enter($__internal_4734e13aac8a2a8581b553c2d4a7486f81be254c9f4d233380fdb72c273c8f16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/layout.html.twig"));

        $__internal_d29dc7d63319d4682e1420af35ea834cd3b5405e7e1350b12389c7eee7c94da6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d29dc7d63319d4682e1420af35ea834cd3b5405e7e1350b12389c7eee7c94da6->enter($__internal_d29dc7d63319d4682e1420af35ea834cd3b5405e7e1350b12389c7eee7c94da6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\"/>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>iSJO</title>

    <!-- Bootstrap Core CSS -->
    <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/login-style.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\"/>

</head>
<body>
<div>
    <div class=\"wrapper\">
    <div class=\"container\">
        ";
        // line 22
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 23
            echo "            ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.logged_in_as", array("%username%" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "username", array())), "FOSUserBundle"), "html", null, true);
            echo " |
            <a href=\"";
            // line 24
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\">
                ";
            // line 25
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.logout", array(), "FOSUserBundle"), "html", null, true);
            echo "
            </a>
        ";
            // line 28
            echo "            ";
            // line 29
            echo "        ";
        }
        // line 30
        echo "    </div>

    ";
        // line 32
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "hasPreviousSession", array())) {
            // line 33
            echo "        ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "session", array()), "flashbag", array()), "all", array(), "method"));
            foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
                // line 34
                echo "            ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($context["messages"]);
                foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                    // line 35
                    echo "                <div class=\"flash-";
                    echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                    echo "\">
                    ";
                    // line 36
                    echo twig_escape_filter($this->env, $context["message"], "html", null, true);
                    echo "
                </div>
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 39
                echo "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 40
            echo "    ";
        }
        // line 41
        echo "
    <div>
        ";
        // line 43
        $this->displayBlock('fos_user_content', $context, $blocks);
        // line 45
        echo "    </div>
</div>
    <div>
</body>
</html>
";
        
        $__internal_4734e13aac8a2a8581b553c2d4a7486f81be254c9f4d233380fdb72c273c8f16->leave($__internal_4734e13aac8a2a8581b553c2d4a7486f81be254c9f4d233380fdb72c273c8f16_prof);

        
        $__internal_d29dc7d63319d4682e1420af35ea834cd3b5405e7e1350b12389c7eee7c94da6->leave($__internal_d29dc7d63319d4682e1420af35ea834cd3b5405e7e1350b12389c7eee7c94da6_prof);

    }

    // line 43
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_2d0269ed5b3af7fdc785881e8d6b59da80dca6e2dacce3b143f7dcf25fdc6ad4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2d0269ed5b3af7fdc785881e8d6b59da80dca6e2dacce3b143f7dcf25fdc6ad4->enter($__internal_2d0269ed5b3af7fdc785881e8d6b59da80dca6e2dacce3b143f7dcf25fdc6ad4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_7239bd1f05fe037e5a22a2bcd1638623585d905b53ee41ddf0410f944b240f75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7239bd1f05fe037e5a22a2bcd1638623585d905b53ee41ddf0410f944b240f75->enter($__internal_7239bd1f05fe037e5a22a2bcd1638623585d905b53ee41ddf0410f944b240f75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 44
        echo "        ";
        
        $__internal_7239bd1f05fe037e5a22a2bcd1638623585d905b53ee41ddf0410f944b240f75->leave($__internal_7239bd1f05fe037e5a22a2bcd1638623585d905b53ee41ddf0410f944b240f75_prof);

        
        $__internal_2d0269ed5b3af7fdc785881e8d6b59da80dca6e2dacce3b143f7dcf25fdc6ad4->leave($__internal_2d0269ed5b3af7fdc785881e8d6b59da80dca6e2dacce3b143f7dcf25fdc6ad4_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 44,  136 => 43,  121 => 45,  119 => 43,  115 => 41,  112 => 40,  106 => 39,  97 => 36,  92 => 35,  87 => 34,  82 => 33,  80 => 32,  76 => 30,  73 => 29,  71 => 28,  66 => 25,  62 => 24,  57 => 23,  55 => 22,  45 => 15,  41 => 14,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\"/>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>iSJO</title>

    <!-- Bootstrap Core CSS -->
    <link rel=\"stylesheet\" href=\"{{ asset('css/login-style.css') }}\"/>
    <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap.min.css') }}\"/>

</head>
<body>
<div>
    <div class=\"wrapper\">
    <div class=\"container\">
        {% if is_granted(\"IS_AUTHENTICATED_REMEMBERED\") %}
            {{ 'layout.logged_in_as'|trans({'%username%': app.user.username}, 'FOSUserBundle') }} |
            <a href=\"{{ path('fos_user_security_logout') }}\">
                {{ 'layout.logout'|trans({}, 'FOSUserBundle') }}
            </a>
        {#{% else %}#}
            {#<a href=\"{{ path('fos_user_security_login') }}\">{{ 'layout.login'|trans({}, 'FOSUserBundle') }}</a>#}
        {% endif %}
    </div>

    {% if app.request.hasPreviousSession %}
        {% for type, messages in app.session.flashbag.all() %}
            {% for message in messages %}
                <div class=\"flash-{{ type }}\">
                    {{ message }}
                </div>
            {% endfor %}
        {% endfor %}
    {% endif %}

    <div>
        {% block fos_user_content %}
        {% endblock fos_user_content %}
    </div>
</div>
    <div>
</body>
</html>
", "@FOSUser/layout.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/layout.html.twig");
    }
}
