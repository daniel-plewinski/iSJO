<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_02cc8d196102144b5ba9e88e9bf329967461ded792a646bcbe1749b8f602a144 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d33277851323b663f1db16b362aeb060f7f8b6f0f068d789fcaa483bf539421a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d33277851323b663f1db16b362aeb060f7f8b6f0f068d789fcaa483bf539421a->enter($__internal_d33277851323b663f1db16b362aeb060f7f8b6f0f068d789fcaa483bf539421a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        $__internal_a574b0732fbdfbc16449373712ccf24f51d7f6a8109c6a4cb05ace44a96d570c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a574b0732fbdfbc16449373712ccf24f51d7f6a8109c6a4cb05ace44a96d570c->enter($__internal_a574b0732fbdfbc16449373712ccf24f51d7f6a8109c6a4cb05ace44a96d570c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_d33277851323b663f1db16b362aeb060f7f8b6f0f068d789fcaa483bf539421a->leave($__internal_d33277851323b663f1db16b362aeb060f7f8b6f0f068d789fcaa483bf539421a_prof);

        
        $__internal_a574b0732fbdfbc16449373712ccf24f51d7f6a8109c6a4cb05ace44a96d570c->leave($__internal_a574b0732fbdfbc16449373712ccf24f51d7f6a8109c6a4cb05ace44a96d570c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/repeated_row.html.php");
    }
}
