<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_fa32852b1343926b4d93600308ba9014f06bbd2ec9dc5bfae7ceb28a2d89f71e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2c702ef4926f8e8497ac2572d08c54982ed95d816636a0a79aeea10710edd674 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2c702ef4926f8e8497ac2572d08c54982ed95d816636a0a79aeea10710edd674->enter($__internal_2c702ef4926f8e8497ac2572d08c54982ed95d816636a0a79aeea10710edd674_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        $__internal_da0c5eae52975c640a78277b7c4e4428506c249759079e81c5707f8adb1f84bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da0c5eae52975c640a78277b7c4e4428506c249759079e81c5707f8adb1f84bd->enter($__internal_da0c5eae52975c640a78277b7c4e4428506c249759079e81c5707f8adb1f84bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_2c702ef4926f8e8497ac2572d08c54982ed95d816636a0a79aeea10710edd674->leave($__internal_2c702ef4926f8e8497ac2572d08c54982ed95d816636a0a79aeea10710edd674_prof);

        
        $__internal_da0c5eae52975c640a78277b7c4e4428506c249759079e81c5707f8adb1f84bd->leave($__internal_da0c5eae52975c640a78277b7c4e4428506c249759079e81c5707f8adb1f84bd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
", "@Framework/Form/number_widget.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/number_widget.html.php");
    }
}
