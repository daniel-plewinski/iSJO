<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_c9a354b3fe93a17f548437df8d331e35f8115d0dba4c9a2fccdd997a68352ce7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e1d167e6e19aa85162fa555ac7f11c5b08c7731f7cf18f8b72e3c086deee3eee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e1d167e6e19aa85162fa555ac7f11c5b08c7731f7cf18f8b72e3c086deee3eee->enter($__internal_e1d167e6e19aa85162fa555ac7f11c5b08c7731f7cf18f8b72e3c086deee3eee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        $__internal_45ad257a5ee3a55c6bf6a912a9f613159c3f973ae6db0d7d6ca729ade5cb73a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45ad257a5ee3a55c6bf6a912a9f613159c3f973ae6db0d7d6ca729ade5cb73a8->enter($__internal_45ad257a5ee3a55c6bf6a912a9f613159c3f973ae6db0d7d6ca729ade5cb73a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_e1d167e6e19aa85162fa555ac7f11c5b08c7731f7cf18f8b72e3c086deee3eee->leave($__internal_e1d167e6e19aa85162fa555ac7f11c5b08c7731f7cf18f8b72e3c086deee3eee_prof);

        
        $__internal_45ad257a5ee3a55c6bf6a912a9f613159c3f973ae6db0d7d6ca729ade5cb73a8->leave($__internal_45ad257a5ee3a55c6bf6a912a9f613159c3f973ae6db0d7d6ca729ade5cb73a8_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.js.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.js.twig");
    }
}
