<?php

/* FOSUserBundle:Group:show.html.twig */
class __TwigTemplate_f0b30d302f7c125993dc49af44bafa4c014b9fe92b113ddfca932b723a3c465e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ea38dfd0e762ca78464af4eb8cad1f8932f2b076e44074178d39d894eec8d261 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ea38dfd0e762ca78464af4eb8cad1f8932f2b076e44074178d39d894eec8d261->enter($__internal_ea38dfd0e762ca78464af4eb8cad1f8932f2b076e44074178d39d894eec8d261_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $__internal_b88cb5c1eda01ad0dbe71c06905e0481a61e38b5e946c22ab88f8189215f26f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b88cb5c1eda01ad0dbe71c06905e0481a61e38b5e946c22ab88f8189215f26f1->enter($__internal_b88cb5c1eda01ad0dbe71c06905e0481a61e38b5e946c22ab88f8189215f26f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ea38dfd0e762ca78464af4eb8cad1f8932f2b076e44074178d39d894eec8d261->leave($__internal_ea38dfd0e762ca78464af4eb8cad1f8932f2b076e44074178d39d894eec8d261_prof);

        
        $__internal_b88cb5c1eda01ad0dbe71c06905e0481a61e38b5e946c22ab88f8189215f26f1->leave($__internal_b88cb5c1eda01ad0dbe71c06905e0481a61e38b5e946c22ab88f8189215f26f1_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_a93c7f23eb30a9262ba618e6643f44c85bc875cf11f4a4bb47465ff789a0bba9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a93c7f23eb30a9262ba618e6643f44c85bc875cf11f4a4bb47465ff789a0bba9->enter($__internal_a93c7f23eb30a9262ba618e6643f44c85bc875cf11f4a4bb47465ff789a0bba9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_43eb14f4ee1c4f53e55a7ae7c58d90c5de3cb4ebc2eb03fb728debc35dddbb30 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_43eb14f4ee1c4f53e55a7ae7c58d90c5de3cb4ebc2eb03fb728debc35dddbb30->enter($__internal_43eb14f4ee1c4f53e55a7ae7c58d90c5de3cb4ebc2eb03fb728debc35dddbb30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/show_content.html.twig", "FOSUserBundle:Group:show.html.twig", 4)->display($context);
        
        $__internal_43eb14f4ee1c4f53e55a7ae7c58d90c5de3cb4ebc2eb03fb728debc35dddbb30->leave($__internal_43eb14f4ee1c4f53e55a7ae7c58d90c5de3cb4ebc2eb03fb728debc35dddbb30_prof);

        
        $__internal_a93c7f23eb30a9262ba618e6643f44c85bc875cf11f4a4bb47465ff789a0bba9->leave($__internal_a93c7f23eb30a9262ba618e6643f44c85bc875cf11f4a4bb47465ff789a0bba9_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/show_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:show.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Group/show.html.twig");
    }
}
