<?php

/* FOSUserBundle:Resetting:request_content.html.twig */
class __TwigTemplate_ff7f67070671f8b80fc83750c56e77dcb9ae4676da5df65985d09547868d415e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_54ea781805a7c513708b4b4dcbf0d0be5ae0b8582a882507b7bc8d25bda9aa50 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_54ea781805a7c513708b4b4dcbf0d0be5ae0b8582a882507b7bc8d25bda9aa50->enter($__internal_54ea781805a7c513708b4b4dcbf0d0be5ae0b8582a882507b7bc8d25bda9aa50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request_content.html.twig"));

        $__internal_b3179d935d8b7bdffd13d6bdf50dadc0df696a7c39ec160fabbfbe2db453e4e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3179d935d8b7bdffd13d6bdf50dadc0df696a7c39ec160fabbfbe2db453e4e4->enter($__internal_b3179d935d8b7bdffd13d6bdf50dadc0df696a7c39ec160fabbfbe2db453e4e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request_content.html.twig"));

        // line 2
        echo "
<form action=\"";
        // line 3
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_resetting_send_email");
        echo "\" method=\"POST\" class=\"fos_user_resetting_request\">
    <div>
        <label for=\"username\">";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.request.username", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
        <input type=\"text\" id=\"username\" name=\"username\" required=\"required\" />
    </div>
    <div>
        <input type=\"submit\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.request.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "\" />
    </div>
</form>
";
        
        $__internal_54ea781805a7c513708b4b4dcbf0d0be5ae0b8582a882507b7bc8d25bda9aa50->leave($__internal_54ea781805a7c513708b4b4dcbf0d0be5ae0b8582a882507b7bc8d25bda9aa50_prof);

        
        $__internal_b3179d935d8b7bdffd13d6bdf50dadc0df696a7c39ec160fabbfbe2db453e4e4->leave($__internal_b3179d935d8b7bdffd13d6bdf50dadc0df696a7c39ec160fabbfbe2db453e4e4_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 9,  33 => 5,  28 => 3,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<form action=\"{{ path('fos_user_resetting_send_email') }}\" method=\"POST\" class=\"fos_user_resetting_request\">
    <div>
        <label for=\"username\">{{ 'resetting.request.username'|trans }}</label>
        <input type=\"text\" id=\"username\" name=\"username\" required=\"required\" />
    </div>
    <div>
        <input type=\"submit\" value=\"{{ 'resetting.request.submit'|trans }}\" />
    </div>
</form>
", "FOSUserBundle:Resetting:request_content.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Resetting/request_content.html.twig");
    }
}
