<?php

/* @Twig/images/icon-minus-square.svg */
class __TwigTemplate_a11b50184c9e1d8e9a301213c4d0fb422c44dbc2506d7e491f6232d2dd8a9ce5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8c96e02d3ce04583cc6a1e6c0dc7c57525c89cc988efece0e5624e04b9ce63f4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8c96e02d3ce04583cc6a1e6c0dc7c57525c89cc988efece0e5624e04b9ce63f4->enter($__internal_8c96e02d3ce04583cc6a1e6c0dc7c57525c89cc988efece0e5624e04b9ce63f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        $__internal_01034fa78538ce526ec09aead2f723ba4bf69ab94434e19404e999a2acba6936 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_01034fa78538ce526ec09aead2f723ba4bf69ab94434e19404e999a2acba6936->enter($__internal_01034fa78538ce526ec09aead2f723ba4bf69ab94434e19404e999a2acba6936_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
";
        
        $__internal_8c96e02d3ce04583cc6a1e6c0dc7c57525c89cc988efece0e5624e04b9ce63f4->leave($__internal_8c96e02d3ce04583cc6a1e6c0dc7c57525c89cc988efece0e5624e04b9ce63f4_prof);

        
        $__internal_01034fa78538ce526ec09aead2f723ba4bf69ab94434e19404e999a2acba6936->leave($__internal_01034fa78538ce526ec09aead2f723ba4bf69ab94434e19404e999a2acba6936_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-minus-square.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
", "@Twig/images/icon-minus-square.svg", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/icon-minus-square.svg");
    }
}
