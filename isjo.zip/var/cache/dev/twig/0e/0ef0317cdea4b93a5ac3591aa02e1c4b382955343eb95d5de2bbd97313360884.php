<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_1e01e5ddc3103215317c4117db74c7219da776651af86e92bd6a121a978c7476 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13f3e4376c2d4d13acaa06c82a6d7ddd9b6ed7d84da1431642806398abe06b22 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_13f3e4376c2d4d13acaa06c82a6d7ddd9b6ed7d84da1431642806398abe06b22->enter($__internal_13f3e4376c2d4d13acaa06c82a6d7ddd9b6ed7d84da1431642806398abe06b22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_86265f1486f7d6eeb613312ac271a4f66214f9ef63b59f4f6f4d3c784f08da9e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_86265f1486f7d6eeb613312ac271a4f66214f9ef63b59f4f6f4d3c784f08da9e->enter($__internal_86265f1486f7d6eeb613312ac271a4f66214f9ef63b59f4f6f4d3c784f08da9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_13f3e4376c2d4d13acaa06c82a6d7ddd9b6ed7d84da1431642806398abe06b22->leave($__internal_13f3e4376c2d4d13acaa06c82a6d7ddd9b6ed7d84da1431642806398abe06b22_prof);

        
        $__internal_86265f1486f7d6eeb613312ac271a4f66214f9ef63b59f4f6f4d3c784f08da9e->leave($__internal_86265f1486f7d6eeb613312ac271a4f66214f9ef63b59f4f6f4d3c784f08da9e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/button_row.html.php");
    }
}
