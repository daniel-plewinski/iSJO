<?php

/* FOSUserBundle:Group:edit.html.twig */
class __TwigTemplate_4e1cf49fdbbf85f91f6f9d05345977f3b82590e12a8632f01ff76d500435919d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c3c5c0abfd03a828b6d7bd80ca0ab1760863134d5ad7577b2dace0f3aafb36b0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c3c5c0abfd03a828b6d7bd80ca0ab1760863134d5ad7577b2dace0f3aafb36b0->enter($__internal_c3c5c0abfd03a828b6d7bd80ca0ab1760863134d5ad7577b2dace0f3aafb36b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $__internal_8cc30138fc3f0c3864942b6f36d54a8d9f003744050613966d6ac92b664afd45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8cc30138fc3f0c3864942b6f36d54a8d9f003744050613966d6ac92b664afd45->enter($__internal_8cc30138fc3f0c3864942b6f36d54a8d9f003744050613966d6ac92b664afd45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c3c5c0abfd03a828b6d7bd80ca0ab1760863134d5ad7577b2dace0f3aafb36b0->leave($__internal_c3c5c0abfd03a828b6d7bd80ca0ab1760863134d5ad7577b2dace0f3aafb36b0_prof);

        
        $__internal_8cc30138fc3f0c3864942b6f36d54a8d9f003744050613966d6ac92b664afd45->leave($__internal_8cc30138fc3f0c3864942b6f36d54a8d9f003744050613966d6ac92b664afd45_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_98abad23fdce067a0f182cde74fab673b89bffadeaacbee16c3f52abaf22be37 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_98abad23fdce067a0f182cde74fab673b89bffadeaacbee16c3f52abaf22be37->enter($__internal_98abad23fdce067a0f182cde74fab673b89bffadeaacbee16c3f52abaf22be37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_a676cf1f93c31dc02b37a9b86302b447916b01b47a98b366fd04c119118e75ec = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a676cf1f93c31dc02b37a9b86302b447916b01b47a98b366fd04c119118e75ec->enter($__internal_a676cf1f93c31dc02b37a9b86302b447916b01b47a98b366fd04c119118e75ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/edit_content.html.twig", "FOSUserBundle:Group:edit.html.twig", 4)->display($context);
        
        $__internal_a676cf1f93c31dc02b37a9b86302b447916b01b47a98b366fd04c119118e75ec->leave($__internal_a676cf1f93c31dc02b37a9b86302b447916b01b47a98b366fd04c119118e75ec_prof);

        
        $__internal_98abad23fdce067a0f182cde74fab673b89bffadeaacbee16c3f52abaf22be37->leave($__internal_98abad23fdce067a0f182cde74fab673b89bffadeaacbee16c3f52abaf22be37_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/edit_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:edit.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Group/edit.html.twig");
    }
}
