<?php

/* FOSUserBundle:Profile:show_content.html.twig */
class __TwigTemplate_e91006b6f04da03e67d006922d0dd1ca4521a7986e27f6a360d8116b1d33ee2d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f8b9ceb65aab13f23937aa4d5117167845704fab5916752c6bace8c5211b0f6d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f8b9ceb65aab13f23937aa4d5117167845704fab5916752c6bace8c5211b0f6d->enter($__internal_f8b9ceb65aab13f23937aa4d5117167845704fab5916752c6bace8c5211b0f6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show_content.html.twig"));

        $__internal_f805f486f5145a4ea20f5445911b141d28858a5ac46483307d1695f3831a6d28 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f805f486f5145a4ea20f5445911b141d28858a5ac46483307d1695f3831a6d28->enter($__internal_f805f486f5145a4ea20f5445911b141d28858a5ac46483307d1695f3831a6d28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show_content.html.twig"));

        // line 2
        echo "
<div class=\"fos_user_user_show\">
    <p>";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("profile.show.username", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array()), "html", null, true);
        echo "</p>
    <p>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("profile.show.email", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "</p>
</div>
";
        
        $__internal_f8b9ceb65aab13f23937aa4d5117167845704fab5916752c6bace8c5211b0f6d->leave($__internal_f8b9ceb65aab13f23937aa4d5117167845704fab5916752c6bace8c5211b0f6d_prof);

        
        $__internal_f805f486f5145a4ea20f5445911b141d28858a5ac46483307d1695f3831a6d28->leave($__internal_f805f486f5145a4ea20f5445911b141d28858a5ac46483307d1695f3831a6d28_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  35 => 5,  29 => 4,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<div class=\"fos_user_user_show\">
    <p>{{ 'profile.show.username'|trans }}: {{ user.username }}</p>
    <p>{{ 'profile.show.email'|trans }}: {{ user.email }}</p>
</div>
", "FOSUserBundle:Profile:show_content.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Profile/show_content.html.twig");
    }
}
