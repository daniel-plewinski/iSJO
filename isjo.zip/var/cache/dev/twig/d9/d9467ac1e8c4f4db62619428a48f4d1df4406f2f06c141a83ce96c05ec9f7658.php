<?php

/* bootstrap_3_horizontal_layout.html.twig */
class __TwigTemplate_00597d35b16b8a8a81e112bd3b27f54f1e7fce1f567e14f699da9b661f5ee983 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("bootstrap_3_layout.html.twig", "bootstrap_3_horizontal_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."bootstrap_3_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'form_start' => array($this, 'block_form_start'),
                'form_label' => array($this, 'block_form_label'),
                'form_label_class' => array($this, 'block_form_label_class'),
                'form_row' => array($this, 'block_form_row'),
                'checkbox_row' => array($this, 'block_checkbox_row'),
                'radio_row' => array($this, 'block_radio_row'),
                'checkbox_radio_row' => array($this, 'block_checkbox_radio_row'),
                'submit_row' => array($this, 'block_submit_row'),
                'reset_row' => array($this, 'block_reset_row'),
                'form_group_class' => array($this, 'block_form_group_class'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_14e3f2e84774745210e24fcb404e193a8ccfa779e887ee29dec77403d53bd4c3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_14e3f2e84774745210e24fcb404e193a8ccfa779e887ee29dec77403d53bd4c3->enter($__internal_14e3f2e84774745210e24fcb404e193a8ccfa779e887ee29dec77403d53bd4c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_horizontal_layout.html.twig"));

        $__internal_12a1a8a306950f73b0dea97e23154dcaa60b7d5cbdd7d6e35aa834771818de3e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_12a1a8a306950f73b0dea97e23154dcaa60b7d5cbdd7d6e35aa834771818de3e->enter($__internal_12a1a8a306950f73b0dea97e23154dcaa60b7d5cbdd7d6e35aa834771818de3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_horizontal_layout.html.twig"));

        // line 2
        echo "
";
        // line 3
        $this->displayBlock('form_start', $context, $blocks);
        // line 7
        echo "
";
        // line 9
        echo "
";
        // line 10
        $this->displayBlock('form_label', $context, $blocks);
        // line 20
        echo "
";
        // line 21
        $this->displayBlock('form_label_class', $context, $blocks);
        // line 24
        echo "
";
        // line 26
        echo "
";
        // line 27
        $this->displayBlock('form_row', $context, $blocks);
        // line 36
        echo "
";
        // line 37
        $this->displayBlock('checkbox_row', $context, $blocks);
        // line 40
        echo "
";
        // line 41
        $this->displayBlock('radio_row', $context, $blocks);
        // line 44
        echo "
";
        // line 45
        $this->displayBlock('checkbox_radio_row', $context, $blocks);
        // line 56
        echo "
";
        // line 57
        $this->displayBlock('submit_row', $context, $blocks);
        // line 67
        echo "
";
        // line 68
        $this->displayBlock('reset_row', $context, $blocks);
        // line 78
        echo "
";
        // line 79
        $this->displayBlock('form_group_class', $context, $blocks);
        
        $__internal_14e3f2e84774745210e24fcb404e193a8ccfa779e887ee29dec77403d53bd4c3->leave($__internal_14e3f2e84774745210e24fcb404e193a8ccfa779e887ee29dec77403d53bd4c3_prof);

        
        $__internal_12a1a8a306950f73b0dea97e23154dcaa60b7d5cbdd7d6e35aa834771818de3e->leave($__internal_12a1a8a306950f73b0dea97e23154dcaa60b7d5cbdd7d6e35aa834771818de3e_prof);

    }

    // line 3
    public function block_form_start($context, array $blocks = array())
    {
        $__internal_c2b649a654259c6aea2b2d2d57c400fff875f769b993913d9cc39ec7e3f05416 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c2b649a654259c6aea2b2d2d57c400fff875f769b993913d9cc39ec7e3f05416->enter($__internal_c2b649a654259c6aea2b2d2d57c400fff875f769b993913d9cc39ec7e3f05416_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_start"));

        $__internal_36da43f6ec3b03925305a1bebc8f80b37f3640b991ed3bdac4eec27e65d1391a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36da43f6ec3b03925305a1bebc8f80b37f3640b991ed3bdac4eec27e65d1391a->enter($__internal_36da43f6ec3b03925305a1bebc8f80b37f3640b991ed3bdac4eec27e65d1391a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_start"));

        // line 4
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-horizontal"))));
        // line 5
        $this->displayParentBlock("form_start", $context, $blocks);
        
        $__internal_36da43f6ec3b03925305a1bebc8f80b37f3640b991ed3bdac4eec27e65d1391a->leave($__internal_36da43f6ec3b03925305a1bebc8f80b37f3640b991ed3bdac4eec27e65d1391a_prof);

        
        $__internal_c2b649a654259c6aea2b2d2d57c400fff875f769b993913d9cc39ec7e3f05416->leave($__internal_c2b649a654259c6aea2b2d2d57c400fff875f769b993913d9cc39ec7e3f05416_prof);

    }

    // line 10
    public function block_form_label($context, array $blocks = array())
    {
        $__internal_0d8cb800dbd9d1bd6baa5180ec594fb4546f4d490f32daa24f49069544dd057d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0d8cb800dbd9d1bd6baa5180ec594fb4546f4d490f32daa24f49069544dd057d->enter($__internal_0d8cb800dbd9d1bd6baa5180ec594fb4546f4d490f32daa24f49069544dd057d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        $__internal_d891b503115cdf8b7a5f43a77cef6859832b4562bcd85fdd1de6d48563620233 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d891b503115cdf8b7a5f43a77cef6859832b4562bcd85fdd1de6d48563620233->enter($__internal_d891b503115cdf8b7a5f43a77cef6859832b4562bcd85fdd1de6d48563620233_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        // line 11
        ob_start();
        // line 12
        echo "    ";
        if ((($context["label"] ?? $this->getContext($context, "label")) === false)) {
            // line 13
            echo "        <div class=\"";
            $this->displayBlock("form_label_class", $context, $blocks);
            echo "\"></div>
    ";
        } else {
            // line 15
            echo "        ";
            $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " ") .             $this->renderBlock("form_label_class", $context, $blocks)))));
            // line 16
            $this->displayParentBlock("form_label", $context, $blocks);
        }
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_d891b503115cdf8b7a5f43a77cef6859832b4562bcd85fdd1de6d48563620233->leave($__internal_d891b503115cdf8b7a5f43a77cef6859832b4562bcd85fdd1de6d48563620233_prof);

        
        $__internal_0d8cb800dbd9d1bd6baa5180ec594fb4546f4d490f32daa24f49069544dd057d->leave($__internal_0d8cb800dbd9d1bd6baa5180ec594fb4546f4d490f32daa24f49069544dd057d_prof);

    }

    // line 21
    public function block_form_label_class($context, array $blocks = array())
    {
        $__internal_701380ef32add0cc894745b0b45bf64f0f90d58aa1c660728a636559b6548cba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_701380ef32add0cc894745b0b45bf64f0f90d58aa1c660728a636559b6548cba->enter($__internal_701380ef32add0cc894745b0b45bf64f0f90d58aa1c660728a636559b6548cba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label_class"));

        $__internal_1a4f7a89ccb7f3d9a8e69f135d594377dc547d42f1bd60f59c45cf1cfe5ff0e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a4f7a89ccb7f3d9a8e69f135d594377dc547d42f1bd60f59c45cf1cfe5ff0e3->enter($__internal_1a4f7a89ccb7f3d9a8e69f135d594377dc547d42f1bd60f59c45cf1cfe5ff0e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label_class"));

        // line 22
        echo "col-sm-2";
        
        $__internal_1a4f7a89ccb7f3d9a8e69f135d594377dc547d42f1bd60f59c45cf1cfe5ff0e3->leave($__internal_1a4f7a89ccb7f3d9a8e69f135d594377dc547d42f1bd60f59c45cf1cfe5ff0e3_prof);

        
        $__internal_701380ef32add0cc894745b0b45bf64f0f90d58aa1c660728a636559b6548cba->leave($__internal_701380ef32add0cc894745b0b45bf64f0f90d58aa1c660728a636559b6548cba_prof);

    }

    // line 27
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_64fcd4979e019933742e45fd89a3179ab1938fe9eb50467b5330eb8deeaa985a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_64fcd4979e019933742e45fd89a3179ab1938fe9eb50467b5330eb8deeaa985a->enter($__internal_64fcd4979e019933742e45fd89a3179ab1938fe9eb50467b5330eb8deeaa985a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_2dfe8b21befce08cfaad883d42b2323a96a36fd44d0b6750b295cb0984a50e35 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2dfe8b21befce08cfaad883d42b2323a96a36fd44d0b6750b295cb0984a50e35->enter($__internal_2dfe8b21befce08cfaad883d42b2323a96a36fd44d0b6750b295cb0984a50e35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 28
        echo "<div class=\"form-group";
        if ((( !($context["compound"] ?? $this->getContext($context, "compound")) || ((array_key_exists("force_error", $context)) ? (_twig_default_filter(($context["force_error"] ?? $this->getContext($context, "force_error")), false)) : (false))) &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            echo " has-error";
        }
        echo "\">";
        // line 29
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 30
        echo "<div class=\"";
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">";
        // line 31
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 32
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 33
        echo "</div>
";
        // line 34
        echo "</div>";
        
        $__internal_2dfe8b21befce08cfaad883d42b2323a96a36fd44d0b6750b295cb0984a50e35->leave($__internal_2dfe8b21befce08cfaad883d42b2323a96a36fd44d0b6750b295cb0984a50e35_prof);

        
        $__internal_64fcd4979e019933742e45fd89a3179ab1938fe9eb50467b5330eb8deeaa985a->leave($__internal_64fcd4979e019933742e45fd89a3179ab1938fe9eb50467b5330eb8deeaa985a_prof);

    }

    // line 37
    public function block_checkbox_row($context, array $blocks = array())
    {
        $__internal_55e610652fd0b7f23f940a5bf4188efb7c11b8b53560fb0c763a24e09326a7b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_55e610652fd0b7f23f940a5bf4188efb7c11b8b53560fb0c763a24e09326a7b9->enter($__internal_55e610652fd0b7f23f940a5bf4188efb7c11b8b53560fb0c763a24e09326a7b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        $__internal_8ed270bfa814ec69176082ae0ebda9ce386b76b7353276d7d508e1a7fd06a402 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ed270bfa814ec69176082ae0ebda9ce386b76b7353276d7d508e1a7fd06a402->enter($__internal_8ed270bfa814ec69176082ae0ebda9ce386b76b7353276d7d508e1a7fd06a402_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        // line 38
        $this->displayBlock("checkbox_radio_row", $context, $blocks);
        
        $__internal_8ed270bfa814ec69176082ae0ebda9ce386b76b7353276d7d508e1a7fd06a402->leave($__internal_8ed270bfa814ec69176082ae0ebda9ce386b76b7353276d7d508e1a7fd06a402_prof);

        
        $__internal_55e610652fd0b7f23f940a5bf4188efb7c11b8b53560fb0c763a24e09326a7b9->leave($__internal_55e610652fd0b7f23f940a5bf4188efb7c11b8b53560fb0c763a24e09326a7b9_prof);

    }

    // line 41
    public function block_radio_row($context, array $blocks = array())
    {
        $__internal_cc7a29747019981e4c53dd912d104cc8fa3c30cd722b156c5106e30a71cb6a7c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cc7a29747019981e4c53dd912d104cc8fa3c30cd722b156c5106e30a71cb6a7c->enter($__internal_cc7a29747019981e4c53dd912d104cc8fa3c30cd722b156c5106e30a71cb6a7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        $__internal_b61279cc872aa74b57da03e8968272caaf10f2d2e84f9f0126eae23079a41724 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b61279cc872aa74b57da03e8968272caaf10f2d2e84f9f0126eae23079a41724->enter($__internal_b61279cc872aa74b57da03e8968272caaf10f2d2e84f9f0126eae23079a41724_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        // line 42
        $this->displayBlock("checkbox_radio_row", $context, $blocks);
        
        $__internal_b61279cc872aa74b57da03e8968272caaf10f2d2e84f9f0126eae23079a41724->leave($__internal_b61279cc872aa74b57da03e8968272caaf10f2d2e84f9f0126eae23079a41724_prof);

        
        $__internal_cc7a29747019981e4c53dd912d104cc8fa3c30cd722b156c5106e30a71cb6a7c->leave($__internal_cc7a29747019981e4c53dd912d104cc8fa3c30cd722b156c5106e30a71cb6a7c_prof);

    }

    // line 45
    public function block_checkbox_radio_row($context, array $blocks = array())
    {
        $__internal_9c4f709cae6c5024c3ef833319260a0aac51a1e290269f06b4592e4edffb70b3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c4f709cae6c5024c3ef833319260a0aac51a1e290269f06b4592e4edffb70b3->enter($__internal_9c4f709cae6c5024c3ef833319260a0aac51a1e290269f06b4592e4edffb70b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_row"));

        $__internal_bca0c01259d19c516978d98f855af7e57bbec5c963340789d9aff1c18dadf0dd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bca0c01259d19c516978d98f855af7e57bbec5c963340789d9aff1c18dadf0dd->enter($__internal_bca0c01259d19c516978d98f855af7e57bbec5c963340789d9aff1c18dadf0dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_row"));

        // line 46
        ob_start();
        // line 47
        echo "    <div class=\"form-group";
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            echo " has-error";
        }
        echo "\">
        <div class=\"";
        // line 48
        $this->displayBlock("form_label_class", $context, $blocks);
        echo "\"></div>
        <div class=\"";
        // line 49
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">
            ";
        // line 50
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
            ";
        // line 51
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        echo "
        </div>
    </div>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_bca0c01259d19c516978d98f855af7e57bbec5c963340789d9aff1c18dadf0dd->leave($__internal_bca0c01259d19c516978d98f855af7e57bbec5c963340789d9aff1c18dadf0dd_prof);

        
        $__internal_9c4f709cae6c5024c3ef833319260a0aac51a1e290269f06b4592e4edffb70b3->leave($__internal_9c4f709cae6c5024c3ef833319260a0aac51a1e290269f06b4592e4edffb70b3_prof);

    }

    // line 57
    public function block_submit_row($context, array $blocks = array())
    {
        $__internal_ba845afc57363fe54b7ee390ca4c029c6b70052645267e8487ccefbc34976862 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba845afc57363fe54b7ee390ca4c029c6b70052645267e8487ccefbc34976862->enter($__internal_ba845afc57363fe54b7ee390ca4c029c6b70052645267e8487ccefbc34976862_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "submit_row"));

        $__internal_7ae166dd93e4d467101e57f2b8a10bf3134d5068edb82be72ddea3635e407d6f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7ae166dd93e4d467101e57f2b8a10bf3134d5068edb82be72ddea3635e407d6f->enter($__internal_7ae166dd93e4d467101e57f2b8a10bf3134d5068edb82be72ddea3635e407d6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "submit_row"));

        // line 58
        ob_start();
        // line 59
        echo "    <div class=\"form-group\">
        <div class=\"";
        // line 60
        $this->displayBlock("form_label_class", $context, $blocks);
        echo "\"></div>
        <div class=\"";
        // line 61
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">
            ";
        // line 62
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
        </div>
    </div>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_7ae166dd93e4d467101e57f2b8a10bf3134d5068edb82be72ddea3635e407d6f->leave($__internal_7ae166dd93e4d467101e57f2b8a10bf3134d5068edb82be72ddea3635e407d6f_prof);

        
        $__internal_ba845afc57363fe54b7ee390ca4c029c6b70052645267e8487ccefbc34976862->leave($__internal_ba845afc57363fe54b7ee390ca4c029c6b70052645267e8487ccefbc34976862_prof);

    }

    // line 68
    public function block_reset_row($context, array $blocks = array())
    {
        $__internal_567e23c34b2abf71b4cba629d86cc8d673596e1a5ff74d0d28615410105966b2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_567e23c34b2abf71b4cba629d86cc8d673596e1a5ff74d0d28615410105966b2->enter($__internal_567e23c34b2abf71b4cba629d86cc8d673596e1a5ff74d0d28615410105966b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "reset_row"));

        $__internal_484f00298538ec5e9b0c8841ae8bd1cc8f7e47623c3beff7bc8748e984816c45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_484f00298538ec5e9b0c8841ae8bd1cc8f7e47623c3beff7bc8748e984816c45->enter($__internal_484f00298538ec5e9b0c8841ae8bd1cc8f7e47623c3beff7bc8748e984816c45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "reset_row"));

        // line 69
        ob_start();
        // line 70
        echo "    <div class=\"form-group\">
        <div class=\"";
        // line 71
        $this->displayBlock("form_label_class", $context, $blocks);
        echo "\"></div>
        <div class=\"";
        // line 72
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">
            ";
        // line 73
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
        </div>
    </div>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_484f00298538ec5e9b0c8841ae8bd1cc8f7e47623c3beff7bc8748e984816c45->leave($__internal_484f00298538ec5e9b0c8841ae8bd1cc8f7e47623c3beff7bc8748e984816c45_prof);

        
        $__internal_567e23c34b2abf71b4cba629d86cc8d673596e1a5ff74d0d28615410105966b2->leave($__internal_567e23c34b2abf71b4cba629d86cc8d673596e1a5ff74d0d28615410105966b2_prof);

    }

    // line 79
    public function block_form_group_class($context, array $blocks = array())
    {
        $__internal_15ac69c619953518d917e3f1ba5559f3b5f5e0f61226666db158b0bf26955d13 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_15ac69c619953518d917e3f1ba5559f3b5f5e0f61226666db158b0bf26955d13->enter($__internal_15ac69c619953518d917e3f1ba5559f3b5f5e0f61226666db158b0bf26955d13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_group_class"));

        $__internal_94e3ff2835bbb36a7f19e3170ef19459ef3ee4931ef7e162f7e1ea1a79df5e82 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_94e3ff2835bbb36a7f19e3170ef19459ef3ee4931ef7e162f7e1ea1a79df5e82->enter($__internal_94e3ff2835bbb36a7f19e3170ef19459ef3ee4931ef7e162f7e1ea1a79df5e82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_group_class"));

        // line 80
        echo "col-sm-10";
        
        $__internal_94e3ff2835bbb36a7f19e3170ef19459ef3ee4931ef7e162f7e1ea1a79df5e82->leave($__internal_94e3ff2835bbb36a7f19e3170ef19459ef3ee4931ef7e162f7e1ea1a79df5e82_prof);

        
        $__internal_15ac69c619953518d917e3f1ba5559f3b5f5e0f61226666db158b0bf26955d13->leave($__internal_15ac69c619953518d917e3f1ba5559f3b5f5e0f61226666db158b0bf26955d13_prof);

    }

    public function getTemplateName()
    {
        return "bootstrap_3_horizontal_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  390 => 80,  381 => 79,  366 => 73,  362 => 72,  358 => 71,  355 => 70,  353 => 69,  344 => 68,  329 => 62,  325 => 61,  321 => 60,  318 => 59,  316 => 58,  307 => 57,  292 => 51,  288 => 50,  284 => 49,  280 => 48,  273 => 47,  271 => 46,  262 => 45,  252 => 42,  243 => 41,  233 => 38,  224 => 37,  214 => 34,  211 => 33,  209 => 32,  207 => 31,  203 => 30,  201 => 29,  195 => 28,  186 => 27,  176 => 22,  167 => 21,  155 => 16,  152 => 15,  146 => 13,  143 => 12,  141 => 11,  132 => 10,  122 => 5,  120 => 4,  111 => 3,  101 => 79,  98 => 78,  96 => 68,  93 => 67,  91 => 57,  88 => 56,  86 => 45,  83 => 44,  81 => 41,  78 => 40,  76 => 37,  73 => 36,  71 => 27,  68 => 26,  65 => 24,  63 => 21,  60 => 20,  58 => 10,  55 => 9,  52 => 7,  50 => 3,  47 => 2,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"bootstrap_3_layout.html.twig\" %}

{% block form_start -%}
    {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-horizontal')|trim}) %}
    {{- parent() -}}
{%- endblock form_start %}

{# Labels #}

{% block form_label -%}
{% spaceless %}
    {% if label is same as(false) %}
        <div class=\"{{ block('form_label_class') }}\"></div>
    {% else %}
        {% set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' ' ~ block('form_label_class'))|trim}) %}
        {{- parent() -}}
    {% endif %}
{% endspaceless %}
{%- endblock form_label %}

{% block form_label_class -%}
col-sm-2
{%- endblock form_label_class %}

{# Rows #}

{% block form_row -%}
    <div class=\"form-group{% if (not compound or force_error|default(false)) and not valid %} has-error{% endif %}\">
        {{- form_label(form) -}}
        <div class=\"{{ block('form_group_class') }}\">
            {{- form_widget(form) -}}
            {{- form_errors(form) -}}
        </div>
{##}</div>
{%- endblock form_row %}

{% block checkbox_row -%}
    {{- block('checkbox_radio_row') -}}
{%- endblock checkbox_row %}

{% block radio_row -%}
    {{- block('checkbox_radio_row') -}}
{%- endblock radio_row %}

{% block checkbox_radio_row -%}
{% spaceless %}
    <div class=\"form-group{% if not valid %} has-error{% endif %}\">
        <div class=\"{{ block('form_label_class') }}\"></div>
        <div class=\"{{ block('form_group_class') }}\">
            {{ form_widget(form) }}
            {{ form_errors(form) }}
        </div>
    </div>
{% endspaceless %}
{%- endblock checkbox_radio_row %}

{% block submit_row -%}
{% spaceless %}
    <div class=\"form-group\">
        <div class=\"{{ block('form_label_class') }}\"></div>
        <div class=\"{{ block('form_group_class') }}\">
            {{ form_widget(form) }}
        </div>
    </div>
{% endspaceless %}
{% endblock submit_row %}

{% block reset_row -%}
{% spaceless %}
    <div class=\"form-group\">
        <div class=\"{{ block('form_label_class') }}\"></div>
        <div class=\"{{ block('form_group_class') }}\">
            {{ form_widget(form) }}
        </div>
    </div>
{% endspaceless %}
{% endblock reset_row %}

{% block form_group_class -%}
col-sm-10
{%- endblock form_group_class %}
", "bootstrap_3_horizontal_layout.html.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bridge/Twig/Resources/views/Form/bootstrap_3_horizontal_layout.html.twig");
    }
}
