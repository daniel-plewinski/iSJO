<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_0b184bad4d5cd420f5e999ba502a65919ae6aa8f08d124d936483155da013d27 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7443a1d8434f36fe6a7fc9472a227f3400fc19fe7cce68e028ca9e325ebb7d68 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7443a1d8434f36fe6a7fc9472a227f3400fc19fe7cce68e028ca9e325ebb7d68->enter($__internal_7443a1d8434f36fe6a7fc9472a227f3400fc19fe7cce68e028ca9e325ebb7d68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_37e3df6dc6a0583ccb467dcc551940bd570b846e240421b1586b137184ec6567 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_37e3df6dc6a0583ccb467dcc551940bd570b846e240421b1586b137184ec6567->enter($__internal_37e3df6dc6a0583ccb467dcc551940bd570b846e240421b1586b137184ec6567_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_7443a1d8434f36fe6a7fc9472a227f3400fc19fe7cce68e028ca9e325ebb7d68->leave($__internal_7443a1d8434f36fe6a7fc9472a227f3400fc19fe7cce68e028ca9e325ebb7d68_prof);

        
        $__internal_37e3df6dc6a0583ccb467dcc551940bd570b846e240421b1586b137184ec6567->leave($__internal_37e3df6dc6a0583ccb467dcc551940bd570b846e240421b1586b137184ec6567_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_errors.html.php");
    }
}
