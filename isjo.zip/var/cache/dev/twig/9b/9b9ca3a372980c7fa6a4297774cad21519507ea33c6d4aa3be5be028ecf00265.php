<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_fbf41283b7f4354ef4521b2c359769377208d0a6cf3ebf5336d1e533a695471e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d36aa419d93f5261ffa63921694c8cac4453a3d81319cafc205746bc14d8d371 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d36aa419d93f5261ffa63921694c8cac4453a3d81319cafc205746bc14d8d371->enter($__internal_d36aa419d93f5261ffa63921694c8cac4453a3d81319cafc205746bc14d8d371_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_789d1ea976816f6df3aaf4d0b02b5a752f716d53b162e0ffa20e34919f5b1c1e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_789d1ea976816f6df3aaf4d0b02b5a752f716d53b162e0ffa20e34919f5b1c1e->enter($__internal_789d1ea976816f6df3aaf4d0b02b5a752f716d53b162e0ffa20e34919f5b1c1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_d36aa419d93f5261ffa63921694c8cac4453a3d81319cafc205746bc14d8d371->leave($__internal_d36aa419d93f5261ffa63921694c8cac4453a3d81319cafc205746bc14d8d371_prof);

        
        $__internal_789d1ea976816f6df3aaf4d0b02b5a752f716d53b162e0ffa20e34919f5b1c1e->leave($__internal_789d1ea976816f6df3aaf4d0b02b5a752f716d53b162e0ffa20e34919f5b1c1e_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.rdf.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
