<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_a036ce7a41f95c34fbc88fcf7fd80291e81560dae9db9b04e558203b7e4041c2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9ce703feb65aa4d01afafff7bc5f99dccc6b89329a679e21cd57f9382be6acdd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9ce703feb65aa4d01afafff7bc5f99dccc6b89329a679e21cd57f9382be6acdd->enter($__internal_9ce703feb65aa4d01afafff7bc5f99dccc6b89329a679e21cd57f9382be6acdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_aaeb3fa9f874b7dd3df39ae2eaa8112a841711b38ef7e5eca9a44cf64d9e3248 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aaeb3fa9f874b7dd3df39ae2eaa8112a841711b38ef7e5eca9a44cf64d9e3248->enter($__internal_aaeb3fa9f874b7dd3df39ae2eaa8112a841711b38ef7e5eca9a44cf64d9e3248_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_9ce703feb65aa4d01afafff7bc5f99dccc6b89329a679e21cd57f9382be6acdd->leave($__internal_9ce703feb65aa4d01afafff7bc5f99dccc6b89329a679e21cd57f9382be6acdd_prof);

        
        $__internal_aaeb3fa9f874b7dd3df39ae2eaa8112a841711b38ef7e5eca9a44cf64d9e3248->leave($__internal_aaeb3fa9f874b7dd3df39ae2eaa8112a841711b38ef7e5eca9a44cf64d9e3248_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/reset_widget.html.php");
    }
}
