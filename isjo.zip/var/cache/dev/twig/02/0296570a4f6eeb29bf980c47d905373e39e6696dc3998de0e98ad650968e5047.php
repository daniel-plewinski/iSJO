<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_22b10d65c6a93088f27c14078211cb05e4c037eca640eed444e4acdea91fe391 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_52afe55447a7588966f51b98abdae23506dffbb6d85f24bd376fee64f37a0e35 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_52afe55447a7588966f51b98abdae23506dffbb6d85f24bd376fee64f37a0e35->enter($__internal_52afe55447a7588966f51b98abdae23506dffbb6d85f24bd376fee64f37a0e35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_95c35ddc47b2032099338d00668b6bf8857f74f6b6627d9b1b6981ba7922bf91 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_95c35ddc47b2032099338d00668b6bf8857f74f6b6627d9b1b6981ba7922bf91->enter($__internal_95c35ddc47b2032099338d00668b6bf8857f74f6b6627d9b1b6981ba7922bf91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_52afe55447a7588966f51b98abdae23506dffbb6d85f24bd376fee64f37a0e35->leave($__internal_52afe55447a7588966f51b98abdae23506dffbb6d85f24bd376fee64f37a0e35_prof);

        
        $__internal_95c35ddc47b2032099338d00668b6bf8857f74f6b6627d9b1b6981ba7922bf91->leave($__internal_95c35ddc47b2032099338d00668b6bf8857f74f6b6627d9b1b6981ba7922bf91_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_options.html.php");
    }
}
