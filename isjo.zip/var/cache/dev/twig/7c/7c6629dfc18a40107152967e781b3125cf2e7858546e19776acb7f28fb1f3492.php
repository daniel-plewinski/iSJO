<?php

/* ::add_course_lesson.html.twig */
class __TwigTemplate_d2a50e6d7777b31ecd3db417cf49b131f384b3a0d68416de9fd78ccb638a2f52 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::add_course_lesson.html.twig", 1);
        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_26704a9a373240d71370e2239806c8e7500865096d99cffef60ab931724ffec8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_26704a9a373240d71370e2239806c8e7500865096d99cffef60ab931724ffec8->enter($__internal_26704a9a373240d71370e2239806c8e7500865096d99cffef60ab931724ffec8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::add_course_lesson.html.twig"));

        $__internal_f9e6d4e1c4d0449b296143e1b3aedebb12ca74023ffa5542821cdbaefe4a7886 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9e6d4e1c4d0449b296143e1b3aedebb12ca74023ffa5542821cdbaefe4a7886->enter($__internal_f9e6d4e1c4d0449b296143e1b3aedebb12ca74023ffa5542821cdbaefe4a7886_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::add_course_lesson.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_26704a9a373240d71370e2239806c8e7500865096d99cffef60ab931724ffec8->leave($__internal_26704a9a373240d71370e2239806c8e7500865096d99cffef60ab931724ffec8_prof);

        
        $__internal_f9e6d4e1c4d0449b296143e1b3aedebb12ca74023ffa5542821cdbaefe4a7886->leave($__internal_f9e6d4e1c4d0449b296143e1b3aedebb12ca74023ffa5542821cdbaefe4a7886_prof);

    }

    // line 3
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_cbdc10298ef5af71299ef5c1b17ae642b3616f35cff937b9780f98560d8c5fe7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cbdc10298ef5af71299ef5c1b17ae642b3616f35cff937b9780f98560d8c5fe7->enter($__internal_cbdc10298ef5af71299ef5c1b17ae642b3616f35cff937b9780f98560d8c5fe7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_f58eedc1bb85cd7ad4e516f932a2ae3085c20c7f41ea2d62a62fd3357de2fdc1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f58eedc1bb85cd7ad4e516f932a2ae3085c20c7f41ea2d62a62fd3357de2fdc1->enter($__internal_f58eedc1bb85cd7ad4e516f932a2ae3085c20c7f41ea2d62a62fd3357de2fdc1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 4
        echo "
    ";
        // line 5
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/locales/bootstrap-datepicker.pl.min.js\"></script>

    <script>
        \$(document).ready(function () {
            \$('.js-datepicker').datepicker({
                language: 'pl-PL',
                showOn: 'button',
                buttonImageOnly: true,
                changeMonth: true,
                changeYear: true,
                format: 'yyyy-mm-dd',
                yearRange: \"-0:+1\"

            });
        });
    </script>

";
        
        $__internal_f58eedc1bb85cd7ad4e516f932a2ae3085c20c7f41ea2d62a62fd3357de2fdc1->leave($__internal_f58eedc1bb85cd7ad4e516f932a2ae3085c20c7f41ea2d62a62fd3357de2fdc1_prof);

        
        $__internal_cbdc10298ef5af71299ef5c1b17ae642b3616f35cff937b9780f98560d8c5fe7->leave($__internal_cbdc10298ef5af71299ef5c1b17ae642b3616f35cff937b9780f98560d8c5fe7_prof);

    }

    // line 27
    public function block_body($context, array $blocks = array())
    {
        $__internal_0a208c1ad464691542e221925dbb9ce8c1ab5cd9ac2e0923211b8e9e0a15201b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0a208c1ad464691542e221925dbb9ce8c1ab5cd9ac2e0923211b8e9e0a15201b->enter($__internal_0a208c1ad464691542e221925dbb9ce8c1ab5cd9ac2e0923211b8e9e0a15201b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_14aac9006908657e9af6457d0336d4a892a27766784bbbb8f8f66b12217ec624 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_14aac9006908657e9af6457d0336d4a892a27766784bbbb8f8f66b12217ec624->enter($__internal_14aac9006908657e9af6457d0336d4a892a27766784bbbb8f8f66b12217ec624_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 28
        echo "

    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Dodawanie lekcji
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Dodawanie lekcji</a>
                </li>
            </ol>
        </div>

        <p>Do nazwy kursu automatycznie dodawany jest unikalny numer aby nazwa nie mogła się powtarzać</p>

        ";
        // line 50
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 51
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
        ";
        // line 52
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

    </div>



";
        
        $__internal_14aac9006908657e9af6457d0336d4a892a27766784bbbb8f8f66b12217ec624->leave($__internal_14aac9006908657e9af6457d0336d4a892a27766784bbbb8f8f66b12217ec624_prof);

        
        $__internal_0a208c1ad464691542e221925dbb9ce8c1ab5cd9ac2e0923211b8e9e0a15201b->leave($__internal_0a208c1ad464691542e221925dbb9ce8c1ab5cd9ac2e0923211b8e9e0a15201b_prof);

    }

    public function getTemplateName()
    {
        return "::add_course_lesson.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 52,  121 => 51,  117 => 50,  93 => 28,  84 => 27,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block javascripts %}

    {{ parent() }}

    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/locales/bootstrap-datepicker.pl.min.js\"></script>

    <script>
        \$(document).ready(function () {
            \$('.js-datepicker').datepicker({
                language: 'pl-PL',
                showOn: 'button',
                buttonImageOnly: true,
                changeMonth: true,
                changeYear: true,
                format: 'yyyy-mm-dd',
                yearRange: \"-0:+1\"

            });
        });
    </script>

{% endblock %}

{% block body %}


    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Dodawanie lekcji
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Dodawanie lekcji</a>
                </li>
            </ol>
        </div>

        <p>Do nazwy kursu automatycznie dodawany jest unikalny numer aby nazwa nie mogła się powtarzać</p>

        {{ form_start(form) }}
        {{ form_widget(form) }}
        {{ form_end(form) }}

    </div>



{% endblock %}", "::add_course_lesson.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/add_course_lesson.html.twig");
    }
}
