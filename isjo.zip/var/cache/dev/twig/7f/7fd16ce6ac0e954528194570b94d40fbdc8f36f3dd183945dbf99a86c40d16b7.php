<?php

/* ::choose_school_settlement_date.html.twig */
class __TwigTemplate_8fa139505261a745da547667a53db4320da63cda65b99b2436c01f39b7452c37 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::choose_school_settlement_date.html.twig", 1);
        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f8b6ded18c51f4d804135213bb0b7bb7a86b2a0b55bb49455f99872d8b703d1a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f8b6ded18c51f4d804135213bb0b7bb7a86b2a0b55bb49455f99872d8b703d1a->enter($__internal_f8b6ded18c51f4d804135213bb0b7bb7a86b2a0b55bb49455f99872d8b703d1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::choose_school_settlement_date.html.twig"));

        $__internal_1bef62754d832754242de24c843871c86a2e1509d5961aaf9c0a1c2a7fdc3926 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1bef62754d832754242de24c843871c86a2e1509d5961aaf9c0a1c2a7fdc3926->enter($__internal_1bef62754d832754242de24c843871c86a2e1509d5961aaf9c0a1c2a7fdc3926_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::choose_school_settlement_date.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f8b6ded18c51f4d804135213bb0b7bb7a86b2a0b55bb49455f99872d8b703d1a->leave($__internal_f8b6ded18c51f4d804135213bb0b7bb7a86b2a0b55bb49455f99872d8b703d1a_prof);

        
        $__internal_1bef62754d832754242de24c843871c86a2e1509d5961aaf9c0a1c2a7fdc3926->leave($__internal_1bef62754d832754242de24c843871c86a2e1509d5961aaf9c0a1c2a7fdc3926_prof);

    }

    // line 3
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_2797ae52c88c301566ff55921d5836b77b245e49a3747d2003c1d7af7cabc540 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2797ae52c88c301566ff55921d5836b77b245e49a3747d2003c1d7af7cabc540->enter($__internal_2797ae52c88c301566ff55921d5836b77b245e49a3747d2003c1d7af7cabc540_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_e802448090d556621d07b191ec65fe3451e666de589a340d0ebc1967748562ae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e802448090d556621d07b191ec65fe3451e666de589a340d0ebc1967748562ae->enter($__internal_e802448090d556621d07b191ec65fe3451e666de589a340d0ebc1967748562ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 4
        echo "
    ";
        // line 5
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

";
        
        $__internal_e802448090d556621d07b191ec65fe3451e666de589a340d0ebc1967748562ae->leave($__internal_e802448090d556621d07b191ec65fe3451e666de589a340d0ebc1967748562ae_prof);

        
        $__internal_2797ae52c88c301566ff55921d5836b77b245e49a3747d2003c1d7af7cabc540->leave($__internal_2797ae52c88c301566ff55921d5836b77b245e49a3747d2003c1d7af7cabc540_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_f76235176d1f26a0a2e9e6e83e71e4f2d8ec11e7785ae095ac18a22d6b869bad = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f76235176d1f26a0a2e9e6e83e71e4f2d8ec11e7785ae095ac18a22d6b869bad->enter($__internal_f76235176d1f26a0a2e9e6e83e71e4f2d8ec11e7785ae095ac18a22d6b869bad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3b5610a1f449c4ec69fd95ae7b8ede2f4f5f8a5a06b04d628db01c661c3cb82d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3b5610a1f449c4ec69fd95ae7b8ede2f4f5f8a5a06b04d628db01c661c3cb82d->enter($__internal_3b5610a1f449c4ec69fd95ae7b8ede2f4f5f8a5a06b04d628db01c661c3cb82d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "

    <div class=\"container-fluid\">

        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Wybierz okres rozliczenia
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Lista kursów
                </li>
            </ol>
        </div>


        ";
        // line 35
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
        <table class=\"centered-table\">
            <tr>
                <th class=\"td-right-padding\">";
        // line 38
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "year", array()), 'label');
        echo "</th>
                <th>";
        // line 39
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "month", array()), 'label');
        echo "</th>
            </tr>
            <tr>
                <td class=\"td-right-padding\">";
        // line 42
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "year", array()), 'widget', array("value" => twig_date_format_filter($this->env, "now", "Y")));
        echo "</td>
                <td>";
        // line 43
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "month", array()), 'widget', array("value" => twig_date_format_filter($this->env, "now", "m")));
        echo "</td>
            </tr>
            <tr>
               <td>";
        // line 46
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "month", array()), 'widget', array("value" => twig_date_format_filter($this->env, "now", "m")));
        echo "</td>
            </tr>
            <tr>
                <td colspan=\"2\" class=\"text-center\">";
        // line 49
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "teacherId", array()), 'label');
        echo "</td>
            </tr>
            <tr>
                <td colspan=\"2\" class=\"text-center\">";
        // line 52
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "teacherId", array()), 'widget');
        echo "</td>
            </tr>
            <tr>
                <td colspan=\"2\" class=\"text-center\">";
        // line 55
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "submit", array()), 'widget');
        echo "</td>
            </tr>

        </table>



        ";
        // line 62
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

    </div>

";
        
        $__internal_3b5610a1f449c4ec69fd95ae7b8ede2f4f5f8a5a06b04d628db01c661c3cb82d->leave($__internal_3b5610a1f449c4ec69fd95ae7b8ede2f4f5f8a5a06b04d628db01c661c3cb82d_prof);

        
        $__internal_f76235176d1f26a0a2e9e6e83e71e4f2d8ec11e7785ae095ac18a22d6b869bad->leave($__internal_f76235176d1f26a0a2e9e6e83e71e4f2d8ec11e7785ae095ac18a22d6b869bad_prof);

    }

    public function getTemplateName()
    {
        return "::choose_school_settlement_date.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  156 => 62,  146 => 55,  140 => 52,  134 => 49,  128 => 46,  122 => 43,  118 => 42,  112 => 39,  108 => 38,  102 => 35,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block javascripts %}

    {{ parent() }}

{% endblock %}

{% block body %}


    <div class=\"container-fluid\">

        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Wybierz okres rozliczenia
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Lista kursów
                </li>
            </ol>
        </div>


        {{ form_start(form) }}
        <table class=\"centered-table\">
            <tr>
                <th class=\"td-right-padding\">{{ form_label(form.year) }}</th>
                <th>{{ form_label(form.month) }}</th>
            </tr>
            <tr>
                <td class=\"td-right-padding\">{{ form_widget(form.year, { 'value': \"now\"|date(\"Y\")} ) }}</td>
                <td>{{ form_widget(form.month, { 'value': \"now\"|date(\"m\")} ) }}</td>
            </tr>
            <tr>
               <td>{{ form_widget(form.month, { 'value': \"now\"|date(\"m\")} ) }}</td>
            </tr>
            <tr>
                <td colspan=\"2\" class=\"text-center\">{{ form_label(form.teacherId) }}</td>
            </tr>
            <tr>
                <td colspan=\"2\" class=\"text-center\">{{ form_widget(form.teacherId) }}</td>
            </tr>
            <tr>
                <td colspan=\"2\" class=\"text-center\">{{ form_widget(form.submit) }}</td>
            </tr>

        </table>



        {{ form_end(form) }}

    </div>

{% endblock %}", "::choose_school_settlement_date.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/choose_school_settlement_date.html.twig");
    }
}
