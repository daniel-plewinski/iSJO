<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_a3c0720c62ad1ecbbea02a67a1821b502286ce309c3d5119117e1a0b18a58041 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_acca52f4e0827211788beeeb901f70d561897db87ebcfe6e03dfab4b858aea98 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_acca52f4e0827211788beeeb901f70d561897db87ebcfe6e03dfab4b858aea98->enter($__internal_acca52f4e0827211788beeeb901f70d561897db87ebcfe6e03dfab4b858aea98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        $__internal_e629c959d746227501c7daec728acc3d62b9bc41c3b324076188c4b9beff0826 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e629c959d746227501c7daec728acc3d62b9bc41c3b324076188c4b9beff0826->enter($__internal_e629c959d746227501c7daec728acc3d62b9bc41c3b324076188c4b9beff0826_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_acca52f4e0827211788beeeb901f70d561897db87ebcfe6e03dfab4b858aea98->leave($__internal_acca52f4e0827211788beeeb901f70d561897db87ebcfe6e03dfab4b858aea98_prof);

        
        $__internal_e629c959d746227501c7daec728acc3d62b9bc41c3b324076188c4b9beff0826->leave($__internal_e629c959d746227501c7daec728acc3d62b9bc41c3b324076188c4b9beff0826_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.css.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.css.twig");
    }
}
