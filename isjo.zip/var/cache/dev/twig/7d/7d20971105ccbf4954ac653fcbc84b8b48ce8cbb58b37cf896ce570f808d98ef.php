<?php

/* ::add_course.html.twig */
class __TwigTemplate_bf7902eb95a8e8a83734e375cc9476a47474dc762f64e7487f4a2c0239faf3c6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::add_course.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1888fcd1d89da774abf07eb7c14e59e33a947ef77d24300645a089e8638bde1d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1888fcd1d89da774abf07eb7c14e59e33a947ef77d24300645a089e8638bde1d->enter($__internal_1888fcd1d89da774abf07eb7c14e59e33a947ef77d24300645a089e8638bde1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::add_course.html.twig"));

        $__internal_cef7cb42097097b397c6b2df445f97f0129d37f38c2e5b744d22184b8f2d440b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cef7cb42097097b397c6b2df445f97f0129d37f38c2e5b744d22184b8f2d440b->enter($__internal_cef7cb42097097b397c6b2df445f97f0129d37f38c2e5b744d22184b8f2d440b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::add_course.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1888fcd1d89da774abf07eb7c14e59e33a947ef77d24300645a089e8638bde1d->leave($__internal_1888fcd1d89da774abf07eb7c14e59e33a947ef77d24300645a089e8638bde1d_prof);

        
        $__internal_cef7cb42097097b397c6b2df445f97f0129d37f38c2e5b744d22184b8f2d440b->leave($__internal_cef7cb42097097b397c6b2df445f97f0129d37f38c2e5b744d22184b8f2d440b_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_95ee4e096af2237b92319d495566851793cd6e1ab37575e362bcd7001edcd751 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_95ee4e096af2237b92319d495566851793cd6e1ab37575e362bcd7001edcd751->enter($__internal_95ee4e096af2237b92319d495566851793cd6e1ab37575e362bcd7001edcd751_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_38647770f951e2f2458842f5d61e42f769b5ee1ea9fee0a8b673520ca4839aec = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38647770f951e2f2458842f5d61e42f769b5ee1ea9fee0a8b673520ca4839aec->enter($__internal_38647770f951e2f2458842f5d61e42f769b5ee1ea9fee0a8b673520ca4839aec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Dodawanie kursu
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Dodawanie kursu</a>
                </li>
            </ol>
        </div>

        <p>Unikalny kod kursu jest tworzony automatycznie</p>

        ";
        // line 26
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 27
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "courseName", array()), 'label');
        echo "
        ";
        // line 28
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "courseName", array()), 'widget');
        echo "
        ";
        // line 29
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "subject", array()), 'label');
        echo "
        ";
        // line 30
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "subject", array()), 'widget');
        echo "
        ";
        // line 31
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "totalLessons", array()), 'label');
        echo "
        ";
        // line 32
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "totalLessons", array()), 'widget', array("type" => "number"));
        echo "
        ";
        // line 33
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "teacherRate", array()), 'label');
        echo "
        ";
        // line 34
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "teacherRate", array()), 'widget', array("type" => "number"));
        echo "
        ";
        // line 35
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "teacherId", array()), 'label');
        echo "
        ";
        // line 36
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "teacherId", array()), 'widget');
        echo "
        ";
        // line 37
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "submit", array()), 'widget');
        echo "
        ";
        // line 38
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

    </div>

";
        
        $__internal_38647770f951e2f2458842f5d61e42f769b5ee1ea9fee0a8b673520ca4839aec->leave($__internal_38647770f951e2f2458842f5d61e42f769b5ee1ea9fee0a8b673520ca4839aec_prof);

        
        $__internal_95ee4e096af2237b92319d495566851793cd6e1ab37575e362bcd7001edcd751->leave($__internal_95ee4e096af2237b92319d495566851793cd6e1ab37575e362bcd7001edcd751_prof);

    }

    public function getTemplateName()
    {
        return "::add_course.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  120 => 38,  116 => 37,  112 => 36,  108 => 35,  104 => 34,  100 => 33,  96 => 32,  92 => 31,  88 => 30,  84 => 29,  80 => 28,  76 => 27,  72 => 26,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Dodawanie kursu
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Dodawanie kursu</a>
                </li>
            </ol>
        </div>

        <p>Unikalny kod kursu jest tworzony automatycznie</p>

        {{ form_start(form) }}
        {{ form_label(form.courseName) }}
        {{ form_widget(form.courseName) }}
        {{ form_label(form.subject) }}
        {{ form_widget(form.subject) }}
        {{ form_label(form.totalLessons) }}
        {{ form_widget(form.totalLessons, {'type':'number'}) }}
        {{ form_label(form.teacherRate) }}
        {{ form_widget(form.teacherRate, {'type':'number'}) }}
        {{ form_label(form.teacherId) }}
        {{ form_widget(form.teacherId) }}
        {{ form_widget(form.submit) }}
        {{ form_end(form) }}

    </div>

{% endblock %}", "::add_course.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/add_course.html.twig");
    }
}
