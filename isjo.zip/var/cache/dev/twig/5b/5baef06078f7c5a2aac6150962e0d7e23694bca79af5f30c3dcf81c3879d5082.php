<?php

/* FOSUserBundle:Resetting:check_email.html.twig */
class __TwigTemplate_abcde66e8bc0132c62bd6186687f8b9aa2edc21bd19d427849e11b7f430d46bc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:check_email.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_08fa10161c905f614283fb0bc628a9da21adb9d5352b93f48305c6108c24c4d7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_08fa10161c905f614283fb0bc628a9da21adb9d5352b93f48305c6108c24c4d7->enter($__internal_08fa10161c905f614283fb0bc628a9da21adb9d5352b93f48305c6108c24c4d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:check_email.html.twig"));

        $__internal_1aea600ab25621491e4f406f1c3b8ccab91dde2ffc730482495d7b2fb4649fab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1aea600ab25621491e4f406f1c3b8ccab91dde2ffc730482495d7b2fb4649fab->enter($__internal_1aea600ab25621491e4f406f1c3b8ccab91dde2ffc730482495d7b2fb4649fab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:check_email.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_08fa10161c905f614283fb0bc628a9da21adb9d5352b93f48305c6108c24c4d7->leave($__internal_08fa10161c905f614283fb0bc628a9da21adb9d5352b93f48305c6108c24c4d7_prof);

        
        $__internal_1aea600ab25621491e4f406f1c3b8ccab91dde2ffc730482495d7b2fb4649fab->leave($__internal_1aea600ab25621491e4f406f1c3b8ccab91dde2ffc730482495d7b2fb4649fab_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_15a1c96981b04869fcc71a88b0dbd877ec6ff356d4b658e99ee33e2327db967a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_15a1c96981b04869fcc71a88b0dbd877ec6ff356d4b658e99ee33e2327db967a->enter($__internal_15a1c96981b04869fcc71a88b0dbd877ec6ff356d4b658e99ee33e2327db967a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_ffc367e40f46680ad76b6f1b87acfa44d57d078709e6636e02c004fc450a6250 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ffc367e40f46680ad76b6f1b87acfa44d57d078709e6636e02c004fc450a6250->enter($__internal_ffc367e40f46680ad76b6f1b87acfa44d57d078709e6636e02c004fc450a6250_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>
";
        // line 7
        echo nl2br(twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.check_email", array("%tokenLifetime%" => ($context["tokenLifetime"] ?? $this->getContext($context, "tokenLifetime"))), "FOSUserBundle"), "html", null, true));
        echo "
</p>
";
        
        $__internal_ffc367e40f46680ad76b6f1b87acfa44d57d078709e6636e02c004fc450a6250->leave($__internal_ffc367e40f46680ad76b6f1b87acfa44d57d078709e6636e02c004fc450a6250_prof);

        
        $__internal_15a1c96981b04869fcc71a88b0dbd877ec6ff356d4b658e99ee33e2327db967a->leave($__internal_15a1c96981b04869fcc71a88b0dbd877ec6ff356d4b658e99ee33e2327db967a_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:check_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  52 => 7,  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
<p>
{{ 'resetting.check_email'|trans({'%tokenLifetime%': tokenLifetime})|nl2br }}
</p>
{% endblock %}
", "FOSUserBundle:Resetting:check_email.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Resetting/check_email.html.twig");
    }
}
