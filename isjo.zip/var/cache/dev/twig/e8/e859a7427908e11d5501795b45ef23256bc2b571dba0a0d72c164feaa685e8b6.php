<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_f90fd4f415226ad76aefdff4da36f0b12f13057e2877538d4b1e006688cadc63 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c333be95cd61d284cd4fdcd352f626a6cd63c9cf8b6b2e1ede94a1b04a991f2c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c333be95cd61d284cd4fdcd352f626a6cd63c9cf8b6b2e1ede94a1b04a991f2c->enter($__internal_c333be95cd61d284cd4fdcd352f626a6cd63c9cf8b6b2e1ede94a1b04a991f2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_dacda5ce23622706d89bfb9ffb15509e9ff60e46dd1c844b7a230708983cf621 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dacda5ce23622706d89bfb9ffb15509e9ff60e46dd1c844b7a230708983cf621->enter($__internal_dacda5ce23622706d89bfb9ffb15509e9ff60e46dd1c844b7a230708983cf621_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_c333be95cd61d284cd4fdcd352f626a6cd63c9cf8b6b2e1ede94a1b04a991f2c->leave($__internal_c333be95cd61d284cd4fdcd352f626a6cd63c9cf8b6b2e1ede94a1b04a991f2c_prof);

        
        $__internal_dacda5ce23622706d89bfb9ffb15509e9ff60e46dd1c844b7a230708983cf621->leave($__internal_dacda5ce23622706d89bfb9ffb15509e9ff60e46dd1c844b7a230708983cf621_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/chevron-right.svg");
    }
}
