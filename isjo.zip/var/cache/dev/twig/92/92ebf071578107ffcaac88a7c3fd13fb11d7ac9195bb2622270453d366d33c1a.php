<?php

/* ::edit_course.html.twig */
class __TwigTemplate_6f20ae5f9741d3defef7ef95f00a42d2248265906880af7d37e80f56dd895bdf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::edit_course.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12a63edb03618f79eb068c0c4b7cf99d0d400748a3d3a0a3f2ff2f3cae4d740a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12a63edb03618f79eb068c0c4b7cf99d0d400748a3d3a0a3f2ff2f3cae4d740a->enter($__internal_12a63edb03618f79eb068c0c4b7cf99d0d400748a3d3a0a3f2ff2f3cae4d740a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::edit_course.html.twig"));

        $__internal_545a3375730fef1669f8e92691352e3ae6c6d1a404cae02a7eba1819856d3693 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_545a3375730fef1669f8e92691352e3ae6c6d1a404cae02a7eba1819856d3693->enter($__internal_545a3375730fef1669f8e92691352e3ae6c6d1a404cae02a7eba1819856d3693_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::edit_course.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_12a63edb03618f79eb068c0c4b7cf99d0d400748a3d3a0a3f2ff2f3cae4d740a->leave($__internal_12a63edb03618f79eb068c0c4b7cf99d0d400748a3d3a0a3f2ff2f3cae4d740a_prof);

        
        $__internal_545a3375730fef1669f8e92691352e3ae6c6d1a404cae02a7eba1819856d3693->leave($__internal_545a3375730fef1669f8e92691352e3ae6c6d1a404cae02a7eba1819856d3693_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_5313a0749ff93b93294c60f1ecdc3f7378ddd7e66018e5aa5ca2b5cc9d5fc0df = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5313a0749ff93b93294c60f1ecdc3f7378ddd7e66018e5aa5ca2b5cc9d5fc0df->enter($__internal_5313a0749ff93b93294c60f1ecdc3f7378ddd7e66018e5aa5ca2b5cc9d5fc0df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_5d78eb7baacb219f8de40f98cb091a9d2d510f67e585bed45cf1b3b720cf6086 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5d78eb7baacb219f8de40f98cb091a9d2d510f67e585bed45cf1b3b720cf6086->enter($__internal_5d78eb7baacb219f8de40f98cb091a9d2d510f67e585bed45cf1b3b720cf6086_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Edycja kursu
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Dodawanie kursu</a>
                </li>
            </ol>
        </div>

        <p>Do nazwy kursu automatycznie dodawany jest unikalny numer aby nazwa nie mogła się powtarzać</p>

        ";
        // line 26
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 27
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
        ";
        // line 28
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

    </div>

";
        
        $__internal_5d78eb7baacb219f8de40f98cb091a9d2d510f67e585bed45cf1b3b720cf6086->leave($__internal_5d78eb7baacb219f8de40f98cb091a9d2d510f67e585bed45cf1b3b720cf6086_prof);

        
        $__internal_5313a0749ff93b93294c60f1ecdc3f7378ddd7e66018e5aa5ca2b5cc9d5fc0df->leave($__internal_5313a0749ff93b93294c60f1ecdc3f7378ddd7e66018e5aa5ca2b5cc9d5fc0df_prof);

    }

    public function getTemplateName()
    {
        return "::edit_course.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 28,  76 => 27,  72 => 26,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Edycja kursu
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Dodawanie kursu</a>
                </li>
            </ol>
        </div>

        <p>Do nazwy kursu automatycznie dodawany jest unikalny numer aby nazwa nie mogła się powtarzać</p>

        {{ form_start(form) }}
        {{ form_widget(form) }}
        {{ form_end(form) }}

    </div>

{% endblock %}", "::edit_course.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/edit_course.html.twig");
    }
}
