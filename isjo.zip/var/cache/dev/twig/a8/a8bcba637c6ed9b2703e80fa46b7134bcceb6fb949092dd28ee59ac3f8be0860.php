<?php

/* FOSUserBundle:Resetting:request.html.twig */
class __TwigTemplate_966a9549cd8a1aa51b6fd3e826da755309f51a76a9f82f34cb2df77164c97e00 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:request.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3f5357a48da763bb20f41bb03db520bcec854fed162c56fe4701bae9bcc71314 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3f5357a48da763bb20f41bb03db520bcec854fed162c56fe4701bae9bcc71314->enter($__internal_3f5357a48da763bb20f41bb03db520bcec854fed162c56fe4701bae9bcc71314_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $__internal_f386018d41f2b25d84d0546a60af2797e001bad17f2733e798ec75eb60897d71 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f386018d41f2b25d84d0546a60af2797e001bad17f2733e798ec75eb60897d71->enter($__internal_f386018d41f2b25d84d0546a60af2797e001bad17f2733e798ec75eb60897d71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3f5357a48da763bb20f41bb03db520bcec854fed162c56fe4701bae9bcc71314->leave($__internal_3f5357a48da763bb20f41bb03db520bcec854fed162c56fe4701bae9bcc71314_prof);

        
        $__internal_f386018d41f2b25d84d0546a60af2797e001bad17f2733e798ec75eb60897d71->leave($__internal_f386018d41f2b25d84d0546a60af2797e001bad17f2733e798ec75eb60897d71_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_4d6c4df55c772f7edb6d943ff03d2e221887e89a58cf0d331295ebeeb79113df = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4d6c4df55c772f7edb6d943ff03d2e221887e89a58cf0d331295ebeeb79113df->enter($__internal_4d6c4df55c772f7edb6d943ff03d2e221887e89a58cf0d331295ebeeb79113df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_d2176a94dda0c315d2abf0105c7cac1962567eb23d1e065e7f520fec4cdf0c3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d2176a94dda0c315d2abf0105c7cac1962567eb23d1e065e7f520fec4cdf0c3c->enter($__internal_d2176a94dda0c315d2abf0105c7cac1962567eb23d1e065e7f520fec4cdf0c3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Resetting/request_content.html.twig", "FOSUserBundle:Resetting:request.html.twig", 4)->display($context);
        
        $__internal_d2176a94dda0c315d2abf0105c7cac1962567eb23d1e065e7f520fec4cdf0c3c->leave($__internal_d2176a94dda0c315d2abf0105c7cac1962567eb23d1e065e7f520fec4cdf0c3c_prof);

        
        $__internal_4d6c4df55c772f7edb6d943ff03d2e221887e89a58cf0d331295ebeeb79113df->leave($__internal_4d6c4df55c772f7edb6d943ff03d2e221887e89a58cf0d331295ebeeb79113df_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Resetting/request_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Resetting:request.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Resetting/request.html.twig");
    }
}
