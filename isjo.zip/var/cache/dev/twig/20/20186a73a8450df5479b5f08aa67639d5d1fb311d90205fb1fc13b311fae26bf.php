<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_542fb54322e5da4fd163e634e43ee3b146f58e380fdd012b569faa8833824fb5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_25bb1bc011582482233c6e422c0a005b84d6e437a3c12b499abea8fa4742f379 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_25bb1bc011582482233c6e422c0a005b84d6e437a3c12b499abea8fa4742f379->enter($__internal_25bb1bc011582482233c6e422c0a005b84d6e437a3c12b499abea8fa4742f379_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        $__internal_8efc06994e5ca61b02d9afdaa508407378898d0ae1c67e73f8d1cd28a9e07207 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8efc06994e5ca61b02d9afdaa508407378898d0ae1c67e73f8d1cd28a9e07207->enter($__internal_8efc06994e5ca61b02d9afdaa508407378898d0ae1c67e73f8d1cd28a9e07207_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_25bb1bc011582482233c6e422c0a005b84d6e437a3c12b499abea8fa4742f379->leave($__internal_25bb1bc011582482233c6e422c0a005b84d6e437a3c12b499abea8fa4742f379_prof);

        
        $__internal_8efc06994e5ca61b02d9afdaa508407378898d0ae1c67e73f8d1cd28a9e07207->leave($__internal_8efc06994e5ca61b02d9afdaa508407378898d0ae1c67e73f8d1cd28a9e07207_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
", "@Framework/Form/hidden_widget.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_widget.html.php");
    }
}
