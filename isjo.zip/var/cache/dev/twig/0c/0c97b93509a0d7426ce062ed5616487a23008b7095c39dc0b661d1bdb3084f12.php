<?php

/* ::show_lessons.html.twig */
class __TwigTemplate_9057d5918099f27ebe9784fd46d6077c7bacae62aedb52bc147d11d743c92d26 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::show_lessons.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ec3a6e16239017f8b41313bfe7b27d2707154e483e315074112957b2e031d104 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ec3a6e16239017f8b41313bfe7b27d2707154e483e315074112957b2e031d104->enter($__internal_ec3a6e16239017f8b41313bfe7b27d2707154e483e315074112957b2e031d104_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::show_lessons.html.twig"));

        $__internal_65d7bbf573bac201c35113a0ca1dbd3b0c02453e7d090e53e1e7c0c2026d161e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_65d7bbf573bac201c35113a0ca1dbd3b0c02453e7d090e53e1e7c0c2026d161e->enter($__internal_65d7bbf573bac201c35113a0ca1dbd3b0c02453e7d090e53e1e7c0c2026d161e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::show_lessons.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ec3a6e16239017f8b41313bfe7b27d2707154e483e315074112957b2e031d104->leave($__internal_ec3a6e16239017f8b41313bfe7b27d2707154e483e315074112957b2e031d104_prof);

        
        $__internal_65d7bbf573bac201c35113a0ca1dbd3b0c02453e7d090e53e1e7c0c2026d161e->leave($__internal_65d7bbf573bac201c35113a0ca1dbd3b0c02453e7d090e53e1e7c0c2026d161e_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_b96004935e5dfa3caf717bbe35f4a93940ad0b699bc3beb15a70e8588535eb66 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b96004935e5dfa3caf717bbe35f4a93940ad0b699bc3beb15a70e8588535eb66->enter($__internal_b96004935e5dfa3caf717bbe35f4a93940ad0b699bc3beb15a70e8588535eb66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b0053ca568d7ff77e02223fd8483262228ae064ddf37d54d0d08bb386a6da523 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b0053ca568d7ff77e02223fd8483262228ae064ddf37d54d0d08bb386a6da523->enter($__internal_b0053ca568d7ff77e02223fd8483262228ae064ddf37d54d0d08bb386a6da523_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"container-fluid\">
    <!-- Page Heading -->
    <div class=\"row\">
        <div class=\"col-md-12\">
            <h2>
                Lekcje
            </h2>
        </div>
    </div>

    <div class=\"row\">
        <ol class=\"breadcrumb\">
            <li>
                <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
            </li>
            <li class=\"active\">
                <i class=\"fa fa-file\"></i> Lekcje
            </li>
        </ol>
    </div>
    <div>

        <div class=\"row\">
            <div class=\"col-lg-12\">
                <p>Możesz usuwać tylko lekcje dodane tego samego dnia. Jeśli musisz usunąć wcześniejszą lekcję - napisz
                    do administratora szkoły.</p>
                <h4>Kurs ";
        // line 31
        echo twig_escape_filter($this->env, $this->getAttribute(($context["course"] ?? $this->getContext($context, "course")), "courseName", array()), "html", null, true);
        echo "</h4>
                <p>Stan realizacji lekcji ";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute(($context["pagination"] ?? $this->getContext($context, "pagination")), "getTotalItemCount", array()), "html", null, true);
        echo " z ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["course"] ?? $this->getContext($context, "course")), "totalLessons", array()), "html", null, true);
        echo "</p>

                <table class=\"table\">
                    <thead class=\"thead\">
                    <tr>
                        <th>L.p.</th>
                        <th>Data lekcji</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["pagination"] ?? $this->getContext($context, "pagination")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 44
            echo "                        <tr>
                            <td>";
            // line 45
            echo twig_escape_filter($this->env, (($this->getAttribute($this->getAttribute(($context["pagination"] ?? $this->getContext($context, "pagination")), "getPaginationData", array()), "firstItemNumber", array()) + $this->getAttribute($context["loop"], "index", array())) - 1), "html", null, true);
            echo "</td>
                            <td>";
            // line 46
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["element"], "date", array()), "d-m-Y"), "html", null, true);
            echo "</td>
                            <td>

                                ";
            // line 49
            if ($this->env->getExtension('AppBundle\Twig\AppExtension')->isOneDayOld($this->getAttribute($context["element"], "dateAdded", array()))) {
                // line 50
                echo "                                <a href=\" ";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete_teacher_lesson_course", array("id" => $this->getAttribute($context["element"], "id", array()))), "html", null, true);
                echo "\">
                                    <button type=\"button\" class=\"btn btn-danger\">Usuń</button>
                                </a>
                                ";
            }
            // line 54
            echo "
                            </td>
                        </tr>
                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "                    </tbody>
                </table>
                ";
        // line 61
        echo "                <div class=\"navigation\">
                    <div class=\"text-center\">
                    ";
        // line 63
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, ($context["pagination"] ?? $this->getContext($context, "pagination")));
        echo "
                    </div>
                </div>
            </div>
        </div>
    </div>


";
        
        $__internal_b0053ca568d7ff77e02223fd8483262228ae064ddf37d54d0d08bb386a6da523->leave($__internal_b0053ca568d7ff77e02223fd8483262228ae064ddf37d54d0d08bb386a6da523_prof);

        
        $__internal_b96004935e5dfa3caf717bbe35f4a93940ad0b699bc3beb15a70e8588535eb66->leave($__internal_b96004935e5dfa3caf717bbe35f4a93940ad0b699bc3beb15a70e8588535eb66_prof);

    }

    public function getTemplateName()
    {
        return "::show_lessons.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 63,  159 => 61,  155 => 58,  138 => 54,  130 => 50,  128 => 49,  122 => 46,  118 => 45,  115 => 44,  98 => 43,  82 => 32,  78 => 31,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

    <div class=\"container-fluid\">
    <!-- Page Heading -->
    <div class=\"row\">
        <div class=\"col-md-12\">
            <h2>
                Lekcje
            </h2>
        </div>
    </div>

    <div class=\"row\">
        <ol class=\"breadcrumb\">
            <li>
                <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
            </li>
            <li class=\"active\">
                <i class=\"fa fa-file\"></i> Lekcje
            </li>
        </ol>
    </div>
    <div>

        <div class=\"row\">
            <div class=\"col-lg-12\">
                <p>Możesz usuwać tylko lekcje dodane tego samego dnia. Jeśli musisz usunąć wcześniejszą lekcję - napisz
                    do administratora szkoły.</p>
                <h4>Kurs {{ course.courseName }}</h4>
                <p>Stan realizacji lekcji {{ pagination.getTotalItemCount }} z {{ course.totalLessons }}</p>

                <table class=\"table\">
                    <thead class=\"thead\">
                    <tr>
                        <th>L.p.</th>
                        <th>Data lekcji</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    {% for element in pagination %}
                        <tr>
                            <td>{{ pagination.getPaginationData.firstItemNumber + loop.index - 1 }}</td>
                            <td>{{ element.date |date('d-m-Y') }}</td>
                            <td>

                                {% if (isOneDayOld(element.dateAdded)) %}
                                <a href=\" {{ path('delete_teacher_lesson_course', {'id':  element.id }) }}\">
                                    <button type=\"button\" class=\"btn btn-danger\">Usuń</button>
                                </a>
                                {% endif %}

                            </td>
                        </tr>
                    {% endfor %}
                    </tbody>
                </table>
                {# display navigation #}
                <div class=\"navigation\">
                    <div class=\"text-center\">
                    {{ knp_pagination_render(pagination) }}
                    </div>
                </div>
            </div>
        </div>
    </div>


{% endblock %}", "::show_lessons.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/show_lessons.html.twig");
    }
}
