<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_25634f603c3cdb4a02d6936e4655330f1bdbb6c98236b3adc29bfd217fd8e373 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5e614aae2f2864006956e75d362ed4d69f3af2ace40ab03b6120ad62f924afa9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5e614aae2f2864006956e75d362ed4d69f3af2ace40ab03b6120ad62f924afa9->enter($__internal_5e614aae2f2864006956e75d362ed4d69f3af2ace40ab03b6120ad62f924afa9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        $__internal_25a67b26eb4cf1a569ae18023c56544384d954ee45e84d6470517bc8717b4867 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_25a67b26eb4cf1a569ae18023c56544384d954ee45e84d6470517bc8717b4867->enter($__internal_25a67b26eb4cf1a569ae18023c56544384d954ee45e84d6470517bc8717b4867_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_5e614aae2f2864006956e75d362ed4d69f3af2ace40ab03b6120ad62f924afa9->leave($__internal_5e614aae2f2864006956e75d362ed4d69f3af2ace40ab03b6120ad62f924afa9_prof);

        
        $__internal_25a67b26eb4cf1a569ae18023c56544384d954ee45e84d6470517bc8717b4867->leave($__internal_25a67b26eb4cf1a569ae18023c56544384d954ee45e84d6470517bc8717b4867_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "TwigBundle:Exception:exception.css.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.css.twig");
    }
}
