<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_31c69652600870cc3fe779e7578f44d66843976ed0e7f9ca371d3975f183c069 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_901a9c658333859933de4897c1772b25851de4b3771a55adeaf4fa13cb031d1a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_901a9c658333859933de4897c1772b25851de4b3771a55adeaf4fa13cb031d1a->enter($__internal_901a9c658333859933de4897c1772b25851de4b3771a55adeaf4fa13cb031d1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        $__internal_ee061859d7114b796ea9ae6091877c5e89a523264d19e54e1d2c2d01e68752eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee061859d7114b796ea9ae6091877c5e89a523264d19e54e1d2c2d01e68752eb->enter($__internal_ee061859d7114b796ea9ae6091877c5e89a523264d19e54e1d2c2d01e68752eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_901a9c658333859933de4897c1772b25851de4b3771a55adeaf4fa13cb031d1a->leave($__internal_901a9c658333859933de4897c1772b25851de4b3771a55adeaf4fa13cb031d1a_prof);

        
        $__internal_ee061859d7114b796ea9ae6091877c5e89a523264d19e54e1d2c2d01e68752eb->leave($__internal_ee061859d7114b796ea9ae6091877c5e89a523264d19e54e1d2c2d01e68752eb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
", "@Framework/Form/choice_widget_expanded.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_widget_expanded.html.php");
    }
}
