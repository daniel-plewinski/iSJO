<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_6fad1b84f112bd4c636d05ccca454e2e6c79b51b1b3061bb42294d38887ab907 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5ef68f2fa134a4b1ec16e34ae3310fb55844396cd4c77490534afb92d8dbaaf5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ef68f2fa134a4b1ec16e34ae3310fb55844396cd4c77490534afb92d8dbaaf5->enter($__internal_5ef68f2fa134a4b1ec16e34ae3310fb55844396cd4c77490534afb92d8dbaaf5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        $__internal_96217f4ae6209a0c22723ae999cfe10bfbfa3c3f61b1b6349566128c3ff4bff3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_96217f4ae6209a0c22723ae999cfe10bfbfa3c3f61b1b6349566128c3ff4bff3->enter($__internal_96217f4ae6209a0c22723ae999cfe10bfbfa3c3f61b1b6349566128c3ff4bff3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_5ef68f2fa134a4b1ec16e34ae3310fb55844396cd4c77490534afb92d8dbaaf5->leave($__internal_5ef68f2fa134a4b1ec16e34ae3310fb55844396cd4c77490534afb92d8dbaaf5_prof);

        
        $__internal_96217f4ae6209a0c22723ae999cfe10bfbfa3c3f61b1b6349566128c3ff4bff3->leave($__internal_96217f4ae6209a0c22723ae999cfe10bfbfa3c3f61b1b6349566128c3ff4bff3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_rows.html.php");
    }
}
