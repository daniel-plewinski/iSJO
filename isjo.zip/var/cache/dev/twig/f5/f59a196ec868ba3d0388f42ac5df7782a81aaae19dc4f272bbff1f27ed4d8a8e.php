<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_08da90db87f9317d007e431c78819e06918a77318f620f08c883776e068954a6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3a5e90c35459292da6fac6bb1e3da100274acbe82ed0208337078e459de957b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3a5e90c35459292da6fac6bb1e3da100274acbe82ed0208337078e459de957b9->enter($__internal_3a5e90c35459292da6fac6bb1e3da100274acbe82ed0208337078e459de957b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_ed5afde68f1e60e6fe4368c0ec67663e26751b7a74d34a0b2c1f7770ca1187e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed5afde68f1e60e6fe4368c0ec67663e26751b7a74d34a0b2c1f7770ca1187e9->enter($__internal_ed5afde68f1e60e6fe4368c0ec67663e26751b7a74d34a0b2c1f7770ca1187e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_3a5e90c35459292da6fac6bb1e3da100274acbe82ed0208337078e459de957b9->leave($__internal_3a5e90c35459292da6fac6bb1e3da100274acbe82ed0208337078e459de957b9_prof);

        
        $__internal_ed5afde68f1e60e6fe4368c0ec67663e26751b7a74d34a0b2c1f7770ca1187e9->leave($__internal_ed5afde68f1e60e6fe4368c0ec67663e26751b7a74d34a0b2c1f7770ca1187e9_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.rdf.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
