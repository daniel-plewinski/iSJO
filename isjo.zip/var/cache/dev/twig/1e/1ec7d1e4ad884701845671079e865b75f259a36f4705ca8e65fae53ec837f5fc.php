<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_fb78a96e7b0d89984b722b7ebcef9676b9b52d60bfcadaedc2bbdd5cd16dfdd9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ffd8021ea57f387d39fc55db8612d2e129b2b2e9c23c1802f98a896bff9a6a92 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ffd8021ea57f387d39fc55db8612d2e129b2b2e9c23c1802f98a896bff9a6a92->enter($__internal_ffd8021ea57f387d39fc55db8612d2e129b2b2e9c23c1802f98a896bff9a6a92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        $__internal_f28bd9692d5cf1da3e3e917804a5c78f4ff8aae01c99d65ffc92c995365b3017 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f28bd9692d5cf1da3e3e917804a5c78f4ff8aae01c99d65ffc92c995365b3017->enter($__internal_f28bd9692d5cf1da3e3e917804a5c78f4ff8aae01c99d65ffc92c995365b3017_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_ffd8021ea57f387d39fc55db8612d2e129b2b2e9c23c1802f98a896bff9a6a92->leave($__internal_ffd8021ea57f387d39fc55db8612d2e129b2b2e9c23c1802f98a896bff9a6a92_prof);

        
        $__internal_f28bd9692d5cf1da3e3e917804a5c78f4ff8aae01c99d65ffc92c995365b3017->leave($__internal_f28bd9692d5cf1da3e3e917804a5c78f4ff8aae01c99d65ffc92c995365b3017_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
", "@Framework/Form/percent_widget.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/percent_widget.html.php");
    }
}
