<?php

/* FOSUserBundle:Profile:edit.html.twig */
class __TwigTemplate_8a08364e470b0cdd29ffa36eb327d144c68f1c67da94700ed86dfef5e00dc6e4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout-profile.html.twig", "FOSUserBundle:Profile:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout-profile.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4a28d3e9f5d8e30e82aef603b575c0145e13fcf1ce5878379e55b12d136f0872 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4a28d3e9f5d8e30e82aef603b575c0145e13fcf1ce5878379e55b12d136f0872->enter($__internal_4a28d3e9f5d8e30e82aef603b575c0145e13fcf1ce5878379e55b12d136f0872_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit.html.twig"));

        $__internal_1e9af842cf0aa25fc94e16c2c5386aa525c8f5b026a840488d94a525a7548e0e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e9af842cf0aa25fc94e16c2c5386aa525c8f5b026a840488d94a525a7548e0e->enter($__internal_1e9af842cf0aa25fc94e16c2c5386aa525c8f5b026a840488d94a525a7548e0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4a28d3e9f5d8e30e82aef603b575c0145e13fcf1ce5878379e55b12d136f0872->leave($__internal_4a28d3e9f5d8e30e82aef603b575c0145e13fcf1ce5878379e55b12d136f0872_prof);

        
        $__internal_1e9af842cf0aa25fc94e16c2c5386aa525c8f5b026a840488d94a525a7548e0e->leave($__internal_1e9af842cf0aa25fc94e16c2c5386aa525c8f5b026a840488d94a525a7548e0e_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_6046934da057fa5011a57e316858147047ebf02cd7801f3d428bf6d9fba59fd5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6046934da057fa5011a57e316858147047ebf02cd7801f3d428bf6d9fba59fd5->enter($__internal_6046934da057fa5011a57e316858147047ebf02cd7801f3d428bf6d9fba59fd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_fdd114d8bd9c8b1b02c1906aca47fe7c817969378b5cb5e313f197657ce196fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fdd114d8bd9c8b1b02c1906aca47fe7c817969378b5cb5e313f197657ce196fb->enter($__internal_fdd114d8bd9c8b1b02c1906aca47fe7c817969378b5cb5e313f197657ce196fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        $this->displayBlock('fos_user_content', $context, $blocks);
        
        $__internal_fdd114d8bd9c8b1b02c1906aca47fe7c817969378b5cb5e313f197657ce196fb->leave($__internal_fdd114d8bd9c8b1b02c1906aca47fe7c817969378b5cb5e313f197657ce196fb_prof);

        
        $__internal_6046934da057fa5011a57e316858147047ebf02cd7801f3d428bf6d9fba59fd5->leave($__internal_6046934da057fa5011a57e316858147047ebf02cd7801f3d428bf6d9fba59fd5_prof);

    }

    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_094632ea7371e767192aefa42a5ee298c7d0b38117983c3fbacd909b6caa55b0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_094632ea7371e767192aefa42a5ee298c7d0b38117983c3fbacd909b6caa55b0->enter($__internal_094632ea7371e767192aefa42a5ee298c7d0b38117983c3fbacd909b6caa55b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_5be5aaf6d0438fde2be35b9230f5fd7e25791ad632c0d09d01b00bf2dae86c00 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5be5aaf6d0438fde2be35b9230f5fd7e25791ad632c0d09d01b00bf2dae86c00->enter($__internal_5be5aaf6d0438fde2be35b9230f5fd7e25791ad632c0d09d01b00bf2dae86c00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 5
        $this->loadTemplate("@FOSUser/Profile/edit_content.html.twig", "FOSUserBundle:Profile:edit.html.twig", 5)->display($context);
        
        $__internal_5be5aaf6d0438fde2be35b9230f5fd7e25791ad632c0d09d01b00bf2dae86c00->leave($__internal_5be5aaf6d0438fde2be35b9230f5fd7e25791ad632c0d09d01b00bf2dae86c00_prof);

        
        $__internal_094632ea7371e767192aefa42a5ee298c7d0b38117983c3fbacd909b6caa55b0->leave($__internal_094632ea7371e767192aefa42a5ee298c7d0b38117983c3fbacd909b6caa55b0_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout-profile.html.twig\" %}

{% block body %}
{% block fos_user_content %}
{% include \"@FOSUser/Profile/edit_content.html.twig\" %}
{% endblock fos_user_content %}
{% endblock %}
", "FOSUserBundle:Profile:edit.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Profile/edit.html.twig");
    }
}
