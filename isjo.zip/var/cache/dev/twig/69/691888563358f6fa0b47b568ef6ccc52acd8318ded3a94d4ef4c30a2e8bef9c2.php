<?php

/* ::choose_overview_settlement_date.html.twig */
class __TwigTemplate_5b22657abf5f250a687cad237ab697f85ceeea95e578b46f26695da3030b156f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::choose_overview_settlement_date.html.twig", 1);
        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_069163db34f990f98c4a904f68926f33c2b4ef194c8078e2722f4851a76ec9a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_069163db34f990f98c4a904f68926f33c2b4ef194c8078e2722f4851a76ec9a9->enter($__internal_069163db34f990f98c4a904f68926f33c2b4ef194c8078e2722f4851a76ec9a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::choose_overview_settlement_date.html.twig"));

        $__internal_1ea630fcda04948d82128e4bd2bfad1ea89f1d0041c8eb40d3de3e1619717725 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1ea630fcda04948d82128e4bd2bfad1ea89f1d0041c8eb40d3de3e1619717725->enter($__internal_1ea630fcda04948d82128e4bd2bfad1ea89f1d0041c8eb40d3de3e1619717725_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::choose_overview_settlement_date.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_069163db34f990f98c4a904f68926f33c2b4ef194c8078e2722f4851a76ec9a9->leave($__internal_069163db34f990f98c4a904f68926f33c2b4ef194c8078e2722f4851a76ec9a9_prof);

        
        $__internal_1ea630fcda04948d82128e4bd2bfad1ea89f1d0041c8eb40d3de3e1619717725->leave($__internal_1ea630fcda04948d82128e4bd2bfad1ea89f1d0041c8eb40d3de3e1619717725_prof);

    }

    // line 3
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_7dca2b1160dc5a3e3899b2a3a40e52faae321a0a5c3740f9688de14acfb303de = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7dca2b1160dc5a3e3899b2a3a40e52faae321a0a5c3740f9688de14acfb303de->enter($__internal_7dca2b1160dc5a3e3899b2a3a40e52faae321a0a5c3740f9688de14acfb303de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_5c85cef0a2f629ca4485aa58759cfa3b2a4287f4cff07d60c90a0ad19b5e2f11 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c85cef0a2f629ca4485aa58759cfa3b2a4287f4cff07d60c90a0ad19b5e2f11->enter($__internal_5c85cef0a2f629ca4485aa58759cfa3b2a4287f4cff07d60c90a0ad19b5e2f11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 4
        echo "
    ";
        // line 5
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

";
        
        $__internal_5c85cef0a2f629ca4485aa58759cfa3b2a4287f4cff07d60c90a0ad19b5e2f11->leave($__internal_5c85cef0a2f629ca4485aa58759cfa3b2a4287f4cff07d60c90a0ad19b5e2f11_prof);

        
        $__internal_7dca2b1160dc5a3e3899b2a3a40e52faae321a0a5c3740f9688de14acfb303de->leave($__internal_7dca2b1160dc5a3e3899b2a3a40e52faae321a0a5c3740f9688de14acfb303de_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_11b62f466865f9a79118486cb2e06cbeec77bd51cbb172362440d535789445ef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_11b62f466865f9a79118486cb2e06cbeec77bd51cbb172362440d535789445ef->enter($__internal_11b62f466865f9a79118486cb2e06cbeec77bd51cbb172362440d535789445ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_34b71527ff87cb828e76908f82c5637bb2c73055249e0246eae044e925d93518 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_34b71527ff87cb828e76908f82c5637bb2c73055249e0246eae044e925d93518->enter($__internal_34b71527ff87cb828e76908f82c5637bb2c73055249e0246eae044e925d93518_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "

    <div class=\"container-fluid\">

        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Wybierz okres rozliczenia
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Lista kursów
                </li>
            </ol>
        </div>


        ";
        // line 35
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
        <table class=\"centered-table\">
            <tr>
                <th class=\"td-right-padding\">";
        // line 38
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "year", array()), 'label');
        echo "</th>
                <th>";
        // line 39
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "month", array()), 'label');
        echo "</th>
            </tr>
            <tr>
                <td class=\"td-right-padding\">";
        // line 42
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "year", array()), 'widget', array("value" => twig_date_format_filter($this->env, "now", "Y")));
        echo "</td>
                <td>";
        // line 43
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "month", array()), 'widget', array("value" => twig_date_format_filter($this->env, "now", "m")));
        echo "</td>
            </tr>
            <tr>
                <td colspan=\"2\" class=\"text-center\">";
        // line 46
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "submit", array()), 'widget');
        echo "</td>
            </tr>

        </table>



        ";
        // line 53
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

    </div>

";
        
        $__internal_34b71527ff87cb828e76908f82c5637bb2c73055249e0246eae044e925d93518->leave($__internal_34b71527ff87cb828e76908f82c5637bb2c73055249e0246eae044e925d93518_prof);

        
        $__internal_11b62f466865f9a79118486cb2e06cbeec77bd51cbb172362440d535789445ef->leave($__internal_11b62f466865f9a79118486cb2e06cbeec77bd51cbb172362440d535789445ef_prof);

    }

    public function getTemplateName()
    {
        return "::choose_overview_settlement_date.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 53,  128 => 46,  122 => 43,  118 => 42,  112 => 39,  108 => 38,  102 => 35,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block javascripts %}

    {{ parent() }}

{% endblock %}

{% block body %}


    <div class=\"container-fluid\">

        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Wybierz okres rozliczenia
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Lista kursów
                </li>
            </ol>
        </div>


        {{ form_start(form) }}
        <table class=\"centered-table\">
            <tr>
                <th class=\"td-right-padding\">{{ form_label(form.year) }}</th>
                <th>{{ form_label(form.month) }}</th>
            </tr>
            <tr>
                <td class=\"td-right-padding\">{{ form_widget(form.year, { 'value': \"now\"|date(\"Y\")} ) }}</td>
                <td>{{ form_widget(form.month, { 'value': \"now\"|date(\"m\")} ) }}</td>
            </tr>
            <tr>
                <td colspan=\"2\" class=\"text-center\">{{ form_widget(form.submit) }}</td>
            </tr>

        </table>



        {{ form_end(form) }}

    </div>

{% endblock %}", "::choose_overview_settlement_date.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/choose_overview_settlement_date.html.twig");
    }
}
