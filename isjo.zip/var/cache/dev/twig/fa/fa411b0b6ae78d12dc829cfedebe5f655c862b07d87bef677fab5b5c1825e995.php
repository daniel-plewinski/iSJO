<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_12c08fd2698f6434da1a0bfbac77af78e56847ee0b5159b0cb7f98e9300fcdba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_771fa7a1f30e34523d047fa9ecd065541b74f02c0db17151e4d938a2edf37bb5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_771fa7a1f30e34523d047fa9ecd065541b74f02c0db17151e4d938a2edf37bb5->enter($__internal_771fa7a1f30e34523d047fa9ecd065541b74f02c0db17151e4d938a2edf37bb5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        $__internal_70baaf456d3d8dad9d69ef04d8621cc3d33551c0d12aaa18d678aba90420d9b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_70baaf456d3d8dad9d69ef04d8621cc3d33551c0d12aaa18d678aba90420d9b0->enter($__internal_70baaf456d3d8dad9d69ef04d8621cc3d33551c0d12aaa18d678aba90420d9b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes'); ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form); ?>
        </td>
    </tr>
    <?php endif; ?>
    <?php echo \$view['form']->block(\$form, 'form_rows'); ?>
    <?php echo \$view['form']->rest(\$form); ?>
</table>
";
        
        $__internal_771fa7a1f30e34523d047fa9ecd065541b74f02c0db17151e4d938a2edf37bb5->leave($__internal_771fa7a1f30e34523d047fa9ecd065541b74f02c0db17151e4d938a2edf37bb5_prof);

        
        $__internal_70baaf456d3d8dad9d69ef04d8621cc3d33551c0d12aaa18d678aba90420d9b0->leave($__internal_70baaf456d3d8dad9d69ef04d8621cc3d33551c0d12aaa18d678aba90420d9b0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes'); ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form); ?>
        </td>
    </tr>
    <?php endif; ?>
    <?php echo \$view['form']->block(\$form, 'form_rows'); ?>
    <?php echo \$view['form']->rest(\$form); ?>
</table>
", "@Framework/FormTable/form_widget_compound.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/form_widget_compound.html.php");
    }
}
