<?php

/* show_school_teacher_settlement.twig */
class __TwigTemplate_0ff0a8488aea70f2a775fe137c9acc358540d9922152e968eb1dea6cd137f3e7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "show_school_teacher_settlement.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9098c21a1403b6061ea1c2bb90959a98d5d8f6ef362ebe65f2bbbcbf2badd0ec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9098c21a1403b6061ea1c2bb90959a98d5d8f6ef362ebe65f2bbbcbf2badd0ec->enter($__internal_9098c21a1403b6061ea1c2bb90959a98d5d8f6ef362ebe65f2bbbcbf2badd0ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "show_school_teacher_settlement.twig"));

        $__internal_a962b2f4d8d7810726ac5e894192c872b7d0efa19d52f9fe97d7a328092746df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a962b2f4d8d7810726ac5e894192c872b7d0efa19d52f9fe97d7a328092746df->enter($__internal_a962b2f4d8d7810726ac5e894192c872b7d0efa19d52f9fe97d7a328092746df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "show_school_teacher_settlement.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9098c21a1403b6061ea1c2bb90959a98d5d8f6ef362ebe65f2bbbcbf2badd0ec->leave($__internal_9098c21a1403b6061ea1c2bb90959a98d5d8f6ef362ebe65f2bbbcbf2badd0ec_prof);

        
        $__internal_a962b2f4d8d7810726ac5e894192c872b7d0efa19d52f9fe97d7a328092746df->leave($__internal_a962b2f4d8d7810726ac5e894192c872b7d0efa19d52f9fe97d7a328092746df_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_ade836dcf51474d5197598938589ea47f0286f082f4d34c73c0528bb0789eafe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ade836dcf51474d5197598938589ea47f0286f082f4d34c73c0528bb0789eafe->enter($__internal_ade836dcf51474d5197598938589ea47f0286f082f4d34c73c0528bb0789eafe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_bca0a5669485e1ea756abafbe7e47a38aaed3c1a362f000e968ffbcea8962d96 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bca0a5669485e1ea756abafbe7e47a38aaed3c1a362f000e968ffbcea8962d96->enter($__internal_bca0a5669485e1ea756abafbe7e47a38aaed3c1a362f000e968ffbcea8962d96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Rozliczenie za ";
        // line 10
        echo twig_escape_filter($this->env, ($context["month"] ?? $this->getContext($context, "month")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["year"] ?? $this->getContext($context, "year")), "html", null, true);
        echo "
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Rozliczenie</a>
                </li>
            </ol>
        </div>

        <h3>Podsumowanie</h3>
        <table class=\"table\">
            <tr>
                <td class=\"short-td\">Liczba przeprowadzonych lekcji</td>
                <th>";
        // line 27
        echo twig_escape_filter($this->env, twig_length_filter($this->env, ($context["lessons"] ?? $this->getContext($context, "lessons"))), "html", null, true);
        echo "</th>
            </tr>
            <tr>
                <td class=\"short-td\">Liczba kursów</td>
                <th>";
        // line 31
        echo twig_escape_filter($this->env, ($context["courseCount"] ?? $this->getContext($context, "courseCount")), "html", null, true);
        echo "</th>
            </tr>
            <tr>
                <td class=\"short-td\">Do wypłaty brutto</td>
                <th>";
        // line 35
        echo twig_escape_filter($this->env, ($context["salary"] ?? $this->getContext($context, "salary")), "html", null, true);
        echo "</th>
            </tr>
        </table>


        <h3>Przeprowadzone lekcje</h3>

        <table class=\"table\">
            <thead class=\"thead\">
            <tr>
                <th>L.p.</th>
                <th>Data lekcji</th>
                <th>Stawka za lekcję</th>
                <th>Nazwa kursu</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 52
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["lessons"] ?? $this->getContext($context, "lessons")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 53
            echo "                <tr>
                    <td>";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 55
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["element"], "date", array()), "Y-d-m"), "html", null, true);
            echo "</td>
                    <td>";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "teacher_rate", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "course_name", array()), "html", null, true);
            echo "</td>
                </tr>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 60
        echo "            </tbody>
        </table>
    </div>




";
        
        $__internal_bca0a5669485e1ea756abafbe7e47a38aaed3c1a362f000e968ffbcea8962d96->leave($__internal_bca0a5669485e1ea756abafbe7e47a38aaed3c1a362f000e968ffbcea8962d96_prof);

        
        $__internal_ade836dcf51474d5197598938589ea47f0286f082f4d34c73c0528bb0789eafe->leave($__internal_ade836dcf51474d5197598938589ea47f0286f082f4d34c73c0528bb0789eafe_prof);

    }

    public function getTemplateName()
    {
        return "show_school_teacher_settlement.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  162 => 60,  145 => 57,  141 => 56,  137 => 55,  133 => 54,  130 => 53,  113 => 52,  93 => 35,  86 => 31,  79 => 27,  57 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Rozliczenie za {{ month }} {{ year }}
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Rozliczenie</a>
                </li>
            </ol>
        </div>

        <h3>Podsumowanie</h3>
        <table class=\"table\">
            <tr>
                <td class=\"short-td\">Liczba przeprowadzonych lekcji</td>
                <th>{{ lessons | length }}</th>
            </tr>
            <tr>
                <td class=\"short-td\">Liczba kursów</td>
                <th>{{ courseCount }}</th>
            </tr>
            <tr>
                <td class=\"short-td\">Do wypłaty brutto</td>
                <th>{{ salary }}</th>
            </tr>
        </table>


        <h3>Przeprowadzone lekcje</h3>

        <table class=\"table\">
            <thead class=\"thead\">
            <tr>
                <th>L.p.</th>
                <th>Data lekcji</th>
                <th>Stawka za lekcję</th>
                <th>Nazwa kursu</th>
            </tr>
            </thead>
            <tbody>
            {% for element in  lessons %}
                <tr>
                    <td>{{ loop.index }}</td>
                    <td>{{ element.date | date('Y-d-m') }}</td>
                    <td>{{ element.teacher_rate }}</td>
                    <td>{{ element.course_name }}</td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>




{% endblock %}", "show_school_teacher_settlement.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/show_school_teacher_settlement.twig");
    }
}
