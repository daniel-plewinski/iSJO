<?php

/* FOSUserBundle:Group:list.html.twig */
class __TwigTemplate_052f76e59ff3bb6a82d9b9853ae310fb99fa92343873f2f664c25fd0ccb47c04 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_819057c591339f50f25cb8fe3d3b4c09a9e8042ef27735b88d45477ee61da781 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_819057c591339f50f25cb8fe3d3b4c09a9e8042ef27735b88d45477ee61da781->enter($__internal_819057c591339f50f25cb8fe3d3b4c09a9e8042ef27735b88d45477ee61da781_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $__internal_fd8bb006bac0991aacc9be8a617bd11034a34aebd85a7f135868720424d7cb34 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd8bb006bac0991aacc9be8a617bd11034a34aebd85a7f135868720424d7cb34->enter($__internal_fd8bb006bac0991aacc9be8a617bd11034a34aebd85a7f135868720424d7cb34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_819057c591339f50f25cb8fe3d3b4c09a9e8042ef27735b88d45477ee61da781->leave($__internal_819057c591339f50f25cb8fe3d3b4c09a9e8042ef27735b88d45477ee61da781_prof);

        
        $__internal_fd8bb006bac0991aacc9be8a617bd11034a34aebd85a7f135868720424d7cb34->leave($__internal_fd8bb006bac0991aacc9be8a617bd11034a34aebd85a7f135868720424d7cb34_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_b141d3e1005543a6f5f39386090eb84d2d7b23feb1063ac0eac3f222c3f2ba28 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b141d3e1005543a6f5f39386090eb84d2d7b23feb1063ac0eac3f222c3f2ba28->enter($__internal_b141d3e1005543a6f5f39386090eb84d2d7b23feb1063ac0eac3f222c3f2ba28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_17ea4b542af755b4e133deef9afeb0cc762d75e9e37c2cc75ea894b2b23368e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_17ea4b542af755b4e133deef9afeb0cc762d75e9e37c2cc75ea894b2b23368e0->enter($__internal_17ea4b542af755b4e133deef9afeb0cc762d75e9e37c2cc75ea894b2b23368e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/list_content.html.twig", "FOSUserBundle:Group:list.html.twig", 4)->display($context);
        
        $__internal_17ea4b542af755b4e133deef9afeb0cc762d75e9e37c2cc75ea894b2b23368e0->leave($__internal_17ea4b542af755b4e133deef9afeb0cc762d75e9e37c2cc75ea894b2b23368e0_prof);

        
        $__internal_b141d3e1005543a6f5f39386090eb84d2d7b23feb1063ac0eac3f222c3f2ba28->leave($__internal_b141d3e1005543a6f5f39386090eb84d2d7b23feb1063ac0eac3f222c3f2ba28_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/list_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:list.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Group/list.html.twig");
    }
}
