<?php

/* FOSUserBundle:Registration:email.txt.twig */
class __TwigTemplate_e0648391789c70c718be315f4ae91dcdda4a4633b03fbef0e6111f92e52017d2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d59ab5eb489fc702ad1a2f31e0fc6bbe2c90ca3e727e64d9eb7e4185b730d5c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7d59ab5eb489fc702ad1a2f31e0fc6bbe2c90ca3e727e64d9eb7e4185b730d5c->enter($__internal_7d59ab5eb489fc702ad1a2f31e0fc6bbe2c90ca3e727e64d9eb7e4185b730d5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        $__internal_387d2e46906e86fee48b16083a9d800c3c67bc2640441e4c9a0fdbb771e084cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_387d2e46906e86fee48b16083a9d800c3c67bc2640441e4c9a0fdbb771e084cb->enter($__internal_387d2e46906e86fee48b16083a9d800c3c67bc2640441e4c9a0fdbb771e084cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('body_text', $context, $blocks);
        // line 13
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_7d59ab5eb489fc702ad1a2f31e0fc6bbe2c90ca3e727e64d9eb7e4185b730d5c->leave($__internal_7d59ab5eb489fc702ad1a2f31e0fc6bbe2c90ca3e727e64d9eb7e4185b730d5c_prof);

        
        $__internal_387d2e46906e86fee48b16083a9d800c3c67bc2640441e4c9a0fdbb771e084cb->leave($__internal_387d2e46906e86fee48b16083a9d800c3c67bc2640441e4c9a0fdbb771e084cb_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_bcad3dcb78c9d5389fe9e3c8ceaee6203e0f3a31a0dfee1e8c3b7622403bc61f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bcad3dcb78c9d5389fe9e3c8ceaee6203e0f3a31a0dfee1e8c3b7622403bc61f->enter($__internal_bcad3dcb78c9d5389fe9e3c8ceaee6203e0f3a31a0dfee1e8c3b7622403bc61f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        $__internal_9853b807fb4d46492db00cf422d1f8ea84b57c288a2d137a3df4a7f213bfb2ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9853b807fb4d46492db00cf422d1f8ea84b57c288a2d137a3df4a7f213bfb2ad->enter($__internal_9853b807fb4d46492db00cf422d1f8ea84b57c288a2d137a3df4a7f213bfb2ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.email.subject", array("%username%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => ($context["confirmationUrl"] ?? $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        
        $__internal_9853b807fb4d46492db00cf422d1f8ea84b57c288a2d137a3df4a7f213bfb2ad->leave($__internal_9853b807fb4d46492db00cf422d1f8ea84b57c288a2d137a3df4a7f213bfb2ad_prof);

        
        $__internal_bcad3dcb78c9d5389fe9e3c8ceaee6203e0f3a31a0dfee1e8c3b7622403bc61f->leave($__internal_bcad3dcb78c9d5389fe9e3c8ceaee6203e0f3a31a0dfee1e8c3b7622403bc61f_prof);

    }

    // line 8
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_51f4b23a5ff1795a5f78b27a7432e3dcf4abaeb7e155287a879c0d35afadc785 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_51f4b23a5ff1795a5f78b27a7432e3dcf4abaeb7e155287a879c0d35afadc785->enter($__internal_51f4b23a5ff1795a5f78b27a7432e3dcf4abaeb7e155287a879c0d35afadc785_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        $__internal_dc213dfa26acbdc28f4692ed1d11a89b622e419b6d523f530f11268a5a581962 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dc213dfa26acbdc28f4692ed1d11a89b622e419b6d523f530f11268a5a581962->enter($__internal_dc213dfa26acbdc28f4692ed1d11a89b622e419b6d523f530f11268a5a581962_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.email.message", array("%username%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => ($context["confirmationUrl"] ?? $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_dc213dfa26acbdc28f4692ed1d11a89b622e419b6d523f530f11268a5a581962->leave($__internal_dc213dfa26acbdc28f4692ed1d11a89b622e419b6d523f530f11268a5a581962_prof);

        
        $__internal_51f4b23a5ff1795a5f78b27a7432e3dcf4abaeb7e155287a879c0d35afadc785->leave($__internal_51f4b23a5ff1795a5f78b27a7432e3dcf4abaeb7e155287a879c0d35afadc785_prof);

    }

    // line 13
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_c7aff5bdfcd49452e8c910bec09889674e66ed5eb78b43722bcf28925636a16d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c7aff5bdfcd49452e8c910bec09889674e66ed5eb78b43722bcf28925636a16d->enter($__internal_c7aff5bdfcd49452e8c910bec09889674e66ed5eb78b43722bcf28925636a16d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        $__internal_6c2b279d4ec98833e10b3c4ef6a545c888d4f37bd11a84dc169ef7625f8a4186 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c2b279d4ec98833e10b3c4ef6a545c888d4f37bd11a84dc169ef7625f8a4186->enter($__internal_6c2b279d4ec98833e10b3c4ef6a545c888d4f37bd11a84dc169ef7625f8a4186_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_6c2b279d4ec98833e10b3c4ef6a545c888d4f37bd11a84dc169ef7625f8a4186->leave($__internal_6c2b279d4ec98833e10b3c4ef6a545c888d4f37bd11a84dc169ef7625f8a4186_prof);

        
        $__internal_c7aff5bdfcd49452e8c910bec09889674e66ed5eb78b43722bcf28925636a16d->leave($__internal_c7aff5bdfcd49452e8c910bec09889674e66ed5eb78b43722bcf28925636a16d_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  85 => 13,  73 => 10,  64 => 8,  54 => 4,  45 => 2,  35 => 13,  33 => 8,  30 => 7,  28 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}
{% block subject %}
{%- autoescape false -%}
{{ 'registration.email.subject'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{%- endautoescape -%}
{% endblock %}

{% block body_text %}
{% autoescape false %}
{{ 'registration.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endautoescape %}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Registration:email.txt.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Registration/email.txt.twig");
    }
}
