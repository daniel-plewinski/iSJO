<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_a4223ef3f7522cccd9720f200562d10c3c6e5b3e807ff62607ba74f1413cfd3b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cc163bfdb1c3c4d5d9431c92db6defa4f14950eeb330120b0c3f2612c69cf6be = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cc163bfdb1c3c4d5d9431c92db6defa4f14950eeb330120b0c3f2612c69cf6be->enter($__internal_cc163bfdb1c3c4d5d9431c92db6defa4f14950eeb330120b0c3f2612c69cf6be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_75035a22801a1a7d1fdb7195d30c448d8f8fe082b3de663837f7ff7d06e8b3be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_75035a22801a1a7d1fdb7195d30c448d8f8fe082b3de663837f7ff7d06e8b3be->enter($__internal_75035a22801a1a7d1fdb7195d30c448d8f8fe082b3de663837f7ff7d06e8b3be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_cc163bfdb1c3c4d5d9431c92db6defa4f14950eeb330120b0c3f2612c69cf6be->leave($__internal_cc163bfdb1c3c4d5d9431c92db6defa4f14950eeb330120b0c3f2612c69cf6be_prof);

        
        $__internal_75035a22801a1a7d1fdb7195d30c448d8f8fe082b3de663837f7ff7d06e8b3be->leave($__internal_75035a22801a1a7d1fdb7195d30c448d8f8fe082b3de663837f7ff7d06e8b3be_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.atom.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
