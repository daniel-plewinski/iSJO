<?php

/* ::show_overview_settlement.html.twig */
class __TwigTemplate_a00ddc457e444b6997cc499cce95b5012d0a7b01ed44f4816b2697e31c5d71eb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::show_overview_settlement.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7bdb007439470ef6fe5888641b16612399de4d0b9cc44690a76e29682ee71143 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7bdb007439470ef6fe5888641b16612399de4d0b9cc44690a76e29682ee71143->enter($__internal_7bdb007439470ef6fe5888641b16612399de4d0b9cc44690a76e29682ee71143_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::show_overview_settlement.html.twig"));

        $__internal_dd94a43c6130dfe356830302f48ece77c57a58f1428ea292a1271af1ffbb7b6c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd94a43c6130dfe356830302f48ece77c57a58f1428ea292a1271af1ffbb7b6c->enter($__internal_dd94a43c6130dfe356830302f48ece77c57a58f1428ea292a1271af1ffbb7b6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::show_overview_settlement.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7bdb007439470ef6fe5888641b16612399de4d0b9cc44690a76e29682ee71143->leave($__internal_7bdb007439470ef6fe5888641b16612399de4d0b9cc44690a76e29682ee71143_prof);

        
        $__internal_dd94a43c6130dfe356830302f48ece77c57a58f1428ea292a1271af1ffbb7b6c->leave($__internal_dd94a43c6130dfe356830302f48ece77c57a58f1428ea292a1271af1ffbb7b6c_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_a436061e5237648fed1fc7970d4467f4cad0b968049b15f3ec20a5f13033e9fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a436061e5237648fed1fc7970d4467f4cad0b968049b15f3ec20a5f13033e9fe->enter($__internal_a436061e5237648fed1fc7970d4467f4cad0b968049b15f3ec20a5f13033e9fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_aa0cdffa8a7464624a1953361a71b2fac7cd92f2e1c8d029b59f50bc05ea1383 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa0cdffa8a7464624a1953361a71b2fac7cd92f2e1c8d029b59f50bc05ea1383->enter($__internal_aa0cdffa8a7464624a1953361a71b2fac7cd92f2e1c8d029b59f50bc05ea1383_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Rozliczenie za ";
        // line 10
        echo twig_escape_filter($this->env, ($context["month"] ?? $this->getContext($context, "month")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["year"] ?? $this->getContext($context, "year")), "html", null, true);
        echo "
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Rozliczenie</a>
                </li>
            </ol>
        </div>

        <h3>Podsumowanie</h3>
        <table class=\"table\">
            <tr>
                <td class=\"short-td\">Razem do wypłaty brutto</td>
                <th>";
        // line 27
        echo twig_escape_filter($this->env, ($context["totalSalary"] ?? $this->getContext($context, "totalSalary")), "html", null, true);
        echo "</th>
            </tr>
            <tr>
                <td class=\"short-td\">Łączna liczba kursów</td>
                <th>";
        // line 31
        echo twig_escape_filter($this->env, ($context["courseCount"] ?? $this->getContext($context, "courseCount")), "html", null, true);
        echo "</th>
            </tr>
            <tr>
                <td class=\"short-td\">Łączna liczba lekcji</td>
                <th>";
        // line 35
        echo twig_escape_filter($this->env, ($context["lessonCount"] ?? $this->getContext($context, "lessonCount")), "html", null, true);
        echo "</th>
            </tr>
        </table>

        <h3>Wynagrodzenie nauczycieli</h3>
        <table class=\"table\">
            ";
        // line 41
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["salaryByTeachers"] ?? $this->getContext($context, "salaryByTeachers")));
        foreach ($context['_seq'] as $context["index"] => $context["key"]) {
            // line 42
            echo "            <tr>
                <td class=\"short-td\">";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["key"], "name", array(), "array"), "html", null, true);
            echo "</td>
                <th>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["key"], "salary", array(), "array"), "html", null, true);
            echo "</th>
            </tr>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['index'], $context['key'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "        </table>





";
        
        $__internal_aa0cdffa8a7464624a1953361a71b2fac7cd92f2e1c8d029b59f50bc05ea1383->leave($__internal_aa0cdffa8a7464624a1953361a71b2fac7cd92f2e1c8d029b59f50bc05ea1383_prof);

        
        $__internal_a436061e5237648fed1fc7970d4467f4cad0b968049b15f3ec20a5f13033e9fe->leave($__internal_a436061e5237648fed1fc7970d4467f4cad0b968049b15f3ec20a5f13033e9fe_prof);

    }

    public function getTemplateName()
    {
        return "::show_overview_settlement.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  122 => 47,  113 => 44,  109 => 43,  106 => 42,  102 => 41,  93 => 35,  86 => 31,  79 => 27,  57 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Rozliczenie za {{ month }} {{ year }}
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Rozliczenie</a>
                </li>
            </ol>
        </div>

        <h3>Podsumowanie</h3>
        <table class=\"table\">
            <tr>
                <td class=\"short-td\">Razem do wypłaty brutto</td>
                <th>{{ totalSalary }}</th>
            </tr>
            <tr>
                <td class=\"short-td\">Łączna liczba kursów</td>
                <th>{{ courseCount }}</th>
            </tr>
            <tr>
                <td class=\"short-td\">Łączna liczba lekcji</td>
                <th>{{ lessonCount }}</th>
            </tr>
        </table>

        <h3>Wynagrodzenie nauczycieli</h3>
        <table class=\"table\">
            {% for index,  key in salaryByTeachers %}
            <tr>
                <td class=\"short-td\">{{ key['name'] }}</td>
                <th>{{ key['salary'] }}</th>
            </tr>
          {% endfor %}
        </table>





{% endblock %}", "::show_overview_settlement.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/show_overview_settlement.html.twig");
    }
}
