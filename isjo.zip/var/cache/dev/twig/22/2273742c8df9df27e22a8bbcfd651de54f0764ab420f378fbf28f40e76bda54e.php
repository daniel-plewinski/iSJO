<?php

/* ::index_school.html.twig */
class __TwigTemplate_7d93597851ea4c8977397b483d202300cec93e77ff4b1b520f40bb89327673b6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::index_school.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_96637a9c772efd56ca9240618beb49300bb1319a93c627abaa7547de93070195 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_96637a9c772efd56ca9240618beb49300bb1319a93c627abaa7547de93070195->enter($__internal_96637a9c772efd56ca9240618beb49300bb1319a93c627abaa7547de93070195_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::index_school.html.twig"));

        $__internal_ec3ff23c3dfb80b0093133f95ca64795b9b89e59ddddd69766fafb9467d972bf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec3ff23c3dfb80b0093133f95ca64795b9b89e59ddddd69766fafb9467d972bf->enter($__internal_ec3ff23c3dfb80b0093133f95ca64795b9b89e59ddddd69766fafb9467d972bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::index_school.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_96637a9c772efd56ca9240618beb49300bb1319a93c627abaa7547de93070195->leave($__internal_96637a9c772efd56ca9240618beb49300bb1319a93c627abaa7547de93070195_prof);

        
        $__internal_ec3ff23c3dfb80b0093133f95ca64795b9b89e59ddddd69766fafb9467d972bf->leave($__internal_ec3ff23c3dfb80b0093133f95ca64795b9b89e59ddddd69766fafb9467d972bf_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_d6220b32392c4a205b0e655f878a39a980b2837bea803a1ce37e78008fec0c0b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d6220b32392c4a205b0e655f878a39a980b2837bea803a1ce37e78008fec0c0b->enter($__internal_d6220b32392c4a205b0e655f878a39a980b2837bea803a1ce37e78008fec0c0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_cf6d2b323347c840353e5660926f8963bd016895588be44ab36e18a91e711877 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf6d2b323347c840353e5660926f8963bd016895588be44ab36e18a91e711877->enter($__internal_cf6d2b323347c840353e5660926f8963bd016895588be44ab36e18a91e711877_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <!-- Page Heading -->
    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h2>
                Podsumowanie
            </h2>

            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"jumbotron jumbotron-fluid jumbotron-low\">
        <div class=\"container\">
            <h1 class=\"display-4\">Szkoła ";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "name", array()), "html", null, true);
        echo "</h1>
            <p class=\"lead\">Liczba nauczycieli: <b>";
        // line 24
        echo twig_escape_filter($this->env, ($context["teacherNo"] ?? $this->getContext($context, "teacherNo")), "html", null, true);
        echo "</b>. Lczba kursów: <b>";
        echo twig_escape_filter($this->env, ($context["courseNo"] ?? $this->getContext($context, "courseNo")), "html", null, true);
        echo "</b>.</p>
        </div>
    </div>

";
        
        $__internal_cf6d2b323347c840353e5660926f8963bd016895588be44ab36e18a91e711877->leave($__internal_cf6d2b323347c840353e5660926f8963bd016895588be44ab36e18a91e711877_prof);

        
        $__internal_d6220b32392c4a205b0e655f878a39a980b2837bea803a1ce37e78008fec0c0b->leave($__internal_d6220b32392c4a205b0e655f878a39a980b2837bea803a1ce37e78008fec0c0b_prof);

    }

    public function getTemplateName()
    {
        return "::index_school.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 24,  69 => 23,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

    <!-- Page Heading -->
    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h2>
                Podsumowanie
            </h2>

            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"jumbotron jumbotron-fluid jumbotron-low\">
        <div class=\"container\">
            <h1 class=\"display-4\">Szkoła {{ app.user.name }}</h1>
            <p class=\"lead\">Liczba nauczycieli: <b>{{ teacherNo }}</b>. Lczba kursów: <b>{{ courseNo }}</b>.</p>
        </div>
    </div>

{% endblock %}", "::index_school.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/index_school.html.twig");
    }
}
