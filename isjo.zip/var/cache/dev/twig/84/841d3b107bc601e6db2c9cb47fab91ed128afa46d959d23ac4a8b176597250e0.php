<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_8b6f69f623ca28801fa1bd4f695e897cc1d7fb0b5973f8e812220bb46f839b8a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dd37339801532891ad26d0f6c5669f5fae4da1ee9fb94087793e76f6177f322a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dd37339801532891ad26d0f6c5669f5fae4da1ee9fb94087793e76f6177f322a->enter($__internal_dd37339801532891ad26d0f6c5669f5fae4da1ee9fb94087793e76f6177f322a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_266759840218e78f1c69aa06ec1fc5e158a643af4844e2d699f0dda35bf52964 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_266759840218e78f1c69aa06ec1fc5e158a643af4844e2d699f0dda35bf52964->enter($__internal_266759840218e78f1c69aa06ec1fc5e158a643af4844e2d699f0dda35bf52964_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_dd37339801532891ad26d0f6c5669f5fae4da1ee9fb94087793e76f6177f322a->leave($__internal_dd37339801532891ad26d0f6c5669f5fae4da1ee9fb94087793e76f6177f322a_prof);

        
        $__internal_266759840218e78f1c69aa06ec1fc5e158a643af4844e2d699f0dda35bf52964->leave($__internal_266759840218e78f1c69aa06ec1fc5e158a643af4844e2d699f0dda35bf52964_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/textarea_widget.html.php");
    }
}
