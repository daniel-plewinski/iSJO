<?php

/* FOSUserBundle:Resetting:email.txt.twig */
class __TwigTemplate_c05a599fbad1bf42dbd2787c50f984d39897600906443fa8d637210270bfd986 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f3fe81306a5a666b764b2c76b2c48588736cd331adadffc693e7790b1cc4a84a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f3fe81306a5a666b764b2c76b2c48588736cd331adadffc693e7790b1cc4a84a->enter($__internal_f3fe81306a5a666b764b2c76b2c48588736cd331adadffc693e7790b1cc4a84a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        $__internal_4a81a5a92ea5519160e6605124f7077a202f87dd204dc476900bcd3370cbe633 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4a81a5a92ea5519160e6605124f7077a202f87dd204dc476900bcd3370cbe633->enter($__internal_4a81a5a92ea5519160e6605124f7077a202f87dd204dc476900bcd3370cbe633_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('body_text', $context, $blocks);
        // line 13
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_f3fe81306a5a666b764b2c76b2c48588736cd331adadffc693e7790b1cc4a84a->leave($__internal_f3fe81306a5a666b764b2c76b2c48588736cd331adadffc693e7790b1cc4a84a_prof);

        
        $__internal_4a81a5a92ea5519160e6605124f7077a202f87dd204dc476900bcd3370cbe633->leave($__internal_4a81a5a92ea5519160e6605124f7077a202f87dd204dc476900bcd3370cbe633_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_6c390fa70ebdb06f7eca89fd4f8d7e57cf10f55b80f608b4f884212143cc9451 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6c390fa70ebdb06f7eca89fd4f8d7e57cf10f55b80f608b4f884212143cc9451->enter($__internal_6c390fa70ebdb06f7eca89fd4f8d7e57cf10f55b80f608b4f884212143cc9451_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        $__internal_74f5f5f65e02c2ba18b6a8520f767963272f71e066164b5e938a4db4fdced6ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_74f5f5f65e02c2ba18b6a8520f767963272f71e066164b5e938a4db4fdced6ef->enter($__internal_74f5f5f65e02c2ba18b6a8520f767963272f71e066164b5e938a4db4fdced6ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.subject", array("%username%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array())), "FOSUserBundle");
        
        $__internal_74f5f5f65e02c2ba18b6a8520f767963272f71e066164b5e938a4db4fdced6ef->leave($__internal_74f5f5f65e02c2ba18b6a8520f767963272f71e066164b5e938a4db4fdced6ef_prof);

        
        $__internal_6c390fa70ebdb06f7eca89fd4f8d7e57cf10f55b80f608b4f884212143cc9451->leave($__internal_6c390fa70ebdb06f7eca89fd4f8d7e57cf10f55b80f608b4f884212143cc9451_prof);

    }

    // line 8
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_4b339743f5ee31386fbcded4d6385a85e1f16e4be49518b205c48c18c56a6ae7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4b339743f5ee31386fbcded4d6385a85e1f16e4be49518b205c48c18c56a6ae7->enter($__internal_4b339743f5ee31386fbcded4d6385a85e1f16e4be49518b205c48c18c56a6ae7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        $__internal_6c759e1cb5dfd19b7cf6e323f40564ec164b35f46fb7480c0a9e46ad81b0dbcc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c759e1cb5dfd19b7cf6e323f40564ec164b35f46fb7480c0a9e46ad81b0dbcc->enter($__internal_6c759e1cb5dfd19b7cf6e323f40564ec164b35f46fb7480c0a9e46ad81b0dbcc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.message", array("%username%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => ($context["confirmationUrl"] ?? $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_6c759e1cb5dfd19b7cf6e323f40564ec164b35f46fb7480c0a9e46ad81b0dbcc->leave($__internal_6c759e1cb5dfd19b7cf6e323f40564ec164b35f46fb7480c0a9e46ad81b0dbcc_prof);

        
        $__internal_4b339743f5ee31386fbcded4d6385a85e1f16e4be49518b205c48c18c56a6ae7->leave($__internal_4b339743f5ee31386fbcded4d6385a85e1f16e4be49518b205c48c18c56a6ae7_prof);

    }

    // line 13
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_ed3d78f050e5d20ce2d7c9b32e27bf2100c85beb4351cb75e3170d4f47e3dcc8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ed3d78f050e5d20ce2d7c9b32e27bf2100c85beb4351cb75e3170d4f47e3dcc8->enter($__internal_ed3d78f050e5d20ce2d7c9b32e27bf2100c85beb4351cb75e3170d4f47e3dcc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        $__internal_6d23ba1b69fe80b0ffb4c9b41482cbe2b90c6f879720606cce83c9cf09a50aad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d23ba1b69fe80b0ffb4c9b41482cbe2b90c6f879720606cce83c9cf09a50aad->enter($__internal_6d23ba1b69fe80b0ffb4c9b41482cbe2b90c6f879720606cce83c9cf09a50aad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_6d23ba1b69fe80b0ffb4c9b41482cbe2b90c6f879720606cce83c9cf09a50aad->leave($__internal_6d23ba1b69fe80b0ffb4c9b41482cbe2b90c6f879720606cce83c9cf09a50aad_prof);

        
        $__internal_ed3d78f050e5d20ce2d7c9b32e27bf2100c85beb4351cb75e3170d4f47e3dcc8->leave($__internal_ed3d78f050e5d20ce2d7c9b32e27bf2100c85beb4351cb75e3170d4f47e3dcc8_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  85 => 13,  73 => 10,  64 => 8,  54 => 4,  45 => 2,  35 => 13,  33 => 8,  30 => 7,  28 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}
{% block subject %}
{%- autoescape false -%}
{{ 'resetting.email.subject'|trans({'%username%': user.username}) }}
{%- endautoescape -%}
{% endblock %}

{% block body_text %}
{% autoescape false %}
{{ 'resetting.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endautoescape %}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Resetting:email.txt.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Resetting/email.txt.twig");
    }
}
