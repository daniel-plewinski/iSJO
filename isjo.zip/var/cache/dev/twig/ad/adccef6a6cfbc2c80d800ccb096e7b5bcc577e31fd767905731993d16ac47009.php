<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_6d29e2ee1ee58b4663edcc85350b32d70322c55a118cacae01ead4236d8e0e84 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3d2e01f026d97edf620b9ababc986eba98cd8020ef018e190244dd2309503b8f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3d2e01f026d97edf620b9ababc986eba98cd8020ef018e190244dd2309503b8f->enter($__internal_3d2e01f026d97edf620b9ababc986eba98cd8020ef018e190244dd2309503b8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        $__internal_8b8c6049583f840233e18088bfc410d955afde8224c8400fbe4c125aa79f8bc2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8b8c6049583f840233e18088bfc410d955afde8224c8400fbe4c125aa79f8bc2->enter($__internal_8b8c6049583f840233e18088bfc410d955afde8224c8400fbe4c125aa79f8bc2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo ($context["status_code"] ?? $this->getContext($context, "status_code"));
        echo " ";
        echo ($context["status_text"] ?? $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_3d2e01f026d97edf620b9ababc986eba98cd8020ef018e190244dd2309503b8f->leave($__internal_3d2e01f026d97edf620b9ababc986eba98cd8020ef018e190244dd2309503b8f_prof);

        
        $__internal_8b8c6049583f840233e18088bfc410d955afde8224c8400fbe4c125aa79f8bc2->leave($__internal_8b8c6049583f840233e18088bfc410d955afde8224c8400fbe4c125aa79f8bc2_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "TwigBundle:Exception:error.txt.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.txt.twig");
    }
}
