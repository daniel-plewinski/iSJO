<?php

/* @FOSUser/layout-profile.html.twig */
class __TwigTemplate_9be7eeda8ab3e92ff3302dfa028657690311a58627cbda3512f3ecf659050110 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1fa70e6a172ebcb2e7e9f7893dfe98ef408041921d4c98f3a544b6dbf97be3e9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1fa70e6a172ebcb2e7e9f7893dfe98ef408041921d4c98f3a544b6dbf97be3e9->enter($__internal_1fa70e6a172ebcb2e7e9f7893dfe98ef408041921d4c98f3a544b6dbf97be3e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/layout-profile.html.twig"));

        $__internal_24d964ea61d2b83e8f318bdb87f8f182e2dcf4d28f4936b7f09c7a5731519e2f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_24d964ea61d2b83e8f318bdb87f8f182e2dcf4d28f4936b7f09c7a5731519e2f->enter($__internal_24d964ea61d2b83e8f318bdb87f8f182e2dcf4d28f4936b7f09c7a5731519e2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/layout-profile.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"pl\">

<head>

    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>Blog Home - Start Bootstrap Template</title>

    <!-- Bootstrap Core CSS -->
    <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/sb-admin.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo "\"/>

    <!-- Custom CSS -->
    <link rel=\"stylesheet\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/blog-home.css"), "html", null, true);
        echo "\"/>

</head>

<body>

<div id=\"wrapper\">


    <!-- Navigation -->
    <nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-ex1-collapse\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"/\">iSJO</a>
        </div>
        <!-- Top Menu Items -->
        <ul class=\"nav navbar-right top-nav\">
            <li class=\"dropdown\">
                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\"><i
                            class=\"fa fa-user\"></i> ";
        // line 46
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "name", array()), "html", null, true);
        echo " <b
                            class=\"caret\"></b></a>
                <ul class=\"dropdown-menu\">
                    <li>
                        <a href=\"/profile\"><i class=\"fa fa-fw fa-user\"></i> Profil</a>
                    </li>
                    <li class=\"divider\"></li>
                    <li>
                        <a href=\"/logout\"><i class=\"fa fa-fw fa-power-off\"></i> Wyloguj się</a>
                    </li>
                </ul>
            </li>
        </ul>
        <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
        <div class=\"collapse navbar-collapse navbar-ex1-collapse\">
            <ul class=\"nav navbar-nav side-nav\">
                <li>
                    <a href=\"";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index_school");
        echo "\"><i class=\"fa fa-fw fa-dashboard\"></i> Podsumowanie</a>
                </li>
                <li>
                    <a href=\"";
        // line 66
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("show_teachers");
        echo "\"><i class=\"fa fa-fw fa-user-circle\"></i> Nauczyciele</a>
                </li>
                <li>
                    <a href=\"";
        // line 69
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("show_courses");
        echo "\"><i class=\"fa fa-fw fa-table\"></i> Kursy</a>
                </li>
                <li>
                    <a href=\"#\"><i class=\"fa fa-fw fa-edit\"></i> Rozliczenia</a>
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </nav>

    <div id=\"page-wrapper\">

        <div class=\"container-fluid min-height\">

            ";
        // line 82
        $this->displayBlock('body', $context, $blocks);
        // line 111
        echo "
    </div>
    <div>
</body>
</html>

</div>

</div>
<!-- Footer -->
<footer>
    <div class=\"row\">
        <div class=\"col-lg-12\">
            <p class=\"text-center\">&copy; iSJO by Daniel Plewinski</p>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
</footer>

</div>

<!-- /#page-wrapper -->


";
        // line 142
        echo "
";
        // line 159
        echo "

<script src=\"";
        // line 161
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 162
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 163
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/extra.js"), "html", null, true);
        echo "\"></script>


<script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>
<script src=\"https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js\"></script>

</body>
</html>


";
        
        $__internal_1fa70e6a172ebcb2e7e9f7893dfe98ef408041921d4c98f3a544b6dbf97be3e9->leave($__internal_1fa70e6a172ebcb2e7e9f7893dfe98ef408041921d4c98f3a544b6dbf97be3e9_prof);

        
        $__internal_24d964ea61d2b83e8f318bdb87f8f182e2dcf4d28f4936b7f09c7a5731519e2f->leave($__internal_24d964ea61d2b83e8f318bdb87f8f182e2dcf4d28f4936b7f09c7a5731519e2f_prof);

    }

    // line 82
    public function block_body($context, array $blocks = array())
    {
        $__internal_b44ae70079d55049d738d8aa8b5c267abd752408745819572f778c6dd48d3899 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b44ae70079d55049d738d8aa8b5c267abd752408745819572f778c6dd48d3899->enter($__internal_b44ae70079d55049d738d8aa8b5c267abd752408745819572f778c6dd48d3899_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_cee14c787da427c06a1b811f20bc00e9d25120b6531596816c639a72fee59ba7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cee14c787da427c06a1b811f20bc00e9d25120b6531596816c639a72fee59ba7->enter($__internal_cee14c787da427c06a1b811f20bc00e9d25120b6531596816c639a72fee59ba7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 83
        echo "

            ";
        // line 85
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 86
            echo "                ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.logged_in_as", array("%username%" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "username", array())), "FOSUserBundle"), "html", null, true);
            echo " |
                <a href=\"";
            // line 87
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\">
                    ";
            // line 88
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.logout", array(), "FOSUserBundle"), "html", null, true);
            echo "
                </a>
                ";
            // line 91
            echo "                ";
            // line 92
            echo "            ";
        }
        // line 93
        echo "        </div>

        ";
        // line 95
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "hasPreviousSession", array())) {
            // line 96
            echo "            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "session", array()), "flashbag", array()), "all", array(), "method"));
            foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
                // line 97
                echo "                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($context["messages"]);
                foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                    // line 98
                    echo "                    <div class=\"flash-";
                    echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                    echo "\">
                        ";
                    // line 99
                    echo twig_escape_filter($this->env, $context["message"], "html", null, true);
                    echo "
                    </div>
                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 102
                echo "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 103
            echo "        ";
        }
        // line 104
        echo "
        <div>
            ";
        // line 106
        $this->displayBlock('fos_user_content', $context, $blocks);
        // line 108
        echo "        </div>

        ";
        
        $__internal_cee14c787da427c06a1b811f20bc00e9d25120b6531596816c639a72fee59ba7->leave($__internal_cee14c787da427c06a1b811f20bc00e9d25120b6531596816c639a72fee59ba7_prof);

        
        $__internal_b44ae70079d55049d738d8aa8b5c267abd752408745819572f778c6dd48d3899->leave($__internal_b44ae70079d55049d738d8aa8b5c267abd752408745819572f778c6dd48d3899_prof);

    }

    // line 106
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_b936c07d88b1b8bfa2f5db8adc59a39f7cfa548670c02fca646af7728f9d6359 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b936c07d88b1b8bfa2f5db8adc59a39f7cfa548670c02fca646af7728f9d6359->enter($__internal_b936c07d88b1b8bfa2f5db8adc59a39f7cfa548670c02fca646af7728f9d6359_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_2a9f65cfed4e6bdcf61fcdde8e3edb0a296c0892b0be0ce6956dda3facd4a637 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2a9f65cfed4e6bdcf61fcdde8e3edb0a296c0892b0be0ce6956dda3facd4a637->enter($__internal_2a9f65cfed4e6bdcf61fcdde8e3edb0a296c0892b0be0ce6956dda3facd4a637_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 107
        echo "            ";
        
        $__internal_2a9f65cfed4e6bdcf61fcdde8e3edb0a296c0892b0be0ce6956dda3facd4a637->leave($__internal_2a9f65cfed4e6bdcf61fcdde8e3edb0a296c0892b0be0ce6956dda3facd4a637_prof);

        
        $__internal_b936c07d88b1b8bfa2f5db8adc59a39f7cfa548670c02fca646af7728f9d6359->leave($__internal_b936c07d88b1b8bfa2f5db8adc59a39f7cfa548670c02fca646af7728f9d6359_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/layout-profile.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  302 => 107,  293 => 106,  281 => 108,  279 => 106,  275 => 104,  272 => 103,  266 => 102,  257 => 99,  252 => 98,  247 => 97,  242 => 96,  240 => 95,  236 => 93,  233 => 92,  231 => 91,  226 => 88,  222 => 87,  217 => 86,  215 => 85,  211 => 83,  202 => 82,  181 => 163,  177 => 162,  173 => 161,  169 => 159,  166 => 142,  139 => 111,  137 => 82,  121 => 69,  115 => 66,  109 => 63,  89 => 46,  61 => 21,  55 => 18,  51 => 17,  47 => 16,  43 => 15,  27 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"pl\">

<head>

    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>Blog Home - Start Bootstrap Template</title>

    <!-- Bootstrap Core CSS -->
    <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\"/>
    <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap.min.css') }}\"/>
    <link rel=\"stylesheet\" href=\"{{ asset('css/sb-admin.css') }}\"/>
    <link rel=\"stylesheet\" href=\"{{ asset('font-awesome/css/font-awesome.min.css') }}\"/>

    <!-- Custom CSS -->
    <link rel=\"stylesheet\" href=\"{{ asset('css/blog-home.css') }}\"/>

</head>

<body>

<div id=\"wrapper\">


    <!-- Navigation -->
    <nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-ex1-collapse\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"/\">iSJO</a>
        </div>
        <!-- Top Menu Items -->
        <ul class=\"nav navbar-right top-nav\">
            <li class=\"dropdown\">
                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\"><i
                            class=\"fa fa-user\"></i> {{ app.user.name }} <b
                            class=\"caret\"></b></a>
                <ul class=\"dropdown-menu\">
                    <li>
                        <a href=\"/profile\"><i class=\"fa fa-fw fa-user\"></i> Profil</a>
                    </li>
                    <li class=\"divider\"></li>
                    <li>
                        <a href=\"/logout\"><i class=\"fa fa-fw fa-power-off\"></i> Wyloguj się</a>
                    </li>
                </ul>
            </li>
        </ul>
        <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
        <div class=\"collapse navbar-collapse navbar-ex1-collapse\">
            <ul class=\"nav navbar-nav side-nav\">
                <li>
                    <a href=\"{{ path('index_school') }}\"><i class=\"fa fa-fw fa-dashboard\"></i> Podsumowanie</a>
                </li>
                <li>
                    <a href=\"{{ path('show_teachers') }}\"><i class=\"fa fa-fw fa-user-circle\"></i> Nauczyciele</a>
                </li>
                <li>
                    <a href=\"{{ path('show_courses') }}\"><i class=\"fa fa-fw fa-table\"></i> Kursy</a>
                </li>
                <li>
                    <a href=\"#\"><i class=\"fa fa-fw fa-edit\"></i> Rozliczenia</a>
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </nav>

    <div id=\"page-wrapper\">

        <div class=\"container-fluid min-height\">

            {% block body %}


            {% if is_granted(\"IS_AUTHENTICATED_REMEMBERED\") %}
                {{ 'layout.logged_in_as'|trans({'%username%': app.user.username}, 'FOSUserBundle') }} |
                <a href=\"{{ path('fos_user_security_logout') }}\">
                    {{ 'layout.logout'|trans({}, 'FOSUserBundle') }}
                </a>
                {#{% else %}#}
                {#<a href=\"{{ path('fos_user_security_login') }}\">{{ 'layout.login'|trans({}, 'FOSUserBundle') }}</a>#}
            {% endif %}
        </div>

        {% if app.request.hasPreviousSession %}
            {% for type, messages in app.session.flashbag.all() %}
                {% for message in messages %}
                    <div class=\"flash-{{ type }}\">
                        {{ message }}
                    </div>
                {% endfor %}
            {% endfor %}
        {% endif %}

        <div>
            {% block fos_user_content %}
            {% endblock fos_user_content %}
        </div>

        {% endblock %}

    </div>
    <div>
</body>
</html>

</div>

</div>
<!-- Footer -->
<footer>
    <div class=\"row\">
        <div class=\"col-lg-12\">
            <p class=\"text-center\">&copy; iSJO by Daniel Plewinski</p>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
</footer>

</div>

<!-- /#page-wrapper -->


{#<nav class=\"navbar navbar-expand-md navbar-dark bg-dark fixed-top\">#}
{#<a class=\"navbar-brand\" href=\"/\">iSJO</a>#}
{#<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarsExampleDefault\"#}
{#aria-controls=\"navbarsExampleDefault\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">#}
{#<span class=\"navbar-toggler-icon\"></span>#}
{#</button>#}

{#<div class=\"collapse navbar-collapse\" id=\"navbarsExampleDefault\">#}
{#<ul class=\"navbar-nav mr-auto\">#}
{#<li class=\"nav-item active\">#}
{#<a class=\"nav-link\" href=\"/\">Start <span class=\"sr-only\">(current)</span></a>#}
{#</li>#}
{#{% if is_granted(\"ROLE_SCHOOL\") %}#}
{#<li class=\"nav-item active\"><a class=\"nav-link\" href=\"{{ path('show_teachers') }}\">Nauczyciele</a></li>#}
{#<li class=\"nav-item active\"><a class=\"nav-link\" href=\"#\">Grupy</a></li>#}
{#<li class=\"nav-item active\"><a class=\"nav-link\" href=\"#\">Rozliczenia</a></li>#}
{#<li class=\"nav-item active\"><a class=\"nav-link\" href=\"/logout\">Wyloguj się</a></li>#}
{#{% else %}#}
{#<li class=\"nav-item active\"><a href=\"/register\">Zarejestruj się</a></li>#}
{#{% endif %}#}
{#</ul>#}
{#</div>#}
{#</nav>#}


<script src=\"{{ asset('js/jquery.js') }}\"></script>
<script src=\"{{ asset('js/bootstrap.js') }}\"></script>
<script src=\"{{ asset('js/extra.js') }}\"></script>


<script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>
<script src=\"https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js\"></script>

</body>
</html>


", "@FOSUser/layout-profile.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/layout-profile.html.twig");
    }
}
