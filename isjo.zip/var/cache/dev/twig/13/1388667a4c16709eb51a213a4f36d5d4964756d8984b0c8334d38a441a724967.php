<?php

/* ::index_teacher.html.twig */
class __TwigTemplate_dc92d990e8e7fbbd0a952706b1d6495d42a7fb7baa32fca82de02c9eb02b870f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::index_teacher.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_17683dc180ccb7bb58300e35de6255fe48f477f6536515681bdef96fce497acd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_17683dc180ccb7bb58300e35de6255fe48f477f6536515681bdef96fce497acd->enter($__internal_17683dc180ccb7bb58300e35de6255fe48f477f6536515681bdef96fce497acd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::index_teacher.html.twig"));

        $__internal_a1b5e1722665cd49a2c17f18baf074400f4d94299030b6dd92ed7839a2574918 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a1b5e1722665cd49a2c17f18baf074400f4d94299030b6dd92ed7839a2574918->enter($__internal_a1b5e1722665cd49a2c17f18baf074400f4d94299030b6dd92ed7839a2574918_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::index_teacher.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_17683dc180ccb7bb58300e35de6255fe48f477f6536515681bdef96fce497acd->leave($__internal_17683dc180ccb7bb58300e35de6255fe48f477f6536515681bdef96fce497acd_prof);

        
        $__internal_a1b5e1722665cd49a2c17f18baf074400f4d94299030b6dd92ed7839a2574918->leave($__internal_a1b5e1722665cd49a2c17f18baf074400f4d94299030b6dd92ed7839a2574918_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_73f7ab44edb4f2eddac4f3f2ca1f8391eadf0600bb5027971184f6a254ee1b84 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_73f7ab44edb4f2eddac4f3f2ca1f8391eadf0600bb5027971184f6a254ee1b84->enter($__internal_73f7ab44edb4f2eddac4f3f2ca1f8391eadf0600bb5027971184f6a254ee1b84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_39773fd8b08711cc13c8ad9844b9dfbd202fc1885e24c4fd23d1ec22f767d961 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_39773fd8b08711cc13c8ad9844b9dfbd202fc1885e24c4fd23d1ec22f767d961->enter($__internal_39773fd8b08711cc13c8ad9844b9dfbd202fc1885e24c4fd23d1ec22f767d961_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <!-- Page Heading -->
    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h2>
                Podsumowanie
            </h2>

            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"jumbotron jumbotron-fluid jumbotron-low\">
        <div class=\"container\">
            <h1 class=\"display-4\"> ";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "name", array()), "html", null, true);
        echo "</h1>
            <p class=\"lead\">Witamy</p>
        </div>
    </div>

";
        
        $__internal_39773fd8b08711cc13c8ad9844b9dfbd202fc1885e24c4fd23d1ec22f767d961->leave($__internal_39773fd8b08711cc13c8ad9844b9dfbd202fc1885e24c4fd23d1ec22f767d961_prof);

        
        $__internal_73f7ab44edb4f2eddac4f3f2ca1f8391eadf0600bb5027971184f6a254ee1b84->leave($__internal_73f7ab44edb4f2eddac4f3f2ca1f8391eadf0600bb5027971184f6a254ee1b84_prof);

    }

    public function getTemplateName()
    {
        return "::index_teacher.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 23,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

    <!-- Page Heading -->
    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h2>
                Podsumowanie
            </h2>

            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
            </ol>
        </div>
    </div>

    <div class=\"jumbotron jumbotron-fluid jumbotron-low\">
        <div class=\"container\">
            <h1 class=\"display-4\"> {{ app.user.name }}</h1>
            <p class=\"lead\">Witamy</p>
        </div>
    </div>

{% endblock %}", "::index_teacher.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/index_teacher.html.twig");
    }
}
