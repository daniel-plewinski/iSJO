<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_7495ac0952d7836574e650a6d2ab367a650e2cad1f59a624e01c73160690bd2e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8348daed7b8dac49bcb39a090daa55d249fd9184470eb2c7e9e677c35439f15 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8348daed7b8dac49bcb39a090daa55d249fd9184470eb2c7e9e677c35439f15->enter($__internal_b8348daed7b8dac49bcb39a090daa55d249fd9184470eb2c7e9e677c35439f15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_b38aae2dc4403ced8a023c83da99febf07721d611a835120d3a0884247e051db = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b38aae2dc4403ced8a023c83da99febf07721d611a835120d3a0884247e051db->enter($__internal_b38aae2dc4403ced8a023c83da99febf07721d611a835120d3a0884247e051db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b8348daed7b8dac49bcb39a090daa55d249fd9184470eb2c7e9e677c35439f15->leave($__internal_b8348daed7b8dac49bcb39a090daa55d249fd9184470eb2c7e9e677c35439f15_prof);

        
        $__internal_b38aae2dc4403ced8a023c83da99febf07721d611a835120d3a0884247e051db->leave($__internal_b38aae2dc4403ced8a023c83da99febf07721d611a835120d3a0884247e051db_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_78cfeb22a619aab2c2877b4806654a24f95826d2372940a65556b2c2b9105bb9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78cfeb22a619aab2c2877b4806654a24f95826d2372940a65556b2c2b9105bb9->enter($__internal_78cfeb22a619aab2c2877b4806654a24f95826d2372940a65556b2c2b9105bb9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_5820260c06eeed7ccd0b0ae2755eb9ffc7ff42ca49a4e3ec65f8bd4e52736d15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5820260c06eeed7ccd0b0ae2755eb9ffc7ff42ca49a4e3ec65f8bd4e52736d15->enter($__internal_5820260c06eeed7ccd0b0ae2755eb9ffc7ff42ca49a4e3ec65f8bd4e52736d15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_5820260c06eeed7ccd0b0ae2755eb9ffc7ff42ca49a4e3ec65f8bd4e52736d15->leave($__internal_5820260c06eeed7ccd0b0ae2755eb9ffc7ff42ca49a4e3ec65f8bd4e52736d15_prof);

        
        $__internal_78cfeb22a619aab2c2877b4806654a24f95826d2372940a65556b2c2b9105bb9->leave($__internal_78cfeb22a619aab2c2877b4806654a24f95826d2372940a65556b2c2b9105bb9_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_c91649ee3e3a059ae54ce09c6212d2b65b4a0c35f3956fb284031bed02186b33 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c91649ee3e3a059ae54ce09c6212d2b65b4a0c35f3956fb284031bed02186b33->enter($__internal_c91649ee3e3a059ae54ce09c6212d2b65b4a0c35f3956fb284031bed02186b33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_1359136530a573ce14b19914d4b95bf1b4e40d519fe092c32f60506c5997db8a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1359136530a573ce14b19914d4b95bf1b4e40d519fe092c32f60506c5997db8a->enter($__internal_1359136530a573ce14b19914d4b95bf1b4e40d519fe092c32f60506c5997db8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_1359136530a573ce14b19914d4b95bf1b4e40d519fe092c32f60506c5997db8a->leave($__internal_1359136530a573ce14b19914d4b95bf1b4e40d519fe092c32f60506c5997db8a_prof);

        
        $__internal_c91649ee3e3a059ae54ce09c6212d2b65b4a0c35f3956fb284031bed02186b33->leave($__internal_c91649ee3e3a059ae54ce09c6212d2b65b4a0c35f3956fb284031bed02186b33_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
