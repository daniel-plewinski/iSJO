<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_5ec7e0feede03551b64fd990456a5723f083ccf5d8ea16c66c13174123e92fd2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_458c9caa0160c6a64fa8f8f9d780b0b730587a93fdf49bdb4cd0dcae34ed8818 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_458c9caa0160c6a64fa8f8f9d780b0b730587a93fdf49bdb4cd0dcae34ed8818->enter($__internal_458c9caa0160c6a64fa8f8f9d780b0b730587a93fdf49bdb4cd0dcae34ed8818_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        $__internal_eb2eceb2208cdd216dd79a626e3b9816957bc8d2cd4bbc669b48983508148141 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb2eceb2208cdd216dd79a626e3b9816957bc8d2cd4bbc669b48983508148141->enter($__internal_eb2eceb2208cdd216dd79a626e3b9816957bc8d2cd4bbc669b48983508148141_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_458c9caa0160c6a64fa8f8f9d780b0b730587a93fdf49bdb4cd0dcae34ed8818->leave($__internal_458c9caa0160c6a64fa8f8f9d780b0b730587a93fdf49bdb4cd0dcae34ed8818_prof);

        
        $__internal_eb2eceb2208cdd216dd79a626e3b9816957bc8d2cd4bbc669b48983508148141->leave($__internal_eb2eceb2208cdd216dd79a626e3b9816957bc8d2cd4bbc669b48983508148141_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/submit_widget.html.php");
    }
}
