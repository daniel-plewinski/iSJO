<?php

/* WebProfilerBundle:Collector:exception.css.twig */
class __TwigTemplate_63ec63fc5272d026aa70db4832bfe937ee02677215ad8e942239bba0cd191f7a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb32deeb60567c0299a0b03cd9d0a12cc090e27f4b03b772a26163aa804653d9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb32deeb60567c0299a0b03cd9d0a12cc090e27f4b03b772a26163aa804653d9->enter($__internal_fb32deeb60567c0299a0b03cd9d0a12cc090e27f4b03b772a26163aa804653d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.css.twig"));

        $__internal_503c844b4ddd7f1e2722ef6d64a8c94f43704e51b8f85a6b3c26a21451511e2a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_503c844b4ddd7f1e2722ef6d64a8c94f43704e51b8f85a6b3c26a21451511e2a->enter($__internal_503c844b4ddd7f1e2722ef6d64a8c94f43704e51b8f85a6b3c26a21451511e2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:exception.css.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}
.exception-summary.exception-without-message {
    display: none;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper .container {
    min-height: auto;
}
";
        
        $__internal_fb32deeb60567c0299a0b03cd9d0a12cc090e27f4b03b772a26163aa804653d9->leave($__internal_fb32deeb60567c0299a0b03cd9d0a12cc090e27f4b03b772a26163aa804653d9_prof);

        
        $__internal_503c844b4ddd7f1e2722ef6d64a8c94f43704e51b8f85a6b3c26a21451511e2a->leave($__internal_503c844b4ddd7f1e2722ef6d64a8c94f43704e51b8f85a6b3c26a21451511e2a_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/exception.css.twig') }}

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}
.exception-summary.exception-without-message {
    display: none;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper .container {
    min-height: auto;
}
", "WebProfilerBundle:Collector:exception.css.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.css.twig");
    }
}
