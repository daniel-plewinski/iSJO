<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_355be641eb9d9111018b82ced4e931fa1d37b15bd7a0f52ca3de3ab002683f8a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0726f4bb380bda2c7378db7c54dcdc7da2b8d4bd9094be2fe2e4bfaafa791b76 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0726f4bb380bda2c7378db7c54dcdc7da2b8d4bd9094be2fe2e4bfaafa791b76->enter($__internal_0726f4bb380bda2c7378db7c54dcdc7da2b8d4bd9094be2fe2e4bfaafa791b76_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_f09c58b5fae6a4e06c2c96e738c81a7abd700c9032645572659c3bdf8bbbde23 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f09c58b5fae6a4e06c2c96e738c81a7abd700c9032645572659c3bdf8bbbde23->enter($__internal_f09c58b5fae6a4e06c2c96e738c81a7abd700c9032645572659c3bdf8bbbde23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_0726f4bb380bda2c7378db7c54dcdc7da2b8d4bd9094be2fe2e4bfaafa791b76->leave($__internal_0726f4bb380bda2c7378db7c54dcdc7da2b8d4bd9094be2fe2e4bfaafa791b76_prof);

        
        $__internal_f09c58b5fae6a4e06c2c96e738c81a7abd700c9032645572659c3bdf8bbbde23->leave($__internal_f09c58b5fae6a4e06c2c96e738c81a7abd700c9032645572659c3bdf8bbbde23_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/password_widget.html.php");
    }
}
