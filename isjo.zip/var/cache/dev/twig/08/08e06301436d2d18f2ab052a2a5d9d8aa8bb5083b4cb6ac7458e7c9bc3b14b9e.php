<?php

/* @Framework/Form/choice_attributes.html.php */
class __TwigTemplate_c40d4fbd35cbd4f6a962472530c51cca9dad4f0ada6d7edfdbefea0917352616 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_18c2d323f57dd8c16a55c753f65375c454ed75d9c6bccd09fd54ec617ba7c29b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_18c2d323f57dd8c16a55c753f65375c454ed75d9c6bccd09fd54ec617ba7c29b->enter($__internal_18c2d323f57dd8c16a55c753f65375c454ed75d9c6bccd09fd54ec617ba7c29b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        $__internal_623224bff2227b87eec745dedc1f107118e58e242a39414ed013ee30793c4801 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_623224bff2227b87eec745dedc1f107118e58e242a39414ed013ee30793c4801->enter($__internal_623224bff2227b87eec745dedc1f107118e58e242a39414ed013ee30793c4801_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        // line 1
        echo "<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_18c2d323f57dd8c16a55c753f65375c454ed75d9c6bccd09fd54ec617ba7c29b->leave($__internal_18c2d323f57dd8c16a55c753f65375c454ed75d9c6bccd09fd54ec617ba7c29b_prof);

        
        $__internal_623224bff2227b87eec745dedc1f107118e58e242a39414ed013ee30793c4801->leave($__internal_623224bff2227b87eec745dedc1f107118e58e242a39414ed013ee30793c4801_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/choice_attributes.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_attributes.html.php");
    }
}
