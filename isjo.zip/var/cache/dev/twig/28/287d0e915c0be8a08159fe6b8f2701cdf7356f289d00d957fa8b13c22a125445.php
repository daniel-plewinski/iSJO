<?php

/* ::show_courses.html.twig */
class __TwigTemplate_3e4b396d6208bbb53ad17b3e7ec361222f918fef27aeccb8dbaeae39bd018081 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::show_courses.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eae7c716d56b481999ca4e640f955130894509e36b329d311f4bf21fb790122e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eae7c716d56b481999ca4e640f955130894509e36b329d311f4bf21fb790122e->enter($__internal_eae7c716d56b481999ca4e640f955130894509e36b329d311f4bf21fb790122e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::show_courses.html.twig"));

        $__internal_cd17845d066fc29cc7fb4e392784790ebb547328e68aa2603a7d5d585bdc2f43 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd17845d066fc29cc7fb4e392784790ebb547328e68aa2603a7d5d585bdc2f43->enter($__internal_cd17845d066fc29cc7fb4e392784790ebb547328e68aa2603a7d5d585bdc2f43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::show_courses.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_eae7c716d56b481999ca4e640f955130894509e36b329d311f4bf21fb790122e->leave($__internal_eae7c716d56b481999ca4e640f955130894509e36b329d311f4bf21fb790122e_prof);

        
        $__internal_cd17845d066fc29cc7fb4e392784790ebb547328e68aa2603a7d5d585bdc2f43->leave($__internal_cd17845d066fc29cc7fb4e392784790ebb547328e68aa2603a7d5d585bdc2f43_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_6f8630093076bdcf15e5ec2cf19c0b2a179d53ee06ef54d8554bcf6079ad6ae5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6f8630093076bdcf15e5ec2cf19c0b2a179d53ee06ef54d8554bcf6079ad6ae5->enter($__internal_6f8630093076bdcf15e5ec2cf19c0b2a179d53ee06ef54d8554bcf6079ad6ae5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7c4f641709bcc0b32376c17dccfb73f47401d2c0aadd8dd9c0e06d96dea036cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c4f641709bcc0b32376c17dccfb73f47401d2c0aadd8dd9c0e06d96dea036cb->enter($__internal_7c4f641709bcc0b32376c17dccfb73f47401d2c0aadd8dd9c0e06d96dea036cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <div class=\"container-fluid\">

        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Lista kursów
                </h2>
            </div>
            <div class=\"col-md-2\">

                <h2><a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_course");
        echo "\">
                        <button type=\"button\" class=\"btn btn-info\">Dodaj kurs</button>
                    </a></h2>

            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Lista kursów
                </li>
            </ol>
        </div>
    </div>

    <div class=\"row\">
        <div class=\"col-lg-12\">
            <table class=\"table\">
                <thead class=\"thead\">
                <tr>
                    <th>L.p.</th>
                    <th>Nazwa kursu</th>
                    <th>Kod</th>
                    <th>Lekcji</th>
                    <th class=\"hidden-xs hidden-sm\">Przedmiot</th>
                    <th>Nauczyciel</th>

                    <th></th>
                    <th class=\"hidden-xs hidden-sm\"></th>
                </tr>
                </thead>
                <tbody>

                ";
        // line 54
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["pagination"] ?? $this->getContext($context, "pagination")));
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 55
            echo "                    <tr>
                        <td>";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["pagination"] ?? $this->getContext($context, "pagination")), "getPaginationData", array()), "firstItemNumber", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "courseName", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "id", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 59
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "totalLessons", array()), "html", null, true);
            echo "</td>
                        <td class=\"hidden-xs hidden-sm\">";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($context["element"], "subject", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 61
            echo twig_escape_filter($this->env, $this->getAttribute(($context["teacherAr"] ?? $this->getContext($context, "teacherAr")), $this->getAttribute($context["element"], "teacherId", array())), "html", null, true);
            echo "</td>
                        <td><a href=\" ";
            // line 62
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("shows_school_lessons", array("id" => $this->getAttribute($context["element"], "id", array()))), "html", null, true);
            echo "\">
                                <button type=\"button\" class=\"btn btn-info\">Lekcje</button>
                            </a></td>
                        <td class=\"hidden-xs hidden-sm\"><a href=\" ";
            // line 65
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("edit_course", array("id" => $this->getAttribute($context["element"], "id", array()))), "html", null, true);
            echo "\">
                                <button type=\"button\" class=\"btn btn-warning\">Edycja</button>
                            </a></td>

                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 71
        echo "                </tbody>
            </table>
            ";
        // line 74
        echo "            <div class=\"navigation\">
                <div class=\"text-center\">
                    ";
        // line 76
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, ($context["pagination"] ?? $this->getContext($context, "pagination")));
        echo "
                </div>
            </div>
        </div>
    </div>
    </div>


";
        
        $__internal_7c4f641709bcc0b32376c17dccfb73f47401d2c0aadd8dd9c0e06d96dea036cb->leave($__internal_7c4f641709bcc0b32376c17dccfb73f47401d2c0aadd8dd9c0e06d96dea036cb_prof);

        
        $__internal_6f8630093076bdcf15e5ec2cf19c0b2a179d53ee06ef54d8554bcf6079ad6ae5->leave($__internal_6f8630093076bdcf15e5ec2cf19c0b2a179d53ee06ef54d8554bcf6079ad6ae5_prof);

    }

    public function getTemplateName()
    {
        return "::show_courses.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  160 => 76,  156 => 74,  152 => 71,  140 => 65,  134 => 62,  130 => 61,  126 => 60,  122 => 59,  118 => 58,  114 => 57,  110 => 56,  107 => 55,  103 => 54,  63 => 17,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

    <div class=\"container-fluid\">

        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Lista kursów
                </h2>
            </div>
            <div class=\"col-md-2\">

                <h2><a href=\"{{ path('add_course') }}\">
                        <button type=\"button\" class=\"btn btn-info\">Dodaj kurs</button>
                    </a></h2>

            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Lista kursów
                </li>
            </ol>
        </div>
    </div>

    <div class=\"row\">
        <div class=\"col-lg-12\">
            <table class=\"table\">
                <thead class=\"thead\">
                <tr>
                    <th>L.p.</th>
                    <th>Nazwa kursu</th>
                    <th>Kod</th>
                    <th>Lekcji</th>
                    <th class=\"hidden-xs hidden-sm\">Przedmiot</th>
                    <th>Nauczyciel</th>

                    <th></th>
                    <th class=\"hidden-xs hidden-sm\"></th>
                </tr>
                </thead>
                <tbody>

                {% for element in pagination %}
                    <tr>
                        <td>{{  pagination.getPaginationData.firstItemNumber }}</td>
                        <td>{{ element.courseName }}</td>
                        <td>{{ element.id }}</td>
                        <td>{{ element.totalLessons }}</td>
                        <td class=\"hidden-xs hidden-sm\">{{ element.subject }}</td>
                        <td>{{ attribute(teacherAr, element.teacherId) }}</td>
                        <td><a href=\" {{ path('shows_school_lessons', {'id':  element.id }) }}\">
                                <button type=\"button\" class=\"btn btn-info\">Lekcje</button>
                            </a></td>
                        <td class=\"hidden-xs hidden-sm\"><a href=\" {{ path('edit_course', {'id':  element.id }) }}\">
                                <button type=\"button\" class=\"btn btn-warning\">Edycja</button>
                            </a></td>

                    </tr>
                {% endfor %}
                </tbody>
            </table>
            {# display navigation #}
            <div class=\"navigation\">
                <div class=\"text-center\">
                    {{ knp_pagination_render(pagination) }}
                </div>
            </div>
        </div>
    </div>
    </div>


{% endblock %}", "::show_courses.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/show_courses.html.twig");
    }
}
