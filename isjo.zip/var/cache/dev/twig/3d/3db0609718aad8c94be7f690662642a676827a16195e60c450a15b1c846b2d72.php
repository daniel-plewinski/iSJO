<?php

/* WebProfilerBundle:Profiler:info.html.twig */
class __TwigTemplate_4fe815ad05d020562ba505bceb268cc2baa44bef648d8f5d88b834d2b6c61447 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Profiler:info.html.twig", 1);
        $this->blocks = array(
            'summary' => array($this, 'block_summary'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_16165a2eeebf39d9dc56c429d7eddd2535e6988c83347899fae8f26239011d9b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16165a2eeebf39d9dc56c429d7eddd2535e6988c83347899fae8f26239011d9b->enter($__internal_16165a2eeebf39d9dc56c429d7eddd2535e6988c83347899fae8f26239011d9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:info.html.twig"));

        $__internal_94db5e46b05b6f639d8cd61f52e65c4ebdd8eb76786950e1e898df0af239916f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_94db5e46b05b6f639d8cd61f52e65c4ebdd8eb76786950e1e898df0af239916f->enter($__internal_94db5e46b05b6f639d8cd61f52e65c4ebdd8eb76786950e1e898df0af239916f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:info.html.twig"));

        // line 3
        $context["messages"] = array("no_token" => array("status" => "error", "title" => (((((        // line 6
array_key_exists("token", $context)) ? (_twig_default_filter(($context["token"] ?? $this->getContext($context, "token")), "")) : ("")) == "latest")) ? ("There are no profiles") : ("Token not found")), "message" => (((((        // line 7
array_key_exists("token", $context)) ? (_twig_default_filter(($context["token"] ?? $this->getContext($context, "token")), "")) : ("")) == "latest")) ? ("No profiles found in the database.") : ((("Token \"" . ((array_key_exists("token", $context)) ? (_twig_default_filter(($context["token"] ?? $this->getContext($context, "token")), "")) : (""))) . "\" was not found in the database.")))));
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_16165a2eeebf39d9dc56c429d7eddd2535e6988c83347899fae8f26239011d9b->leave($__internal_16165a2eeebf39d9dc56c429d7eddd2535e6988c83347899fae8f26239011d9b_prof);

        
        $__internal_94db5e46b05b6f639d8cd61f52e65c4ebdd8eb76786950e1e898df0af239916f->leave($__internal_94db5e46b05b6f639d8cd61f52e65c4ebdd8eb76786950e1e898df0af239916f_prof);

    }

    // line 11
    public function block_summary($context, array $blocks = array())
    {
        $__internal_84d5552e80845e474d60190b94cc0fefa9dc5a763c985a5a593f691daef711b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_84d5552e80845e474d60190b94cc0fefa9dc5a763c985a5a593f691daef711b4->enter($__internal_84d5552e80845e474d60190b94cc0fefa9dc5a763c985a5a593f691daef711b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "summary"));

        $__internal_86c732452417ecafc153f06f489157e34ea730a1b5a55e3f3855ac980529cb6d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_86c732452417ecafc153f06f489157e34ea730a1b5a55e3f3855ac980529cb6d->enter($__internal_86c732452417ecafc153f06f489157e34ea730a1b5a55e3f3855ac980529cb6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "summary"));

        // line 12
        echo "    <div class=\"status status-";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["messages"] ?? $this->getContext($context, "messages")), ($context["about"] ?? $this->getContext($context, "about")), array(), "array"), "status", array()), "html", null, true);
        echo "\">
        <div class=\"container\">
            <h2>";
        // line 14
        echo twig_escape_filter($this->env, twig_title_string_filter($this->env, $this->getAttribute($this->getAttribute(($context["messages"] ?? $this->getContext($context, "messages")), ($context["about"] ?? $this->getContext($context, "about")), array(), "array"), "status", array())), "html", null, true);
        echo "</h2>
        </div>
    </div>
";
        
        $__internal_86c732452417ecafc153f06f489157e34ea730a1b5a55e3f3855ac980529cb6d->leave($__internal_86c732452417ecafc153f06f489157e34ea730a1b5a55e3f3855ac980529cb6d_prof);

        
        $__internal_84d5552e80845e474d60190b94cc0fefa9dc5a763c985a5a593f691daef711b4->leave($__internal_84d5552e80845e474d60190b94cc0fefa9dc5a763c985a5a593f691daef711b4_prof);

    }

    // line 19
    public function block_panel($context, array $blocks = array())
    {
        $__internal_c18c51566076b937315416795ee8591a394df99138cdbf6a8b8ffb99cb96abd7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c18c51566076b937315416795ee8591a394df99138cdbf6a8b8ffb99cb96abd7->enter($__internal_c18c51566076b937315416795ee8591a394df99138cdbf6a8b8ffb99cb96abd7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_1f58f776d70b5d0b90e11e07f3262d27d58a2523f51d6fe49c2233b9b9a08a1f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1f58f776d70b5d0b90e11e07f3262d27d58a2523f51d6fe49c2233b9b9a08a1f->enter($__internal_1f58f776d70b5d0b90e11e07f3262d27d58a2523f51d6fe49c2233b9b9a08a1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 20
        echo "    <h2>";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["messages"] ?? $this->getContext($context, "messages")), ($context["about"] ?? $this->getContext($context, "about")), array(), "array"), "title", array()), "html", null, true);
        echo "</h2>
    <p>";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["messages"] ?? $this->getContext($context, "messages")), ($context["about"] ?? $this->getContext($context, "about")), array(), "array"), "message", array()), "html", null, true);
        echo "</p>
";
        
        $__internal_1f58f776d70b5d0b90e11e07f3262d27d58a2523f51d6fe49c2233b9b9a08a1f->leave($__internal_1f58f776d70b5d0b90e11e07f3262d27d58a2523f51d6fe49c2233b9b9a08a1f_prof);

        
        $__internal_c18c51566076b937315416795ee8591a394df99138cdbf6a8b8ffb99cb96abd7->leave($__internal_c18c51566076b937315416795ee8591a394df99138cdbf6a8b8ffb99cb96abd7_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:info.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 21,  84 => 20,  75 => 19,  61 => 14,  55 => 12,  46 => 11,  36 => 1,  34 => 7,  33 => 6,  32 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% set messages = {
    'no_token' : {
        status:  'error',
        title:   (token|default('') == 'latest') ? 'There are no profiles' : 'Token not found',
        message: (token|default('') == 'latest') ? 'No profiles found in the database.' : 'Token \"' ~ token|default('') ~ '\" was not found in the database.'
    }
} %}

{% block summary %}
    <div class=\"status status-{{ messages[about].status }}\">
        <div class=\"container\">
            <h2>{{ messages[about].status|title }}</h2>
        </div>
    </div>
{% endblock %}

{% block panel %}
    <h2>{{ messages[about].title }}</h2>
    <p>{{ messages[about].message }}</p>
{% endblock %}
", "WebProfilerBundle:Profiler:info.html.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/info.html.twig");
    }
}
