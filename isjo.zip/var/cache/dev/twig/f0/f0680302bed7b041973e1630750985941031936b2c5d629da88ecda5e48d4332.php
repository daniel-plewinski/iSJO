<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_0d2c7135649bbda953f4b47a89b85496373782e36b3e85e0ce006b0a032734b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_587bd691ca9bc01fb3d6bb3bfb8551c16c0bfa712684bd007e57b55c12c3f351 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_587bd691ca9bc01fb3d6bb3bfb8551c16c0bfa712684bd007e57b55c12c3f351->enter($__internal_587bd691ca9bc01fb3d6bb3bfb8551c16c0bfa712684bd007e57b55c12c3f351_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_ca8306a59d9da60708ad6ebc738173f3ceabcdb3735ff6c0ae7eb128045b18e8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca8306a59d9da60708ad6ebc738173f3ceabcdb3735ff6c0ae7eb128045b18e8->enter($__internal_ca8306a59d9da60708ad6ebc738173f3ceabcdb3735ff6c0ae7eb128045b18e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_587bd691ca9bc01fb3d6bb3bfb8551c16c0bfa712684bd007e57b55c12c3f351->leave($__internal_587bd691ca9bc01fb3d6bb3bfb8551c16c0bfa712684bd007e57b55c12c3f351_prof);

        
        $__internal_ca8306a59d9da60708ad6ebc738173f3ceabcdb3735ff6c0ae7eb128045b18e8->leave($__internal_ca8306a59d9da60708ad6ebc738173f3ceabcdb3735ff6c0ae7eb128045b18e8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/radio_widget.html.php");
    }
}
