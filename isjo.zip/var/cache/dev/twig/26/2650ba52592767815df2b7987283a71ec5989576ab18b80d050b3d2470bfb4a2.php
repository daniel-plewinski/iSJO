<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_5ca8151fe0461d915e279cce6e693e4c19bd781c5ad670c4b465936102ff8e44 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fbca75491f387c635612b2ebe5d5c2c7e76e2968bca92d770abc891fd80583d6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fbca75491f387c635612b2ebe5d5c2c7e76e2968bca92d770abc891fd80583d6->enter($__internal_fbca75491f387c635612b2ebe5d5c2c7e76e2968bca92d770abc891fd80583d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_cdcc2fe261ee97696ab40f0368e670bace419a8add07ff820ceffffa8168c620 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cdcc2fe261ee97696ab40f0368e670bace419a8add07ff820ceffffa8168c620->enter($__internal_cdcc2fe261ee97696ab40f0368e670bace419a8add07ff820ceffffa8168c620_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form); ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form); ?>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_fbca75491f387c635612b2ebe5d5c2c7e76e2968bca92d770abc891fd80583d6->leave($__internal_fbca75491f387c635612b2ebe5d5c2c7e76e2968bca92d770abc891fd80583d6_prof);

        
        $__internal_cdcc2fe261ee97696ab40f0368e670bace419a8add07ff820ceffffa8168c620->leave($__internal_cdcc2fe261ee97696ab40f0368e670bace419a8add07ff820ceffffa8168c620_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form); ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form); ?>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/form_row.html.php");
    }
}
