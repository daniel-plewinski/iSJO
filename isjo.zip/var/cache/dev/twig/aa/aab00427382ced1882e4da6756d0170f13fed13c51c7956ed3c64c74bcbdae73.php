<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_0b40686859b4f03314d72270d26bf7225cb82ed48d45e7712a59e856ec815e7d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f573aa0d5da4605e62926ee3a2877107bcfa3013e33a53dedce42fa410746c07 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f573aa0d5da4605e62926ee3a2877107bcfa3013e33a53dedce42fa410746c07->enter($__internal_f573aa0d5da4605e62926ee3a2877107bcfa3013e33a53dedce42fa410746c07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $__internal_c6b9fc0d2d7a957485bdcab854a450d9fbbb64d23972af88c9cbbc035c2557f3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c6b9fc0d2d7a957485bdcab854a450d9fbbb64d23972af88c9cbbc035c2557f3->enter($__internal_c6b9fc0d2d7a957485bdcab854a450d9fbbb64d23972af88c9cbbc035c2557f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f573aa0d5da4605e62926ee3a2877107bcfa3013e33a53dedce42fa410746c07->leave($__internal_f573aa0d5da4605e62926ee3a2877107bcfa3013e33a53dedce42fa410746c07_prof);

        
        $__internal_c6b9fc0d2d7a957485bdcab854a450d9fbbb64d23972af88c9cbbc035c2557f3->leave($__internal_c6b9fc0d2d7a957485bdcab854a450d9fbbb64d23972af88c9cbbc035c2557f3_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_8a06ae8227bdfbcec832084bfadcd90f7e77527affacc65627067c483b803339 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8a06ae8227bdfbcec832084bfadcd90f7e77527affacc65627067c483b803339->enter($__internal_8a06ae8227bdfbcec832084bfadcd90f7e77527affacc65627067c483b803339_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_a8e33f81d2ec9de101a706082167343fcc71cb70e0beefc5e754df2544a2a432 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8e33f81d2ec9de101a706082167343fcc71cb70e0beefc5e754df2544a2a432->enter($__internal_a8e33f81d2ec9de101a706082167343fcc71cb70e0beefc5e754df2544a2a432_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Registration/register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_a8e33f81d2ec9de101a706082167343fcc71cb70e0beefc5e754df2544a2a432->leave($__internal_a8e33f81d2ec9de101a706082167343fcc71cb70e0beefc5e754df2544a2a432_prof);

        
        $__internal_8a06ae8227bdfbcec832084bfadcd90f7e77527affacc65627067c483b803339->leave($__internal_8a06ae8227bdfbcec832084bfadcd90f7e77527affacc65627067c483b803339_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Registration/register_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:register.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Registration/register.html.twig");
    }
}
