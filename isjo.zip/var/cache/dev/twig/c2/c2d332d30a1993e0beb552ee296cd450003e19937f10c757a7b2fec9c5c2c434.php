<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_47c4ed15573bfcdb563eb728ba444a10fb9f0f820f97639c1f9000b23d7c323d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fd977f6bd107b6a3b859ae46d662a4d83141783a7898dbc89760c2f8db1fd16f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fd977f6bd107b6a3b859ae46d662a4d83141783a7898dbc89760c2f8db1fd16f->enter($__internal_fd977f6bd107b6a3b859ae46d662a4d83141783a7898dbc89760c2f8db1fd16f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_5e9a3283c8ebe831745d0c9e6f17326b9277661e02a13af5e2dc5c07d93c4c3e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e9a3283c8ebe831745d0c9e6f17326b9277661e02a13af5e2dc5c07d93c4c3e->enter($__internal_5e9a3283c8ebe831745d0c9e6f17326b9277661e02a13af5e2dc5c07d93c4c3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_fd977f6bd107b6a3b859ae46d662a4d83141783a7898dbc89760c2f8db1fd16f->leave($__internal_fd977f6bd107b6a3b859ae46d662a4d83141783a7898dbc89760c2f8db1fd16f_prof);

        
        $__internal_5e9a3283c8ebe831745d0c9e6f17326b9277661e02a13af5e2dc5c07d93c4c3e->leave($__internal_5e9a3283c8ebe831745d0c9e6f17326b9277661e02a13af5e2dc5c07d93c4c3e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_end.html.php");
    }
}
