<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_8b3f88abeb1255de9f92fb98d127c44fd301288e51089adb313528df9df2eb4d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fc9ac88684b5ecfe344971c966141784e846db67f2a0a6f5efad7094c29be2e3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fc9ac88684b5ecfe344971c966141784e846db67f2a0a6f5efad7094c29be2e3->enter($__internal_fc9ac88684b5ecfe344971c966141784e846db67f2a0a6f5efad7094c29be2e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_457c87d4a0f0dcb76f30bc419b006d69cb3cb0845be0a524ae8caf720e13f2a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_457c87d4a0f0dcb76f30bc419b006d69cb3cb0845be0a524ae8caf720e13f2a4->enter($__internal_457c87d4a0f0dcb76f30bc419b006d69cb3cb0845be0a524ae8caf720e13f2a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_fc9ac88684b5ecfe344971c966141784e846db67f2a0a6f5efad7094c29be2e3->leave($__internal_fc9ac88684b5ecfe344971c966141784e846db67f2a0a6f5efad7094c29be2e3_prof);

        
        $__internal_457c87d4a0f0dcb76f30bc419b006d69cb3cb0845be0a524ae8caf720e13f2a4->leave($__internal_457c87d4a0f0dcb76f30bc419b006d69cb3cb0845be0a524ae8caf720e13f2a4_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
