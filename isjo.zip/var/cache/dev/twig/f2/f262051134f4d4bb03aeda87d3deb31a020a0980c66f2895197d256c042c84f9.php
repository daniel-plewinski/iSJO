<?php

/* ::choose_settlement_date.html.twig */
class __TwigTemplate_05341a49881aec26077cfe6ec3d80ff98ede2e793d452cf44ef79840fcebf7c2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::choose_settlement_date.html.twig", 1);
        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9853e604daa12e22926273d1b606e785de2949a4d6d38e992ec3a5683631d331 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9853e604daa12e22926273d1b606e785de2949a4d6d38e992ec3a5683631d331->enter($__internal_9853e604daa12e22926273d1b606e785de2949a4d6d38e992ec3a5683631d331_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::choose_settlement_date.html.twig"));

        $__internal_3afb79043ac53382fe68a60be8c567d0802969795714a999df7268c8615bd990 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3afb79043ac53382fe68a60be8c567d0802969795714a999df7268c8615bd990->enter($__internal_3afb79043ac53382fe68a60be8c567d0802969795714a999df7268c8615bd990_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::choose_settlement_date.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9853e604daa12e22926273d1b606e785de2949a4d6d38e992ec3a5683631d331->leave($__internal_9853e604daa12e22926273d1b606e785de2949a4d6d38e992ec3a5683631d331_prof);

        
        $__internal_3afb79043ac53382fe68a60be8c567d0802969795714a999df7268c8615bd990->leave($__internal_3afb79043ac53382fe68a60be8c567d0802969795714a999df7268c8615bd990_prof);

    }

    // line 3
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_74e195cd042cdc20da7a0672d2bb3726cc8b9c2678ce44240d13b79218417c7b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_74e195cd042cdc20da7a0672d2bb3726cc8b9c2678ce44240d13b79218417c7b->enter($__internal_74e195cd042cdc20da7a0672d2bb3726cc8b9c2678ce44240d13b79218417c7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_0fecf23458ad05d351c5f00713df4d6b8b624c1ae70725b024d86c0e2c34d744 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0fecf23458ad05d351c5f00713df4d6b8b624c1ae70725b024d86c0e2c34d744->enter($__internal_0fecf23458ad05d351c5f00713df4d6b8b624c1ae70725b024d86c0e2c34d744_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 4
        echo "
    ";
        // line 5
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

";
        
        $__internal_0fecf23458ad05d351c5f00713df4d6b8b624c1ae70725b024d86c0e2c34d744->leave($__internal_0fecf23458ad05d351c5f00713df4d6b8b624c1ae70725b024d86c0e2c34d744_prof);

        
        $__internal_74e195cd042cdc20da7a0672d2bb3726cc8b9c2678ce44240d13b79218417c7b->leave($__internal_74e195cd042cdc20da7a0672d2bb3726cc8b9c2678ce44240d13b79218417c7b_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_64eb2a2cc258b0a28536b9ae513c044f5d08e946b87812c8f05138dfc2415999 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_64eb2a2cc258b0a28536b9ae513c044f5d08e946b87812c8f05138dfc2415999->enter($__internal_64eb2a2cc258b0a28536b9ae513c044f5d08e946b87812c8f05138dfc2415999_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d57020e3370eaa4be53860db7db93a0166a7bac7cd82756de3d8a020953e4aa5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d57020e3370eaa4be53860db7db93a0166a7bac7cd82756de3d8a020953e4aa5->enter($__internal_d57020e3370eaa4be53860db7db93a0166a7bac7cd82756de3d8a020953e4aa5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "

    <div class=\"container-fluid\">

        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Wybierz okres rozliczenia
                </h2>
            </div>
            <div class=\"col-md-2\">

                <h2><a href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_course");
        echo "\">
                        <button type=\"button\" class=\"btn btn-info\">Dodaj kurs</button>
                    </a></h2>

            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Lista kursów
                </li>
            </ol>
        </div>


        ";
        // line 42
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
        <table class=\"centered-table\">
            <tr>
                <th class=\"td-right-padding\">";
        // line 45
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "year", array()), 'label');
        echo "</th>
                <th>";
        // line 46
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "month", array()), 'label');
        echo "</th>
            </tr>
            <tr>
                <td class=\"td-right-padding\">";
        // line 49
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "year", array()), 'widget', array("value" => twig_date_format_filter($this->env, "now", "Y")));
        echo "</td>
                <td>";
        // line 50
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "month", array()), 'widget', array("value" => twig_date_format_filter($this->env, "now", "m")));
        echo "</td>
            </tr>
            <tr>
                <td colspan=\"2\" class=\"text-center\">";
        // line 53
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "submit", array()), 'widget');
        echo "</td>
            </tr>
        </table>



        ";
        // line 59
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

    </div>

";
        
        $__internal_d57020e3370eaa4be53860db7db93a0166a7bac7cd82756de3d8a020953e4aa5->leave($__internal_d57020e3370eaa4be53860db7db93a0166a7bac7cd82756de3d8a020953e4aa5_prof);

        
        $__internal_64eb2a2cc258b0a28536b9ae513c044f5d08e946b87812c8f05138dfc2415999->leave($__internal_64eb2a2cc258b0a28536b9ae513c044f5d08e946b87812c8f05138dfc2415999_prof);

    }

    public function getTemplateName()
    {
        return "::choose_settlement_date.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 59,  138 => 53,  132 => 50,  128 => 49,  122 => 46,  118 => 45,  112 => 42,  90 => 23,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block javascripts %}

    {{ parent() }}

{% endblock %}

{% block body %}


    <div class=\"container-fluid\">

        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Wybierz okres rozliczenia
                </h2>
            </div>
            <div class=\"col-md-2\">

                <h2><a href=\"{{ path('add_course') }}\">
                        <button type=\"button\" class=\"btn btn-info\">Dodaj kurs</button>
                    </a></h2>

            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Lista kursów
                </li>
            </ol>
        </div>


        {{ form_start(form) }}
        <table class=\"centered-table\">
            <tr>
                <th class=\"td-right-padding\">{{ form_label(form.year) }}</th>
                <th>{{ form_label(form.month) }}</th>
            </tr>
            <tr>
                <td class=\"td-right-padding\">{{ form_widget(form.year, { 'value': \"now\"|date(\"Y\")} ) }}</td>
                <td>{{ form_widget(form.month, { 'value': \"now\"|date(\"m\")} ) }}</td>
            </tr>
            <tr>
                <td colspan=\"2\" class=\"text-center\">{{ form_widget(form.submit) }}</td>
            </tr>
        </table>



        {{ form_end(form) }}

    </div>

{% endblock %}", "::choose_settlement_date.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/choose_settlement_date.html.twig");
    }
}
