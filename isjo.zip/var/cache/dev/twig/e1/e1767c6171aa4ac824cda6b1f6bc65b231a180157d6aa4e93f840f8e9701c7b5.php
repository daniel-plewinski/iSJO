<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_ff0ee2bbf2b5aa754f4f0db4b63b575d174992dfe8354901e994207666779428 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5c3b5ed9b36ff2e711417939222279eebead4f9b443c24dc54751eb9ef4487ed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c3b5ed9b36ff2e711417939222279eebead4f9b443c24dc54751eb9ef4487ed->enter($__internal_5c3b5ed9b36ff2e711417939222279eebead4f9b443c24dc54751eb9ef4487ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_189397ae73f89f8bcfae90a4dd18eb2bbe1e6cb6098f0802d91582f56a6e4a3f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_189397ae73f89f8bcfae90a4dd18eb2bbe1e6cb6098f0802d91582f56a6e4a3f->enter($__internal_189397ae73f89f8bcfae90a4dd18eb2bbe1e6cb6098f0802d91582f56a6e4a3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_5c3b5ed9b36ff2e711417939222279eebead4f9b443c24dc54751eb9ef4487ed->leave($__internal_5c3b5ed9b36ff2e711417939222279eebead4f9b443c24dc54751eb9ef4487ed_prof);

        
        $__internal_189397ae73f89f8bcfae90a4dd18eb2bbe1e6cb6098f0802d91582f56a6e4a3f->leave($__internal_189397ae73f89f8bcfae90a4dd18eb2bbe1e6cb6098f0802d91582f56a6e4a3f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}
