<?php

/* FOSUserBundle:Group:new.html.twig */
class __TwigTemplate_f2090b38c5ee76d52c8b2e4e45ff7354bf3af706b944b1c221228800da3b00eb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_36d4c5a75dca9d31536ecadfca0f03b860f963006bfbd6d7dc4e8c6cfb7ccef7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_36d4c5a75dca9d31536ecadfca0f03b860f963006bfbd6d7dc4e8c6cfb7ccef7->enter($__internal_36d4c5a75dca9d31536ecadfca0f03b860f963006bfbd6d7dc4e8c6cfb7ccef7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $__internal_52574e118091a3b14731bfbb9710b5ef72cc8cbf3838a30ba7abad9675231460 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_52574e118091a3b14731bfbb9710b5ef72cc8cbf3838a30ba7abad9675231460->enter($__internal_52574e118091a3b14731bfbb9710b5ef72cc8cbf3838a30ba7abad9675231460_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_36d4c5a75dca9d31536ecadfca0f03b860f963006bfbd6d7dc4e8c6cfb7ccef7->leave($__internal_36d4c5a75dca9d31536ecadfca0f03b860f963006bfbd6d7dc4e8c6cfb7ccef7_prof);

        
        $__internal_52574e118091a3b14731bfbb9710b5ef72cc8cbf3838a30ba7abad9675231460->leave($__internal_52574e118091a3b14731bfbb9710b5ef72cc8cbf3838a30ba7abad9675231460_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_a6a3756a0fe2f1b8e807ffdbb79512baf6a48105b6b7219516b6220c145459fc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a6a3756a0fe2f1b8e807ffdbb79512baf6a48105b6b7219516b6220c145459fc->enter($__internal_a6a3756a0fe2f1b8e807ffdbb79512baf6a48105b6b7219516b6220c145459fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_125b94c728f831b2a60ef7ceb8b69068f06ce5777d7c4ee5a32271204de7d200 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_125b94c728f831b2a60ef7ceb8b69068f06ce5777d7c4ee5a32271204de7d200->enter($__internal_125b94c728f831b2a60ef7ceb8b69068f06ce5777d7c4ee5a32271204de7d200_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/new_content.html.twig", "FOSUserBundle:Group:new.html.twig", 4)->display($context);
        
        $__internal_125b94c728f831b2a60ef7ceb8b69068f06ce5777d7c4ee5a32271204de7d200->leave($__internal_125b94c728f831b2a60ef7ceb8b69068f06ce5777d7c4ee5a32271204de7d200_prof);

        
        $__internal_a6a3756a0fe2f1b8e807ffdbb79512baf6a48105b6b7219516b6220c145459fc->leave($__internal_a6a3756a0fe2f1b8e807ffdbb79512baf6a48105b6b7219516b6220c145459fc_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/new_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:new.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Group/new.html.twig");
    }
}
