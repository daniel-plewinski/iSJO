<?php

/* FOSUserBundle:Security:login.html.twig */
class __TwigTemplate_5feb7e9f736bc33ce598442dfebaa5a1c945b7db22d9ba810709ad8106474b34 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Security:login.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_caf62bf751526a97433e1eb218c65f6b0954b3ebc488cffabe0c4a961e0091a1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_caf62bf751526a97433e1eb218c65f6b0954b3ebc488cffabe0c4a961e0091a1->enter($__internal_caf62bf751526a97433e1eb218c65f6b0954b3ebc488cffabe0c4a961e0091a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Security:login.html.twig"));

        $__internal_76d2b166ae5464246fc70f1a0d6117c3673292f52c4789816e1ed2eb7886664a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_76d2b166ae5464246fc70f1a0d6117c3673292f52c4789816e1ed2eb7886664a->enter($__internal_76d2b166ae5464246fc70f1a0d6117c3673292f52c4789816e1ed2eb7886664a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Security:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_caf62bf751526a97433e1eb218c65f6b0954b3ebc488cffabe0c4a961e0091a1->leave($__internal_caf62bf751526a97433e1eb218c65f6b0954b3ebc488cffabe0c4a961e0091a1_prof);

        
        $__internal_76d2b166ae5464246fc70f1a0d6117c3673292f52c4789816e1ed2eb7886664a->leave($__internal_76d2b166ae5464246fc70f1a0d6117c3673292f52c4789816e1ed2eb7886664a_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_4e55bb1d35c9d920bce5fdec70b3d88da9f78988b7103914a44a5f180709b7cc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4e55bb1d35c9d920bce5fdec70b3d88da9f78988b7103914a44a5f180709b7cc->enter($__internal_4e55bb1d35c9d920bce5fdec70b3d88da9f78988b7103914a44a5f180709b7cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_0709144e27c258b4aa92c472c3e995d918b4e8a1cedc81a78a6b1e82a31d6ad0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0709144e27c258b4aa92c472c3e995d918b4e8a1cedc81a78a6b1e82a31d6ad0->enter($__internal_0709144e27c258b4aa92c472c3e995d918b4e8a1cedc81a78a6b1e82a31d6ad0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        echo "    ";
        echo twig_include($this->env, $context, "@FOSUser/Security/login_content.html.twig");
        echo "
";
        
        $__internal_0709144e27c258b4aa92c472c3e995d918b4e8a1cedc81a78a6b1e82a31d6ad0->leave($__internal_0709144e27c258b4aa92c472c3e995d918b4e8a1cedc81a78a6b1e82a31d6ad0_prof);

        
        $__internal_4e55bb1d35c9d920bce5fdec70b3d88da9f78988b7103914a44a5f180709b7cc->leave($__internal_4e55bb1d35c9d920bce5fdec70b3d88da9f78988b7103914a44a5f180709b7cc_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Security:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
    {{ include('@FOSUser/Security/login_content.html.twig') }}
{% endblock fos_user_content %}
", "FOSUserBundle:Security:login.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Security/login.html.twig");
    }
}
