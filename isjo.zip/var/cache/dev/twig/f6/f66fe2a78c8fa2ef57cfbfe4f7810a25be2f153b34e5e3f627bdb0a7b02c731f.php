<?php

/* ::teacher_added.html.twig */
class __TwigTemplate_5b0181c1f6fa088022dfabe1d790fa5f6e8cf07fca41e6a5cce308fb0bbd01f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::teacher_added.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4b31b09cb2cecd01555d449062b036401a5f9303a1f30a30e0ff5871045dc130 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4b31b09cb2cecd01555d449062b036401a5f9303a1f30a30e0ff5871045dc130->enter($__internal_4b31b09cb2cecd01555d449062b036401a5f9303a1f30a30e0ff5871045dc130_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::teacher_added.html.twig"));

        $__internal_d2140eba8840d6320e6d1e8d9364eb52c798c98f9009578c107f59422dbc0d21 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d2140eba8840d6320e6d1e8d9364eb52c798c98f9009578c107f59422dbc0d21->enter($__internal_d2140eba8840d6320e6d1e8d9364eb52c798c98f9009578c107f59422dbc0d21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::teacher_added.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4b31b09cb2cecd01555d449062b036401a5f9303a1f30a30e0ff5871045dc130->leave($__internal_4b31b09cb2cecd01555d449062b036401a5f9303a1f30a30e0ff5871045dc130_prof);

        
        $__internal_d2140eba8840d6320e6d1e8d9364eb52c798c98f9009578c107f59422dbc0d21->leave($__internal_d2140eba8840d6320e6d1e8d9364eb52c798c98f9009578c107f59422dbc0d21_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_1ffd2d08d555d292a367c7baa44d223d45591f169c76556839be018d13541e30 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1ffd2d08d555d292a367c7baa44d223d45591f169c76556839be018d13541e30->enter($__internal_1ffd2d08d555d292a367c7baa44d223d45591f169c76556839be018d13541e30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c18f421d827d8785d96650d07c034d433a4cfd92ad26b6461d99bfb12a652c24 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c18f421d827d8785d96650d07c034d433a4cfd92ad26b6461d99bfb12a652c24->enter($__internal_c18f421d827d8785d96650d07c034d433a4cfd92ad26b6461d99bfb12a652c24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <h2>Dodano nauczyciela</h2>

    <p>Ta strona wyświetla się tylko 1 raz po dodaniu nauczyciela. Zapisz wygenerowane losowo hasło tymczasowe i
    przekaż je nauczycielowi. Powinien on zmienić je na własne.</p>

    <p>Imię i nazwisko: ";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["newTeacher"] ?? $this->getContext($context, "newTeacher")), "getName", array(), "method"), "html", null, true);
        echo "</p>
    <p>Login: ";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute(($context["newTeacher"] ?? $this->getContext($context, "newTeacher")), "getUserName", array(), "method"), "html", null, true);
        echo "</p>
    <p>Hasło: ";
        // line 13
        echo twig_escape_filter($this->env, ($context["password"] ?? $this->getContext($context, "password")), "html", null, true);
        echo "</p>

    <a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("show_teachers");
        echo "\"><button type=\"button\" class=\"btn btn-primary\">Powrót do listy nauczycieli</button></a>

";
        
        $__internal_c18f421d827d8785d96650d07c034d433a4cfd92ad26b6461d99bfb12a652c24->leave($__internal_c18f421d827d8785d96650d07c034d433a4cfd92ad26b6461d99bfb12a652c24_prof);

        
        $__internal_1ffd2d08d555d292a367c7baa44d223d45591f169c76556839be018d13541e30->leave($__internal_1ffd2d08d555d292a367c7baa44d223d45591f169c76556839be018d13541e30_prof);

    }

    public function getTemplateName()
    {
        return "::teacher_added.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 15,  65 => 13,  61 => 12,  57 => 11,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

    <h2>Dodano nauczyciela</h2>

    <p>Ta strona wyświetla się tylko 1 raz po dodaniu nauczyciela. Zapisz wygenerowane losowo hasło tymczasowe i
    przekaż je nauczycielowi. Powinien on zmienić je na własne.</p>

    <p>Imię i nazwisko: {{ newTeacher.getName() }}</p>
    <p>Login: {{ newTeacher.getUserName() }}</p>
    <p>Hasło: {{ password }}</p>

    <a href=\"{{  path('show_teachers') }}\"><button type=\"button\" class=\"btn btn-primary\">Powrót do listy nauczycieli</button></a>

{% endblock %}", "::teacher_added.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/teacher_added.html.twig");
    }
}
