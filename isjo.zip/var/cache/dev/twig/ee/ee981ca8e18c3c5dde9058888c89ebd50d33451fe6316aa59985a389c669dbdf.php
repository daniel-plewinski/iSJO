<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_5d32fb2dab823e8fef75c53a79713868591e3b34de3ff7d1ce07a4afd272d6db extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ef6ee61d8939832831f32de8eec4838cff424b7f2d837f5984703ee1cc22693d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ef6ee61d8939832831f32de8eec4838cff424b7f2d837f5984703ee1cc22693d->enter($__internal_ef6ee61d8939832831f32de8eec4838cff424b7f2d837f5984703ee1cc22693d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_be9fe7c2c790ab260394a27d60baec090552b21c738f5e9486fa9320b5d61e4a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be9fe7c2c790ab260394a27d60baec090552b21c738f5e9486fa9320b5d61e4a->enter($__internal_be9fe7c2c790ab260394a27d60baec090552b21c738f5e9486fa9320b5d61e4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_ef6ee61d8939832831f32de8eec4838cff424b7f2d837f5984703ee1cc22693d->leave($__internal_ef6ee61d8939832831f32de8eec4838cff424b7f2d837f5984703ee1cc22693d_prof);

        
        $__internal_be9fe7c2c790ab260394a27d60baec090552b21c738f5e9486fa9320b5d61e4a->leave($__internal_be9fe7c2c790ab260394a27d60baec090552b21c738f5e9486fa9320b5d61e4a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form.html.php");
    }
}
