<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_739b86ab0d54ef89615e06888fda55a906ff96d994522e0e2cef6500b6dc1d63 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout-profile.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout-profile.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eb4b6751b8add1e10c8a87855c3f89e58778a2341301bf4b1d82843ba0edb158 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eb4b6751b8add1e10c8a87855c3f89e58778a2341301bf4b1d82843ba0edb158->enter($__internal_eb4b6751b8add1e10c8a87855c3f89e58778a2341301bf4b1d82843ba0edb158_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $__internal_93914783dc2174a26e774e9a88e472c500617798e92e69d5129a30e0f729a8ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93914783dc2174a26e774e9a88e472c500617798e92e69d5129a30e0f729a8ef->enter($__internal_93914783dc2174a26e774e9a88e472c500617798e92e69d5129a30e0f729a8ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_eb4b6751b8add1e10c8a87855c3f89e58778a2341301bf4b1d82843ba0edb158->leave($__internal_eb4b6751b8add1e10c8a87855c3f89e58778a2341301bf4b1d82843ba0edb158_prof);

        
        $__internal_93914783dc2174a26e774e9a88e472c500617798e92e69d5129a30e0f729a8ef->leave($__internal_93914783dc2174a26e774e9a88e472c500617798e92e69d5129a30e0f729a8ef_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_ca9839a4142934916e9bc3991bc79de30f6ef2da6b96200c0d0df44782df9340 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ca9839a4142934916e9bc3991bc79de30f6ef2da6b96200c0d0df44782df9340->enter($__internal_ca9839a4142934916e9bc3991bc79de30f6ef2da6b96200c0d0df44782df9340_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_753832f78d12d176ef610b920d849faf05b18c50d0e2ccf85c9cf6c4a3513505 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_753832f78d12d176ef610b920d849faf05b18c50d0e2ccf85c9cf6c4a3513505->enter($__internal_753832f78d12d176ef610b920d849faf05b18c50d0e2ccf85c9cf6c4a3513505_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        $this->displayBlock('fos_user_content', $context, $blocks);
        
        $__internal_753832f78d12d176ef610b920d849faf05b18c50d0e2ccf85c9cf6c4a3513505->leave($__internal_753832f78d12d176ef610b920d849faf05b18c50d0e2ccf85c9cf6c4a3513505_prof);

        
        $__internal_ca9839a4142934916e9bc3991bc79de30f6ef2da6b96200c0d0df44782df9340->leave($__internal_ca9839a4142934916e9bc3991bc79de30f6ef2da6b96200c0d0df44782df9340_prof);

    }

    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_c9f35c47fd8963e4d5a60d2cd9bb3f2f1a6aace7010834706ffd9d2f40697de8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c9f35c47fd8963e4d5a60d2cd9bb3f2f1a6aace7010834706ffd9d2f40697de8->enter($__internal_c9f35c47fd8963e4d5a60d2cd9bb3f2f1a6aace7010834706ffd9d2f40697de8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_f467eb75f41c87847377cb217871e2f371d60cb326672664a3338707fac7efd5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f467eb75f41c87847377cb217871e2f371d60cb326672664a3338707fac7efd5->enter($__internal_f467eb75f41c87847377cb217871e2f371d60cb326672664a3338707fac7efd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 5
        $this->loadTemplate("@FOSUser/Profile/show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 5)->display($context);
        
        $__internal_f467eb75f41c87847377cb217871e2f371d60cb326672664a3338707fac7efd5->leave($__internal_f467eb75f41c87847377cb217871e2f371d60cb326672664a3338707fac7efd5_prof);

        
        $__internal_c9f35c47fd8963e4d5a60d2cd9bb3f2f1a6aace7010834706ffd9d2f40697de8->leave($__internal_c9f35c47fd8963e4d5a60d2cd9bb3f2f1a6aace7010834706ffd9d2f40697de8_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout-profile.html.twig\" %}

{% block body %}
{% block fos_user_content %}
{% include \"@FOSUser/Profile/show_content.html.twig\" %}
{% endblock fos_user_content %}
{% endblock %}
", "FOSUserBundle:Profile:show.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Profile/show.html.twig");
    }
}
