<?php

/* FOSUserBundle:Resetting:reset.html.twig */
class __TwigTemplate_de0cbc7b62af238940b9f9c0c4acf5d516e6d20c56d76bfbf5ca662eb225ea8a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cc21a6b17212589937ee1b6ce6ce5fbba50a647254c1812feb07720c7ab43b14 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cc21a6b17212589937ee1b6ce6ce5fbba50a647254c1812feb07720c7ab43b14->enter($__internal_cc21a6b17212589937ee1b6ce6ce5fbba50a647254c1812feb07720c7ab43b14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $__internal_73f8620679dc0f6a2c2bbe6ce406d3cdb218f5d3f6cdc0fd6f39c4aae0930d45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73f8620679dc0f6a2c2bbe6ce406d3cdb218f5d3f6cdc0fd6f39c4aae0930d45->enter($__internal_73f8620679dc0f6a2c2bbe6ce406d3cdb218f5d3f6cdc0fd6f39c4aae0930d45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cc21a6b17212589937ee1b6ce6ce5fbba50a647254c1812feb07720c7ab43b14->leave($__internal_cc21a6b17212589937ee1b6ce6ce5fbba50a647254c1812feb07720c7ab43b14_prof);

        
        $__internal_73f8620679dc0f6a2c2bbe6ce406d3cdb218f5d3f6cdc0fd6f39c4aae0930d45->leave($__internal_73f8620679dc0f6a2c2bbe6ce406d3cdb218f5d3f6cdc0fd6f39c4aae0930d45_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_03f1e31f39d95e62c13037a2caf41fc7d9a7799a46659719948fa5d563b13117 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_03f1e31f39d95e62c13037a2caf41fc7d9a7799a46659719948fa5d563b13117->enter($__internal_03f1e31f39d95e62c13037a2caf41fc7d9a7799a46659719948fa5d563b13117_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_89fe3d4475ccf274edf039a038b74069e1e744989849accff1efec42ed199724 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89fe3d4475ccf274edf039a038b74069e1e744989849accff1efec42ed199724->enter($__internal_89fe3d4475ccf274edf039a038b74069e1e744989849accff1efec42ed199724_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Resetting/reset_content.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 4)->display($context);
        
        $__internal_89fe3d4475ccf274edf039a038b74069e1e744989849accff1efec42ed199724->leave($__internal_89fe3d4475ccf274edf039a038b74069e1e744989849accff1efec42ed199724_prof);

        
        $__internal_03f1e31f39d95e62c13037a2caf41fc7d9a7799a46659719948fa5d563b13117->leave($__internal_03f1e31f39d95e62c13037a2caf41fc7d9a7799a46659719948fa5d563b13117_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Resetting/reset_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Resetting:reset.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Resetting/reset.html.twig");
    }
}
