<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_8df71d8647c684f802fc0e4583f8674959da8417fa0d4af33fe578c25536db50 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_281910a6f2bd08ddecf57c6de28f967bb192b4dfe202916468cf2bb5d5abc475 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_281910a6f2bd08ddecf57c6de28f967bb192b4dfe202916468cf2bb5d5abc475->enter($__internal_281910a6f2bd08ddecf57c6de28f967bb192b4dfe202916468cf2bb5d5abc475_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_d0bde3a3c18adf0df9ad639bc69d95ed60388cfd2790e98aad2422d8360748dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d0bde3a3c18adf0df9ad639bc69d95ed60388cfd2790e98aad2422d8360748dc->enter($__internal_d0bde3a3c18adf0df9ad639bc69d95ed60388cfd2790e98aad2422d8360748dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_281910a6f2bd08ddecf57c6de28f967bb192b4dfe202916468cf2bb5d5abc475->leave($__internal_281910a6f2bd08ddecf57c6de28f967bb192b4dfe202916468cf2bb5d5abc475_prof);

        
        $__internal_d0bde3a3c18adf0df9ad639bc69d95ed60388cfd2790e98aad2422d8360748dc->leave($__internal_d0bde3a3c18adf0df9ad639bc69d95ed60388cfd2790e98aad2422d8360748dc_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "TwigBundle:Exception:error.atom.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
