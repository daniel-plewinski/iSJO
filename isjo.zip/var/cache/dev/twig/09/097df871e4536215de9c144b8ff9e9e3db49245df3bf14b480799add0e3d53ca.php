<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_8530fe075a5c351c1fe5400fa0875fd0c12620f38ea3321a577cbdc7bb95a76f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9e14ad0457cd5df13e39749be4b47d65dc50ede5672038cc75c92f834917d09d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9e14ad0457cd5df13e39749be4b47d65dc50ede5672038cc75c92f834917d09d->enter($__internal_9e14ad0457cd5df13e39749be4b47d65dc50ede5672038cc75c92f834917d09d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        $__internal_f3002c545c6ba04260a4e66010d4a96b78e3f8b3e3d04fca2ac2aad834216fa0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f3002c545c6ba04260a4e66010d4a96b78e3f8b3e3d04fca2ac2aad834216fa0->enter($__internal_f3002c545c6ba04260a4e66010d4a96b78e3f8b3e3d04fca2ac2aad834216fa0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, ($context["widget"] ?? $this->getContext($context, "widget")), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_9e14ad0457cd5df13e39749be4b47d65dc50ede5672038cc75c92f834917d09d->leave($__internal_9e14ad0457cd5df13e39749be4b47d65dc50ede5672038cc75c92f834917d09d_prof);

        
        $__internal_f3002c545c6ba04260a4e66010d4a96b78e3f8b3e3d04fca2ac2aad834216fa0->leave($__internal_f3002c545c6ba04260a4e66010d4a96b78e3f8b3e3d04fca2ac2aad834216fa0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo str_replace('{{ widget }}', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
", "@Framework/Form/money_widget.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/money_widget.html.php");
    }
}
