<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_4ab66ee0e07cc2dc6e422e6d12dd55844b50ded0e73c8ca4b057c46619d2e5b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_18297be051c5b88190c53321ac4fcbff89e5cdf78ef073a57086a01e6fbd4a56 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_18297be051c5b88190c53321ac4fcbff89e5cdf78ef073a57086a01e6fbd4a56->enter($__internal_18297be051c5b88190c53321ac4fcbff89e5cdf78ef073a57086a01e6fbd4a56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        $__internal_6860339f93caa6d5c8883f60c3ce5166d4ec7105b9e65a192be998451cf6d04c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6860339f93caa6d5c8883f60c3ce5166d4ec7105b9e65a192be998451cf6d04c->enter($__internal_6860339f93caa6d5c8883f60c3ce5166d4ec7105b9e65a192be998451cf6d04c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_18297be051c5b88190c53321ac4fcbff89e5cdf78ef073a57086a01e6fbd4a56->leave($__internal_18297be051c5b88190c53321ac4fcbff89e5cdf78ef073a57086a01e6fbd4a56_prof);

        
        $__internal_6860339f93caa6d5c8883f60c3ce5166d4ec7105b9e65a192be998451cf6d04c->leave($__internal_6860339f93caa6d5c8883f60c3ce5166d4ec7105b9e65a192be998451cf6d04c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/search_widget.html.php");
    }
}
