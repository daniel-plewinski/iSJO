<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_6609cdf5778adbb5a7009d55b0fb411324d79066c85b11b089f7a9df02212aef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_713a5b33e2d59744558a92812daa1efc39bff0d326c45f8d313dd5c221976499 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_713a5b33e2d59744558a92812daa1efc39bff0d326c45f8d313dd5c221976499->enter($__internal_713a5b33e2d59744558a92812daa1efc39bff0d326c45f8d313dd5c221976499_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_79afea6c29c7e0d7afa523f93322933af68cdf42c12b77491c154356ea912914 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_79afea6c29c7e0d7afa523f93322933af68cdf42c12b77491c154356ea912914->enter($__internal_79afea6c29c7e0d7afa523f93322933af68cdf42c12b77491c154356ea912914_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_713a5b33e2d59744558a92812daa1efc39bff0d326c45f8d313dd5c221976499->leave($__internal_713a5b33e2d59744558a92812daa1efc39bff0d326c45f8d313dd5c221976499_prof);

        
        $__internal_79afea6c29c7e0d7afa523f93322933af68cdf42c12b77491c154356ea912914->leave($__internal_79afea6c29c7e0d7afa523f93322933af68cdf42c12b77491c154356ea912914_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_row.html.php");
    }
}
