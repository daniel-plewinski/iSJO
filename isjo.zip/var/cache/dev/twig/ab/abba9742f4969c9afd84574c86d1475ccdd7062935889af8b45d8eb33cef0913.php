<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_8420b60f516aba09bdba46d8e24235eeecb01a54cf160cb7445ca78769908c1f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c861a1f28ba506266900aabf5e790b60fe22bc69039b3e2483190432c6ac101c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c861a1f28ba506266900aabf5e790b60fe22bc69039b3e2483190432c6ac101c->enter($__internal_c861a1f28ba506266900aabf5e790b60fe22bc69039b3e2483190432c6ac101c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_37cb6203c3f135978790a81cfef531a73cb2f9e2d3e71fe87f921f60774fdf47 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_37cb6203c3f135978790a81cfef531a73cb2f9e2d3e71fe87f921f60774fdf47->enter($__internal_37cb6203c3f135978790a81cfef531a73cb2f9e2d3e71fe87f921f60774fdf47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_c861a1f28ba506266900aabf5e790b60fe22bc69039b3e2483190432c6ac101c->leave($__internal_c861a1f28ba506266900aabf5e790b60fe22bc69039b3e2483190432c6ac101c_prof);

        
        $__internal_37cb6203c3f135978790a81cfef531a73cb2f9e2d3e71fe87f921f60774fdf47->leave($__internal_37cb6203c3f135978790a81cfef531a73cb2f9e2d3e71fe87f921f60774fdf47_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_rest.html.php");
    }
}
