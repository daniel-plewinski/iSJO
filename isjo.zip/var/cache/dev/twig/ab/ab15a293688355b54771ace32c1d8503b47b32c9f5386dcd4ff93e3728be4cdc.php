<?php

/* form_table_layout.html.twig */
class __TwigTemplate_d48f40c1f89c77e1153ad27da1074a38b61b2d475ca6976efaab642687a180d0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("form_div_layout.html.twig", "form_table_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."form_div_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'form_row' => array($this, 'block_form_row'),
                'button_row' => array($this, 'block_button_row'),
                'hidden_row' => array($this, 'block_hidden_row'),
                'form_widget_compound' => array($this, 'block_form_widget_compound'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3ebcafb472fa7bf7b09177f7224502dc5cf9ea3bde74df645b88b1964cc72bff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3ebcafb472fa7bf7b09177f7224502dc5cf9ea3bde74df645b88b1964cc72bff->enter($__internal_3ebcafb472fa7bf7b09177f7224502dc5cf9ea3bde74df645b88b1964cc72bff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form_table_layout.html.twig"));

        $__internal_8eada4b135467e3a2d53fab33c8bcfeeeff15df618c025fb9cd3db67cbe550f2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8eada4b135467e3a2d53fab33c8bcfeeeff15df618c025fb9cd3db67cbe550f2->enter($__internal_8eada4b135467e3a2d53fab33c8bcfeeeff15df618c025fb9cd3db67cbe550f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form_table_layout.html.twig"));

        // line 3
        $this->displayBlock('form_row', $context, $blocks);
        // line 15
        $this->displayBlock('button_row', $context, $blocks);
        // line 24
        $this->displayBlock('hidden_row', $context, $blocks);
        // line 32
        $this->displayBlock('form_widget_compound', $context, $blocks);
        
        $__internal_3ebcafb472fa7bf7b09177f7224502dc5cf9ea3bde74df645b88b1964cc72bff->leave($__internal_3ebcafb472fa7bf7b09177f7224502dc5cf9ea3bde74df645b88b1964cc72bff_prof);

        
        $__internal_8eada4b135467e3a2d53fab33c8bcfeeeff15df618c025fb9cd3db67cbe550f2->leave($__internal_8eada4b135467e3a2d53fab33c8bcfeeeff15df618c025fb9cd3db67cbe550f2_prof);

    }

    // line 3
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_2eefe328a2cf309d23b06ef1b74bea5d51ae49b2714898d5be4228ee5578892e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2eefe328a2cf309d23b06ef1b74bea5d51ae49b2714898d5be4228ee5578892e->enter($__internal_2eefe328a2cf309d23b06ef1b74bea5d51ae49b2714898d5be4228ee5578892e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_10a7a3a43c453ab20d68fb6b27ae0c16c3e7f5e39b2289e79db5949da72b80d8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_10a7a3a43c453ab20d68fb6b27ae0c16c3e7f5e39b2289e79db5949da72b80d8->enter($__internal_10a7a3a43c453ab20d68fb6b27ae0c16c3e7f5e39b2289e79db5949da72b80d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 4
        echo "<tr>
        <td>";
        // line 6
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 7
        echo "</td>
        <td>";
        // line 9
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 10
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 11
        echo "</td>
    </tr>";
        
        $__internal_10a7a3a43c453ab20d68fb6b27ae0c16c3e7f5e39b2289e79db5949da72b80d8->leave($__internal_10a7a3a43c453ab20d68fb6b27ae0c16c3e7f5e39b2289e79db5949da72b80d8_prof);

        
        $__internal_2eefe328a2cf309d23b06ef1b74bea5d51ae49b2714898d5be4228ee5578892e->leave($__internal_2eefe328a2cf309d23b06ef1b74bea5d51ae49b2714898d5be4228ee5578892e_prof);

    }

    // line 15
    public function block_button_row($context, array $blocks = array())
    {
        $__internal_16b53d73c621904d4bf8115dd87fd8105c05f77b3616ee298271a14409dc1f75 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16b53d73c621904d4bf8115dd87fd8105c05f77b3616ee298271a14409dc1f75->enter($__internal_16b53d73c621904d4bf8115dd87fd8105c05f77b3616ee298271a14409dc1f75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        $__internal_df1c8b5e0c37b5156717555fc53f3506a868db7693656c71dfabd9c289dee13d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df1c8b5e0c37b5156717555fc53f3506a868db7693656c71dfabd9c289dee13d->enter($__internal_df1c8b5e0c37b5156717555fc53f3506a868db7693656c71dfabd9c289dee13d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        // line 16
        echo "<tr>
        <td></td>
        <td>";
        // line 19
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 20
        echo "</td>
    </tr>";
        
        $__internal_df1c8b5e0c37b5156717555fc53f3506a868db7693656c71dfabd9c289dee13d->leave($__internal_df1c8b5e0c37b5156717555fc53f3506a868db7693656c71dfabd9c289dee13d_prof);

        
        $__internal_16b53d73c621904d4bf8115dd87fd8105c05f77b3616ee298271a14409dc1f75->leave($__internal_16b53d73c621904d4bf8115dd87fd8105c05f77b3616ee298271a14409dc1f75_prof);

    }

    // line 24
    public function block_hidden_row($context, array $blocks = array())
    {
        $__internal_6b7a09b11a4408949187eae5369c538a12fafc66ba31265cfc7ee144bd87f82c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6b7a09b11a4408949187eae5369c538a12fafc66ba31265cfc7ee144bd87f82c->enter($__internal_6b7a09b11a4408949187eae5369c538a12fafc66ba31265cfc7ee144bd87f82c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "hidden_row"));

        $__internal_7639adc37e438634156df8c1e894b3af005eb5ace41de1c3bc6c0477f2fa8247 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7639adc37e438634156df8c1e894b3af005eb5ace41de1c3bc6c0477f2fa8247->enter($__internal_7639adc37e438634156df8c1e894b3af005eb5ace41de1c3bc6c0477f2fa8247_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "hidden_row"));

        // line 25
        echo "<tr style=\"display: none\">
        <td colspan=\"2\">";
        // line 27
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 28
        echo "</td>
    </tr>";
        
        $__internal_7639adc37e438634156df8c1e894b3af005eb5ace41de1c3bc6c0477f2fa8247->leave($__internal_7639adc37e438634156df8c1e894b3af005eb5ace41de1c3bc6c0477f2fa8247_prof);

        
        $__internal_6b7a09b11a4408949187eae5369c538a12fafc66ba31265cfc7ee144bd87f82c->leave($__internal_6b7a09b11a4408949187eae5369c538a12fafc66ba31265cfc7ee144bd87f82c_prof);

    }

    // line 32
    public function block_form_widget_compound($context, array $blocks = array())
    {
        $__internal_14eea3522256d4e4af806a1ffae0dcfb393b760c0490ce85fc7f28d61f961376 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_14eea3522256d4e4af806a1ffae0dcfb393b760c0490ce85fc7f28d61f961376->enter($__internal_14eea3522256d4e4af806a1ffae0dcfb393b760c0490ce85fc7f28d61f961376_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_compound"));

        $__internal_cf230c491de9173d5f96a17c72c974f838a4c87f22ec66694401622888797b94 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf230c491de9173d5f96a17c72c974f838a4c87f22ec66694401622888797b94->enter($__internal_cf230c491de9173d5f96a17c72c974f838a4c87f22ec66694401622888797b94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_compound"));

        // line 33
        echo "<table ";
        $this->displayBlock("widget_container_attributes", $context, $blocks);
        echo ">";
        // line 34
        if ((twig_test_empty($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) && (twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0))) {
            // line 35
            echo "<tr>
            <td colspan=\"2\">";
            // line 37
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
            // line 38
            echo "</td>
        </tr>";
        }
        // line 41
        $this->displayBlock("form_rows", $context, $blocks);
        // line 42
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'rest');
        // line 43
        echo "</table>";
        
        $__internal_cf230c491de9173d5f96a17c72c974f838a4c87f22ec66694401622888797b94->leave($__internal_cf230c491de9173d5f96a17c72c974f838a4c87f22ec66694401622888797b94_prof);

        
        $__internal_14eea3522256d4e4af806a1ffae0dcfb393b760c0490ce85fc7f28d61f961376->leave($__internal_14eea3522256d4e4af806a1ffae0dcfb393b760c0490ce85fc7f28d61f961376_prof);

    }

    public function getTemplateName()
    {
        return "form_table_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  168 => 43,  166 => 42,  164 => 41,  160 => 38,  158 => 37,  155 => 35,  153 => 34,  149 => 33,  140 => 32,  129 => 28,  127 => 27,  124 => 25,  115 => 24,  104 => 20,  102 => 19,  98 => 16,  89 => 15,  78 => 11,  76 => 10,  74 => 9,  71 => 7,  69 => 6,  66 => 4,  57 => 3,  47 => 32,  45 => 24,  43 => 15,  41 => 3,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"form_div_layout.html.twig\" %}

{%- block form_row -%}
    <tr>
        <td>
            {{- form_label(form) -}}
        </td>
        <td>
            {{- form_errors(form) -}}
            {{- form_widget(form) -}}
        </td>
    </tr>
{%- endblock form_row -%}

{%- block button_row -%}
    <tr>
        <td></td>
        <td>
            {{- form_widget(form) -}}
        </td>
    </tr>
{%- endblock button_row -%}

{%- block hidden_row -%}
    <tr style=\"display: none\">
        <td colspan=\"2\">
            {{- form_widget(form) -}}
        </td>
    </tr>
{%- endblock hidden_row -%}

{%- block form_widget_compound -%}
    <table {{ block('widget_container_attributes') }}>
        {%- if form.parent is empty and errors|length > 0 -%}
        <tr>
            <td colspan=\"2\">
                {{- form_errors(form) -}}
            </td>
        </tr>
        {%- endif -%}
        {{- block('form_rows') -}}
        {{- form_rest(form) -}}
    </table>
{%- endblock form_widget_compound -%}
", "form_table_layout.html.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bridge/Twig/Resources/views/Form/form_table_layout.html.twig");
    }
}
