<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_bcb4621e2f5f1dc01631a6d50ef49dade5322c4ab96ad25c0e57c4f253522947 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76a6658f74160cbb3667fc54ce33e4532b6a99fb30ff038fc637df6f3850bc74 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76a6658f74160cbb3667fc54ce33e4532b6a99fb30ff038fc637df6f3850bc74->enter($__internal_76a6658f74160cbb3667fc54ce33e4532b6a99fb30ff038fc637df6f3850bc74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        $__internal_c94224e8ce3e878a69f1c1c9db5095d79b665a49a31961131b439d33562ae65d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c94224e8ce3e878a69f1c1c9db5095d79b665a49a31961131b439d33562ae65d->enter($__internal_c94224e8ce3e878a69f1c1c9db5095d79b665a49a31961131b439d33562ae65d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_76a6658f74160cbb3667fc54ce33e4532b6a99fb30ff038fc637df6f3850bc74->leave($__internal_76a6658f74160cbb3667fc54ce33e4532b6a99fb30ff038fc637df6f3850bc74_prof);

        
        $__internal_c94224e8ce3e878a69f1c1c9db5095d79b665a49a31961131b439d33562ae65d->leave($__internal_c94224e8ce3e878a69f1c1c9db5095d79b665a49a31961131b439d33562ae65d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
", "@Framework/Form/form_widget_simple.html.php", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget_simple.html.php");
    }
}
