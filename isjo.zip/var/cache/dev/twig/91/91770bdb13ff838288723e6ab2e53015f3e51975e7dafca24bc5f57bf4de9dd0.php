<?php

/* FOSUserBundle:Registration:check_email.html.twig */
class __TwigTemplate_8d6b81da381da1e96916d19201d7d40f61ae3473da39d4a075e89b5238e63bed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Registration:check_email.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_088bc9fc249f5cf42f7a8a0348e56485a295466260dfbcc799f1b3c3c2117fd3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_088bc9fc249f5cf42f7a8a0348e56485a295466260dfbcc799f1b3c3c2117fd3->enter($__internal_088bc9fc249f5cf42f7a8a0348e56485a295466260dfbcc799f1b3c3c2117fd3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:check_email.html.twig"));

        $__internal_6ace8afe3aac80727799ab5f3e28b0a61f96865775a4eb478989f9d3359710bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6ace8afe3aac80727799ab5f3e28b0a61f96865775a4eb478989f9d3359710bb->enter($__internal_6ace8afe3aac80727799ab5f3e28b0a61f96865775a4eb478989f9d3359710bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:check_email.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_088bc9fc249f5cf42f7a8a0348e56485a295466260dfbcc799f1b3c3c2117fd3->leave($__internal_088bc9fc249f5cf42f7a8a0348e56485a295466260dfbcc799f1b3c3c2117fd3_prof);

        
        $__internal_6ace8afe3aac80727799ab5f3e28b0a61f96865775a4eb478989f9d3359710bb->leave($__internal_6ace8afe3aac80727799ab5f3e28b0a61f96865775a4eb478989f9d3359710bb_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_c04e79895f56448eaae36a38132432ddf1379456a5cff5c3461ea9f52112dd00 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c04e79895f56448eaae36a38132432ddf1379456a5cff5c3461ea9f52112dd00->enter($__internal_c04e79895f56448eaae36a38132432ddf1379456a5cff5c3461ea9f52112dd00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_ffb9a6c661ed9db0cb6f45345d315197b18c741f82abd3245045b9864c9818a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ffb9a6c661ed9db0cb6f45345d315197b18c741f82abd3245045b9864c9818a0->enter($__internal_ffb9a6c661ed9db0cb6f45345d315197b18c741f82abd3245045b9864c9818a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.check_email", array("%email%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "email", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_ffb9a6c661ed9db0cb6f45345d315197b18c741f82abd3245045b9864c9818a0->leave($__internal_ffb9a6c661ed9db0cb6f45345d315197b18c741f82abd3245045b9864c9818a0_prof);

        
        $__internal_c04e79895f56448eaae36a38132432ddf1379456a5cff5c3461ea9f52112dd00->leave($__internal_c04e79895f56448eaae36a38132432ddf1379456a5cff5c3461ea9f52112dd00_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:check_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
    <p>{{ 'registration.check_email'|trans({'%email%': user.email}) }}</p>
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:check_email.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/FOSUserBundle/views/Registration/check_email.html.twig");
    }
}
