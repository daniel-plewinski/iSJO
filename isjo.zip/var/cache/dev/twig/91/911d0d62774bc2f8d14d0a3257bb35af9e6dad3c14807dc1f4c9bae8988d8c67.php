<?php

/* ::show_school_lessons.html.twig */
class __TwigTemplate_2055b4cf49da45ac58db774005d00b3fe9b918b6a37e4b6942273cd401b79721 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::show_school_lessons.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3faee07af597bfa3c65550ea9eff5a6256e78454dc404901c9bebdb4815239b6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3faee07af597bfa3c65550ea9eff5a6256e78454dc404901c9bebdb4815239b6->enter($__internal_3faee07af597bfa3c65550ea9eff5a6256e78454dc404901c9bebdb4815239b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::show_school_lessons.html.twig"));

        $__internal_59c4c00c5735beaf7e7680dee9b6268f87d31eadd5abd8bd4e4d8f531318a44a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_59c4c00c5735beaf7e7680dee9b6268f87d31eadd5abd8bd4e4d8f531318a44a->enter($__internal_59c4c00c5735beaf7e7680dee9b6268f87d31eadd5abd8bd4e4d8f531318a44a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::show_school_lessons.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3faee07af597bfa3c65550ea9eff5a6256e78454dc404901c9bebdb4815239b6->leave($__internal_3faee07af597bfa3c65550ea9eff5a6256e78454dc404901c9bebdb4815239b6_prof);

        
        $__internal_59c4c00c5735beaf7e7680dee9b6268f87d31eadd5abd8bd4e4d8f531318a44a->leave($__internal_59c4c00c5735beaf7e7680dee9b6268f87d31eadd5abd8bd4e4d8f531318a44a_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_3a5c6f777d9640498f734318e6f23c9b5dcc561900f47cf4bfb13f04cc515e8e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3a5c6f777d9640498f734318e6f23c9b5dcc561900f47cf4bfb13f04cc515e8e->enter($__internal_3a5c6f777d9640498f734318e6f23c9b5dcc561900f47cf4bfb13f04cc515e8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e5f99eb4416048054dd99d98eb81a9843a9ec905763913344fd9afae1685d994 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e5f99eb4416048054dd99d98eb81a9843a9ec905763913344fd9afae1685d994->enter($__internal_e5f99eb4416048054dd99d98eb81a9843a9ec905763913344fd9afae1685d994_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"container-fluid\">
    <!-- Page Heading -->
    <div class=\"row\">
        <div class=\"col-md-12\">
            <h2>
                Lekcje
            </h2>
        </div>
    </div>

    <div class=\"row\">
        <ol class=\"breadcrumb\">
            <li>
                <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
            </li>
            <li class=\"active\">
                <i class=\"fa fa-file\"></i> Lekcje
            </li>
        </ol>
    </div>
    <div>

        <div class=\"row\">
            <div class=\"col-lg-12\">
                <h4>Kurs ";
        // line 29
        echo twig_escape_filter($this->env, ($context["courseName"] ?? $this->getContext($context, "courseName")), "html", null, true);
        echo "</h4>
                <table class=\"table\">
                    <thead class=\"thead\">
                    <tr>
                        <th>L.p.</th>
                        <th>Data lekcji</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>

                    ";
        // line 40
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["pagination"] ?? $this->getContext($context, "pagination")));
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 41
            echo "                        <tr>
                            <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["pagination"] ?? $this->getContext($context, "pagination")), "getPaginationData", array()), "firstItemNumber", array()), "html", null, true);
            echo "</td>
                            <td>";
            // line 43
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["element"], "date", array()), "d-m-Y"), "html", null, true);
            echo "</td>
                            <td>
                                <a href=\" ";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete_school_lesson_course", array("id" => $this->getAttribute($context["element"], "id", array()))), "html", null, true);
            echo "\">
                                    <button type=\"button\" class=\"btn btn-danger\">Usuń</button>
                                </a>

                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "                    </tbody>
                </table>
                ";
        // line 55
        echo "                <div class=\"navigation\">
                    <div class=\"text-center\">
                    ";
        // line 57
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, ($context["pagination"] ?? $this->getContext($context, "pagination")));
        echo "
                    </div>
                </div>
            </div>
        </div>
    </div>


";
        
        $__internal_e5f99eb4416048054dd99d98eb81a9843a9ec905763913344fd9afae1685d994->leave($__internal_e5f99eb4416048054dd99d98eb81a9843a9ec905763913344fd9afae1685d994_prof);

        
        $__internal_3a5c6f777d9640498f734318e6f23c9b5dcc561900f47cf4bfb13f04cc515e8e->leave($__internal_3a5c6f777d9640498f734318e6f23c9b5dcc561900f47cf4bfb13f04cc515e8e_prof);

    }

    public function getTemplateName()
    {
        return "::show_school_lessons.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 57,  123 => 55,  119 => 52,  106 => 45,  101 => 43,  97 => 42,  94 => 41,  90 => 40,  76 => 29,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

    <div class=\"container-fluid\">
    <!-- Page Heading -->
    <div class=\"row\">
        <div class=\"col-md-12\">
            <h2>
                Lekcje
            </h2>
        </div>
    </div>

    <div class=\"row\">
        <ol class=\"breadcrumb\">
            <li>
                <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
            </li>
            <li class=\"active\">
                <i class=\"fa fa-file\"></i> Lekcje
            </li>
        </ol>
    </div>
    <div>

        <div class=\"row\">
            <div class=\"col-lg-12\">
                <h4>Kurs {{ courseName }}</h4>
                <table class=\"table\">
                    <thead class=\"thead\">
                    <tr>
                        <th>L.p.</th>
                        <th>Data lekcji</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>

                    {% for element in pagination %}
                        <tr>
                            <td>{{  pagination.getPaginationData.firstItemNumber }}</td>
                            <td>{{ element.date |date('d-m-Y') }}</td>
                            <td>
                                <a href=\" {{ path('delete_school_lesson_course', {'id':  element.id }) }}\">
                                    <button type=\"button\" class=\"btn btn-danger\">Usuń</button>
                                </a>

                            </td>
                        </tr>
                    {% endfor %}
                    </tbody>
                </table>
                {# display navigation #}
                <div class=\"navigation\">
                    <div class=\"text-center\">
                    {{ knp_pagination_render(pagination) }}
                    </div>
                </div>
            </div>
        </div>
    </div>


{% endblock %}", "::show_school_lessons.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/show_school_lessons.html.twig");
    }
}
