<?php

/* ::add_teacher_lesson.html.twig */
class __TwigTemplate_31e8d5756dadf30fc56645f0c0afbdcd59f5557b1972fd3a9f4c6860b7e4aa25 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::add_teacher_lesson.html.twig", 1);
        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e7e0de0102da5370ff76ac2f9322f40d89923fb77f916649d262b3975b484353 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e7e0de0102da5370ff76ac2f9322f40d89923fb77f916649d262b3975b484353->enter($__internal_e7e0de0102da5370ff76ac2f9322f40d89923fb77f916649d262b3975b484353_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::add_teacher_lesson.html.twig"));

        $__internal_6a1acf58a311bcb0113d0c6de6eb80b8270cfc1df0adb6702c2bd55787733b1f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6a1acf58a311bcb0113d0c6de6eb80b8270cfc1df0adb6702c2bd55787733b1f->enter($__internal_6a1acf58a311bcb0113d0c6de6eb80b8270cfc1df0adb6702c2bd55787733b1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::add_teacher_lesson.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e7e0de0102da5370ff76ac2f9322f40d89923fb77f916649d262b3975b484353->leave($__internal_e7e0de0102da5370ff76ac2f9322f40d89923fb77f916649d262b3975b484353_prof);

        
        $__internal_6a1acf58a311bcb0113d0c6de6eb80b8270cfc1df0adb6702c2bd55787733b1f->leave($__internal_6a1acf58a311bcb0113d0c6de6eb80b8270cfc1df0adb6702c2bd55787733b1f_prof);

    }

    // line 3
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_4f83f1308f3099e82bdbb55a6e7d24811890e34d0fc35ebb45d9012784c1970f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4f83f1308f3099e82bdbb55a6e7d24811890e34d0fc35ebb45d9012784c1970f->enter($__internal_4f83f1308f3099e82bdbb55a6e7d24811890e34d0fc35ebb45d9012784c1970f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_5f88f172c0def71eeab1f9a50a863e7af49bc652351f18e6264313dae3054a29 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5f88f172c0def71eeab1f9a50a863e7af49bc652351f18e6264313dae3054a29->enter($__internal_5f88f172c0def71eeab1f9a50a863e7af49bc652351f18e6264313dae3054a29_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 4
        echo "
    ";
        // line 5
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/locales/bootstrap-datepicker.pl.min.js\"></script>

    <script>
        \$(document).ready(function () {
            \$('.js-datepicker').datepicker({
                language: 'pl-PL',
                showOn: 'button',
                buttonImageOnly: true,
                changeMonth: true,
                changeYear: true,
                format: 'yyyy-mm-dd',
                yearRange: \"-0:+1\"

            });
        });
    </script>

";
        
        $__internal_5f88f172c0def71eeab1f9a50a863e7af49bc652351f18e6264313dae3054a29->leave($__internal_5f88f172c0def71eeab1f9a50a863e7af49bc652351f18e6264313dae3054a29_prof);

        
        $__internal_4f83f1308f3099e82bdbb55a6e7d24811890e34d0fc35ebb45d9012784c1970f->leave($__internal_4f83f1308f3099e82bdbb55a6e7d24811890e34d0fc35ebb45d9012784c1970f_prof);

    }

    // line 27
    public function block_body($context, array $blocks = array())
    {
        $__internal_ceda5e520edf9157cf8bca47a424b148917721ed9167b0d7596b2fbc0a5b2ed2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ceda5e520edf9157cf8bca47a424b148917721ed9167b0d7596b2fbc0a5b2ed2->enter($__internal_ceda5e520edf9157cf8bca47a424b148917721ed9167b0d7596b2fbc0a5b2ed2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_6ad6abe64698ef9a2aa0ed570393eaee9539037e76fe9d29b316b7a0eaf64c8c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6ad6abe64698ef9a2aa0ed570393eaee9539037e76fe9d29b316b7a0eaf64c8c->enter($__internal_6ad6abe64698ef9a2aa0ed570393eaee9539037e76fe9d29b316b7a0eaf64c8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 28
        echo "

    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Dodawanie lekcji
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Dodawanie lekcji</a>
                </li>
            </ol>
        </div>

        <p>Do nazwy kursu automatycznie dodawany jest unikalny numer aby nazwa nie mogła się powtarzać</p>

        ";
        // line 50
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 51
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
        ";
        // line 52
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

    </div>



";
        
        $__internal_6ad6abe64698ef9a2aa0ed570393eaee9539037e76fe9d29b316b7a0eaf64c8c->leave($__internal_6ad6abe64698ef9a2aa0ed570393eaee9539037e76fe9d29b316b7a0eaf64c8c_prof);

        
        $__internal_ceda5e520edf9157cf8bca47a424b148917721ed9167b0d7596b2fbc0a5b2ed2->leave($__internal_ceda5e520edf9157cf8bca47a424b148917721ed9167b0d7596b2fbc0a5b2ed2_prof);

    }

    public function getTemplateName()
    {
        return "::add_teacher_lesson.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 52,  121 => 51,  117 => 50,  93 => 28,  84 => 27,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block javascripts %}

    {{ parent() }}

    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/locales/bootstrap-datepicker.pl.min.js\"></script>

    <script>
        \$(document).ready(function () {
            \$('.js-datepicker').datepicker({
                language: 'pl-PL',
                showOn: 'button',
                buttonImageOnly: true,
                changeMonth: true,
                changeYear: true,
                format: 'yyyy-mm-dd',
                yearRange: \"-0:+1\"

            });
        });
    </script>

{% endblock %}

{% block body %}


    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Dodawanie lekcji
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Dodawanie lekcji</a>
                </li>
            </ol>
        </div>

        <p>Do nazwy kursu automatycznie dodawany jest unikalny numer aby nazwa nie mogła się powtarzać</p>

        {{ form_start(form) }}
        {{ form_widget(form) }}
        {{ form_end(form) }}

    </div>



{% endblock %}", "::add_teacher_lesson.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/add_teacher_lesson.html.twig");
    }
}
