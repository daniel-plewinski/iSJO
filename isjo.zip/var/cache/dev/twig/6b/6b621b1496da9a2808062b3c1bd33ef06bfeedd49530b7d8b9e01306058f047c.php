<?php

/* ::add_teacher.html.twig */
class __TwigTemplate_1a43aa7fd4121c1e717ef64eb6d0899e7d431d5854ab2415959fefde7650237e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::add_teacher.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_204ef1105a79e6e758da84a883f2caf0f03b93a2e278624b7b37413b4b808591 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_204ef1105a79e6e758da84a883f2caf0f03b93a2e278624b7b37413b4b808591->enter($__internal_204ef1105a79e6e758da84a883f2caf0f03b93a2e278624b7b37413b4b808591_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::add_teacher.html.twig"));

        $__internal_595379cfa7ef3e9ba97131a1d95e14f16fe5e79e14a27f7493f6acb361dd351a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_595379cfa7ef3e9ba97131a1d95e14f16fe5e79e14a27f7493f6acb361dd351a->enter($__internal_595379cfa7ef3e9ba97131a1d95e14f16fe5e79e14a27f7493f6acb361dd351a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::add_teacher.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_204ef1105a79e6e758da84a883f2caf0f03b93a2e278624b7b37413b4b808591->leave($__internal_204ef1105a79e6e758da84a883f2caf0f03b93a2e278624b7b37413b4b808591_prof);

        
        $__internal_595379cfa7ef3e9ba97131a1d95e14f16fe5e79e14a27f7493f6acb361dd351a->leave($__internal_595379cfa7ef3e9ba97131a1d95e14f16fe5e79e14a27f7493f6acb361dd351a_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_6eafdc3ca0c50e2187045cdc1db9b4650e82e8e13ea2a1c26d7880d5dba04161 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6eafdc3ca0c50e2187045cdc1db9b4650e82e8e13ea2a1c26d7880d5dba04161->enter($__internal_6eafdc3ca0c50e2187045cdc1db9b4650e82e8e13ea2a1c26d7880d5dba04161_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f26953f8ac6539d257e5c850c21559b5046652870f08182ba03585b4d0fd01b5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f26953f8ac6539d257e5c850c21559b5046652870f08182ba03585b4d0fd01b5->enter($__internal_f26953f8ac6539d257e5c850c21559b5046652870f08182ba03585b4d0fd01b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Dodawanie nauczyciela
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Lista nauczycieli
                </li>
            </ol>
        </div>

        <p>Wpisz dane nowego nauczyciela. Hasło zostanie wygenerowane automatycznie i zostanie pokazane na następnej
            stronie. Przekaż dane logowania nauczycielowi i zaleć zmianę hasła na własne.</p>

        ";
        // line 30
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 31
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "
        ";
        // line 32
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

    </div>

";
        
        $__internal_f26953f8ac6539d257e5c850c21559b5046652870f08182ba03585b4d0fd01b5->leave($__internal_f26953f8ac6539d257e5c850c21559b5046652870f08182ba03585b4d0fd01b5_prof);

        
        $__internal_6eafdc3ca0c50e2187045cdc1db9b4650e82e8e13ea2a1c26d7880d5dba04161->leave($__internal_6eafdc3ca0c50e2187045cdc1db9b4650e82e8e13ea2a1c26d7880d5dba04161_prof);

    }

    public function getTemplateName()
    {
        return "::add_teacher.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 32,  80 => 31,  76 => 30,  49 => 5,  40 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}


{% block body %}

    <div class=\"container-fluid\">
        <!-- Page Heading -->
        <div class=\"row\">
            <div class=\"col-md-10\">
                <h2>
                    Dodawanie nauczyciela
                </h2>
            </div>
        </div>

        <div class=\"row\">
            <ol class=\"breadcrumb\">
                <li>
                    <i class=\"fa fa-dashboard\"></i> <a href=\"index.html\">Podsumowanie</a>
                </li>
                <li class=\"active\">
                    <i class=\"fa fa-file\"></i> Lista nauczycieli
                </li>
            </ol>
        </div>

        <p>Wpisz dane nowego nauczyciela. Hasło zostanie wygenerowane automatycznie i zostanie pokazane na następnej
            stronie. Przekaż dane logowania nauczycielowi i zaleć zmianę hasła na własne.</p>

        {{ form_start(form) }}
        {{ form_widget(form) }}
        {{ form_end(form) }}

    </div>

{% endblock %}", "::add_teacher.html.twig", "/home/daniel/Workspace/coderslab/isjo/app/Resources/views/add_teacher.html.twig");
    }
}
