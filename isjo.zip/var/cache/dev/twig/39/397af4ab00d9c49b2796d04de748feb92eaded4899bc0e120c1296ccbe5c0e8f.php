<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_3f0729baf9088382cb7cd0886441f92bc70847f9f4e6f014198607a83f766375 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f142484888c1e702eec5e296eff6d45f1b9d697ab6cca8422a2d5ae8b60fe61 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f142484888c1e702eec5e296eff6d45f1b9d697ab6cca8422a2d5ae8b60fe61->enter($__internal_9f142484888c1e702eec5e296eff6d45f1b9d697ab6cca8422a2d5ae8b60fe61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_ff99a976dbf8e9f61b54e8caccaa3f88addef359421d97e72efa911f02666f75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff99a976dbf8e9f61b54e8caccaa3f88addef359421d97e72efa911f02666f75->enter($__internal_ff99a976dbf8e9f61b54e8caccaa3f88addef359421d97e72efa911f02666f75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9f142484888c1e702eec5e296eff6d45f1b9d697ab6cca8422a2d5ae8b60fe61->leave($__internal_9f142484888c1e702eec5e296eff6d45f1b9d697ab6cca8422a2d5ae8b60fe61_prof);

        
        $__internal_ff99a976dbf8e9f61b54e8caccaa3f88addef359421d97e72efa911f02666f75->leave($__internal_ff99a976dbf8e9f61b54e8caccaa3f88addef359421d97e72efa911f02666f75_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_87d46ad9519e3183c8e6f4c4ed04daaf269c32fc524e03906172785828ce6ea0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_87d46ad9519e3183c8e6f4c4ed04daaf269c32fc524e03906172785828ce6ea0->enter($__internal_87d46ad9519e3183c8e6f4c4ed04daaf269c32fc524e03906172785828ce6ea0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_78bddbff3515eabcc64372dbcb327440fffb90e785fcd516e806580e9b3f3e68 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78bddbff3515eabcc64372dbcb327440fffb90e785fcd516e806580e9b3f3e68->enter($__internal_78bddbff3515eabcc64372dbcb327440fffb90e785fcd516e806580e9b3f3e68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_78bddbff3515eabcc64372dbcb327440fffb90e785fcd516e806580e9b3f3e68->leave($__internal_78bddbff3515eabcc64372dbcb327440fffb90e785fcd516e806580e9b3f3e68_prof);

        
        $__internal_87d46ad9519e3183c8e6f4c4ed04daaf269c32fc524e03906172785828ce6ea0->leave($__internal_87d46ad9519e3183c8e6f4c4ed04daaf269c32fc524e03906172785828ce6ea0_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_01f10c740605c0a56ad2da77110a538501f7a19d5178029307ae0ebe0183fc35 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_01f10c740605c0a56ad2da77110a538501f7a19d5178029307ae0ebe0183fc35->enter($__internal_01f10c740605c0a56ad2da77110a538501f7a19d5178029307ae0ebe0183fc35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_5525134c47564ef082219c1ddfc0debf437e48361e86f787332dceba472d6ca3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5525134c47564ef082219c1ddfc0debf437e48361e86f787332dceba472d6ca3->enter($__internal_5525134c47564ef082219c1ddfc0debf437e48361e86f787332dceba472d6ca3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_5525134c47564ef082219c1ddfc0debf437e48361e86f787332dceba472d6ca3->leave($__internal_5525134c47564ef082219c1ddfc0debf437e48361e86f787332dceba472d6ca3_prof);

        
        $__internal_01f10c740605c0a56ad2da77110a538501f7a19d5178029307ae0ebe0183fc35->leave($__internal_01f10c740605c0a56ad2da77110a538501f7a19d5178029307ae0ebe0183fc35_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "/home/daniel/Workspace/coderslab/isjo/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
